"""Library version and agent identity constants."""

VERSION = "0.1.0"
"""ByteHide Monitor Python library version."""

LIBRARY_NAME = "bytehide-monitor"
"""Library identifier reported to the backend in the agent block."""

USER_AGENT = f"ByteHide-Monitor/{VERSION} (Python)"
"""HTTP User-Agent header sent to the Monitor API."""

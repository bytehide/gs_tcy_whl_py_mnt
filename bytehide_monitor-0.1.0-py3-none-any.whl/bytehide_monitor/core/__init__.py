"""Core infrastructure shared by the cloud firewall layer."""

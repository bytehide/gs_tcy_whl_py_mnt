"""Fail-safe execution wrappers.

The monitor must never crash the host application: any unexpected error inside a
detector, collector or reporter is swallowed and logged instead of propagating.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

R = TypeVar("R")


def guard(action: Callable[[], R], default: R | None = None, *, context: str = "") -> R | None:
    """Run ``action`` and return its result, or ``default`` on any exception."""
    try:
        return action()
    except Exception as exc:  # noqa: BLE001 - intentional fail-safe boundary
        from bytehide_monitor.core.logging.logger import MonitorLogger

        MonitorLogger.error("E007_GUARDED", f"Guarded failure {context}".strip(), exc)
        return default


def guard_void(action: Callable[[], object], *, context: str = "") -> None:
    """Run ``action`` for its side effects, swallowing any exception."""
    guard(action, None, context=context)

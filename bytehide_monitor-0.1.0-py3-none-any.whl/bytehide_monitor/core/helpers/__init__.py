"""Internal helper utilities."""

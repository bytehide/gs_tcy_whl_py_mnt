"""JSON model base and serialization helpers.

Mirrors the Jackson configuration used by the backend contract: snake_case wire
names, omit ``None`` values when writing, and ignore unknown properties when
reading. Dataclass field names are kept identical to the snake_case JSON keys so
no name mapping table is needed.
"""

from __future__ import annotations

import dataclasses
import json
import types
from typing import Any, ClassVar, TypeVar, Union, get_args, get_origin, get_type_hints

T = TypeVar("T", bound="JsonModel")

_NONE_TYPE = type(None)
# Both the legacy ``Optional[X]`` / ``Union[X, None]`` and the PEP 604 ``X | None``
# (``types.UnionType``) spellings must be recognized.
_UNION_ORIGINS = (Union, getattr(types, "UnionType", Union))


def _is_json_model(tp: Any) -> bool:
    return isinstance(tp, type) and issubclass(tp, JsonModel)


def _unwrap_optional(tp: Any) -> Any:
    """Return the inner type of ``Optional[X]`` / ``X | None``; else ``tp``."""
    if get_origin(tp) in _UNION_ORIGINS:
        args = [a for a in get_args(tp) if a is not _NONE_TYPE]
        if len(args) == 1:
            return args[0]
    return tp


def _encode(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, JsonModel):
        return value.to_dict()
    if isinstance(value, (list, tuple)):
        return [_encode(item) for item in value]
    if isinstance(value, dict):
        return {key: _encode(item) for key, item in value.items()}
    return value


def _decode(value: Any, tp: Any) -> Any:
    if value is None:
        return None
    tp = _unwrap_optional(tp)
    origin = get_origin(tp)
    if _is_json_model(tp) and isinstance(value, dict):
        return tp.from_dict(value)
    if origin in (list, list) and isinstance(value, list):
        (item_tp,) = get_args(tp) or (Any,)
        return [_decode(item, item_tp) for item in value]
    if origin in (dict, dict) and isinstance(value, dict):
        args = get_args(tp)
        val_tp = args[1] if len(args) == 2 else Any
        return {key: _decode(item, val_tp) for key, item in value.items()}
    return value


class JsonModel:
    """Base for wire DTOs.

    Subclasses must be ``@dataclass`` declarations whose field names equal the
    snake_case JSON keys. ``to_dict`` omits ``None`` fields; ``from_dict`` ignores
    unknown keys and recursively decodes nested ``JsonModel`` fields.
    """

    # Cache of resolved type hints per concrete subclass.
    _hints_cache: ClassVar[dict] = {}

    def to_dict(self) -> dict:
        result: dict[str, Any] = {}
        for field in dataclasses.fields(self):  # type: ignore[arg-type]
            raw = getattr(self, field.name)
            if raw is None:
                continue
            result[field.name] = _encode(raw)
        return result

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), ensure_ascii=False)

    @classmethod
    def _hints(cls) -> dict:
        cached = JsonModel._hints_cache.get(cls)
        if cached is None:
            cached = get_type_hints(cls)
            JsonModel._hints_cache[cls] = cached
        return cached

    @classmethod
    def from_dict(cls: type[T], data: dict) -> T:
        if not isinstance(data, dict):
            raise TypeError(f"{cls.__name__}.from_dict expects a dict, got {type(data).__name__}")
        hints = cls._hints()
        kwargs: dict[str, Any] = {}
        for field in dataclasses.fields(cls):  # type: ignore[arg-type]
            if field.name not in data:
                continue
            kwargs[field.name] = _decode(data[field.name], hints.get(field.name, Any))
        return cls(**kwargs)

    @classmethod
    def from_json(cls: type[T], text: str) -> T:
        return cls.from_dict(json.loads(text))

"""Base64 helpers (standard and URL-safe), tolerant of missing padding."""

from __future__ import annotations

import base64 as _b64


def _pad(text: str) -> str:
    remainder = len(text) % 4
    return text + ("=" * (4 - remainder)) if remainder else text


def encode(data: bytes) -> str:
    return _b64.b64encode(data).decode("ascii")


def decode(text: str) -> bytes:
    return _b64.b64decode(_pad(text))


def encode_url_safe(data: bytes) -> str:
    return _b64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def decode_url_safe(text: str) -> bytes:
    return _b64.urlsafe_b64decode(_pad(text))

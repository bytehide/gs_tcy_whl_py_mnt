"""Time helpers. All timestamps on the wire are Unix milliseconds, UTC."""

from __future__ import annotations

import time


def now_unix_ms() -> int:
    """Current UTC time as Unix milliseconds."""
    return int(time.time() * 1000)


def monotonic_ms() -> int:
    """Monotonic clock in milliseconds (for intervals; not wall-clock)."""
    return int(time.monotonic() * 1000)

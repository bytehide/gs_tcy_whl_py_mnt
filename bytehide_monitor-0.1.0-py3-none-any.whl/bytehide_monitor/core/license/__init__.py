"""License/signature validation (RS256 JWT)."""

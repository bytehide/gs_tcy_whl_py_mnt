"""License/signature validation failure."""

from __future__ import annotations


class LicenseException(Exception):
    """Raised when a monitor license/signature is missing, expired or tampered with."""

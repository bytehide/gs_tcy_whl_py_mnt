"""Validates a ByteHide Monitor license (RS256-signed JWT), 1:1 with .NET.

Parses ``header.payload.signature``, verifies the RSA-SHA256 signature against the
embedded public key, checks expiry, and extracts the license claims (customer id,
tier, project token). RSA verification requires the optional ``cryptography`` package
(the ``[license]`` extra); without it, a configured license cannot be verified and
validation fails closed.
"""

from __future__ import annotations

import base64
import json

from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.license.license_data import LicenseData
from bytehide_monitor.core.license.license_exception import LicenseException

# ByteHide signing public key (public material; safe to embed).
RSA_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+rS3OadsFwkYVdmiQl9y
IpWv6K42THpF/jTdsnT51m4WnExYZsqJE0rdY4w/Y7IoogxJr5RBkwFr0jCrSfsf
R6DIQnxLTB6bZuBfmFV2kupiHyT5XGHJSogqyDM7XYOmw4s3hGhgbLo7zIO1fEOj
NG4IzzlDmanp/zsEaZ6KA/gt46phllD3OCttOJ/RA9M+EX5kOTH5KFgond57EFku
FXzfJo21Ao7hkslgHnfNGDo9zlhM1672k/nvgc427b6owqKW+0jjg/P4fJ9rDEum
TK6TrmVjKa8uKhtUL9iDEScQ7OTrOxWirKzkM3iCVB4jLoH1B7+MPKO+XaMtlIKF
jQIDAQAB
-----END PUBLIC KEY-----"""


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def validate(jwt: str | None) -> LicenseData:
    """Validate a signed license JWT and return its claims.

    Raises :class:`LicenseException` when the token is malformed, the signature is
    invalid, required claims are missing, or the license has expired.
    """
    if not jwt or jwt.count(".") != 2:
        raise LicenseException("Invalid license: malformed token")

    header_b64, payload_b64, signature_b64 = jwt.split(".")
    try:
        header = json.loads(_b64url_decode(header_b64))
        payload = json.loads(_b64url_decode(payload_b64))
        signature = _b64url_decode(signature_b64)
    except (ValueError, json.JSONDecodeError) as exc:
        raise LicenseException("Invalid license: cannot decode token") from exc

    if str(header.get("alg", "")).upper() != "RS256":
        raise LicenseException("Invalid license: unexpected signing algorithm")

    _verify_rs256(f"{header_b64}.{payload_b64}".encode(), signature)

    license_data = LicenseData(
        customer_id=payload.get("customer_id"),
        tier=payload.get("tier"),
        token=payload.get("token"),
        assembly_name=payload.get("assembly_name"),
        assembly_version=payload.get("assembly_version"),
        target_framework=payload.get("target_framework"),
        expires_at=_int_or_none(payload.get("exp")),
        issued_at=_int_or_none(payload.get("iat")),
    )

    if not license_data.customer_id:
        raise LicenseException("Invalid license: missing customer identifier")
    if not license_data.token:
        raise LicenseException("Invalid license: missing access token")
    if license_data.is_expired:
        raise LicenseException("Invalid license: license has expired")
    return license_data


def validate_from_env() -> LicenseData | None:
    """Validate the license from ``BYTEHIDE_LICENSE`` (env), or ``None`` when absent."""
    jwt = env_vars.get("BYTEHIDE_LICENSE")
    if not jwt:
        return None
    return validate(jwt)


def _verify_rs256(data: bytes, signature: bytes) -> None:
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
    except ImportError as exc:
        raise LicenseException(
            "License verification requires the 'cryptography' package (the [license] extra)"
        ) from exc

    public_key = serialization.load_pem_public_key(RSA_PUBLIC_KEY.encode())
    if not isinstance(public_key, RSAPublicKey):
        raise LicenseException("Invalid license: unsupported public key type")
    try:
        public_key.verify(signature, data, padding.PKCS1v15(), hashes.SHA256())
    except InvalidSignature as exc:
        raise LicenseException("Invalid license: signature verification failed") from exc


def _int_or_none(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None

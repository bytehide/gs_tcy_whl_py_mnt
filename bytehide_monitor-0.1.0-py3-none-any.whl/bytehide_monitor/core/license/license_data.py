"""Validated license data extracted from a signed monitor JWT (1:1 with .NET)."""

from __future__ import annotations

import time
from dataclasses import dataclass


@dataclass
class LicenseData:
    customer_id: str | None = None
    tier: str | None = None
    token: str | None = None
    assembly_name: str | None = None
    assembly_version: str | None = None
    target_framework: str | None = None
    expires_at: int | None = None  # Unix seconds
    issued_at: int | None = None  # Unix seconds

    @property
    def is_expired(self) -> bool:
        return self.expires_at is not None and time.time() > self.expires_at

    @property
    def is_valid(self) -> bool:
        return not self.is_expired

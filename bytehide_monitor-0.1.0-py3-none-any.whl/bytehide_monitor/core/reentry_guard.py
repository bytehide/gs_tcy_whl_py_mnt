"""Re-entrancy guard: suppress sink instrumentation during the monitor's own I/O.

The sink wrappers patch ``open``, DB drivers, ``subprocess`` and outbound HTTP. The
monitor itself performs such operations internally (writing log files, sending
heartbeats/incidents, fetching threat-intel). Without a guard, those internal
operations would be intercepted by the sinks - causing infinite recursion (logging a
threat re-enters the file sink) or self-inspection (reporting HTTP hitting the SSRF
sink). While this guard is active, ``active_runtime()`` reports no runtime, so the
sinks pass straight through.

Backed by a :class:`contextvars.ContextVar` so it is correct under sync and async.
"""

from __future__ import annotations

import contextlib
import contextvars
from collections.abc import Iterator

_INTERNAL: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "bytehide_monitor_internal", default=False
)


def is_active() -> bool:
    return _INTERNAL.get()


@contextlib.contextmanager
def internal() -> Iterator[None]:
    """Mark the enclosed block as monitor-internal I/O (sinks suppressed)."""
    token = _INTERNAL.set(True)
    try:
        yield
    finally:
        _INTERNAL.reset(token)

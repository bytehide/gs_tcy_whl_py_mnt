"""Attack context passed to custom action handlers (public; 1:1 with .NET)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


@dataclass
class AttackContext:
    module_name: str | None = None
    attack_type: str | None = None
    payload: str | None = None
    confidence: float = 0.0
    blocked: bool = False
    module_type: ProtectionModuleType | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

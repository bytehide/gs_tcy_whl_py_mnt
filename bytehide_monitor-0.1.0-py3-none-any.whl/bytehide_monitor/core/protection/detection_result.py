"""Result of a detection operation (1:1 with Java/.NET DetectionResult).

A detector returns a benign result (``threat_detected == False``) or a threat with
a type, description, confidence (0.0-1.0) and metadata. A sanitized application
stack trace is captured on threats (internal/stdlib frames removed) so reports do
not leak detection internals.
"""

from __future__ import annotations

import sys
import traceback
from collections.abc import Iterable
from typing import Any

_INTERNAL_PREFIXES = ("bytehide_monitor",)
_RUNTIME_MARKERS = ("/lib/python", "<frozen", "importlib", "site-packages", "dist-packages")
# Interpreter/venv roots: prefix filtering removes the stdlib and installed packages on
# every platform (Windows installs do not contain the POSIX "lib/python" marker).
_RUNTIME_PREFIXES = tuple(
    {
        prefix.replace("\\", "/").lower()
        for prefix in (sys.prefix, sys.base_prefix, sys.exec_prefix)
        if prefix
    }
)


class DetectionResult:
    __slots__ = ("threat_detected", "threat_type", "description", "confidence", "metadata", "stack")

    def __init__(
        self,
        threat_detected: bool,
        threat_type: str,
        description: str,
        confidence: float,
        metadata: dict[str, Any] | None = None,
        stack: list[str] | None = None,
    ) -> None:
        self.threat_detected = threat_detected
        self.threat_type = threat_type
        self.description = description
        self.confidence = confidence
        self.metadata: dict[str, Any] = metadata if metadata is not None else {}
        self.stack = stack

    @staticmethod
    def success() -> DetectionResult:
        return DetectionResult(False, "None", "No threat detected", 1.0, None, None)

    @staticmethod
    def threat(
        threat_type: str,
        description: str,
        confidence: float,
        metadata: dict[str, Any] | None = None,
        stack: list[str] | None = None,
    ) -> DetectionResult:
        """Build a threat result; ``stack`` overrides the automatic capture when the
        caller already holds the host frames (e.g. async call sites, where the awaiter
        chain is not on the current thread's stack)."""
        return DetectionResult(
            True,
            threat_type,
            description,
            confidence,
            metadata or {},
            stack if stack is not None else _capture_stack(),
        )

    def with_metadata(self, key: str, value: Any) -> DetectionResult:
        self.metadata[key] = value
        return self

    def __repr__(self) -> str:
        return (
            f"DetectionResult(threat={self.threat_detected}, type={self.threat_type}, "
            f"confidence={self.confidence:.2f}, description={self.description})"
        )


def _capture_stack(limit: int = 10) -> list[str] | None:
    return sanitize_frames(traceback.extract_stack()[:-1], limit)


def sanitize_frames(
    frames: Iterable[traceback.FrameSummary], limit: int = 10
) -> list[str] | None:
    """Format application frames as ``name (file:line)``, dropping monitor/runtime frames.

    Runtime frames are filtered by interpreter/venv path prefix (stdlib and installed
    packages on every platform) plus the POSIX/site-packages markers, so the reported
    stack shows only the host application's own frames.
    """
    out: list[str] = []
    for frame in frames:
        filename = frame.filename or ""
        normalized = filename.replace("\\", "/").lower()
        if normalized.startswith(_RUNTIME_PREFIXES):
            continue
        if any(marker in normalized for marker in _RUNTIME_MARKERS):
            continue
        if any(part in normalized for part in _INTERNAL_PREFIXES):
            continue
        out.append(f"{frame.name} ({frame.filename}:{frame.lineno})")
        if len(out) >= limit:
            break
    return out or None

"""Protection module types (1:1 with Java/.NET ProtectionModuleType).

The cloud layer only uses the nine web modules, but the full enum is preserved so
configuration referencing any module name parses correctly.
"""

from __future__ import annotations

import enum


class ProtectionModuleType(enum.Enum):
    # Mobile + desktop
    CLOCK_TAMPERING = "ClockTampering"
    DEBUGGER_DETECTION = "DebuggerDetection"
    JAILBREAK_DETECTION = "JailbreakDetection"
    # Desktop only
    VIRTUAL_MACHINE_DETECTION = "VirtualMachineDetection"
    EMULATOR_DETECTION = "EmulatorDetection"
    MEMORY_DUMP_DETECTION = "MemoryDumpDetection"
    TAMPERING_DETECTION = "TamperingDetection"
    PROCESS_INJECTION = "ProcessInjection"
    NETWORK_TAMPERING = "NetworkTampering"
    LICENSE_BINDING = "LicenseBinding"
    CONTAINER_DETECTION = "ContainerDetection"
    REMOTE_DESKTOP = "RemoteDesktop"
    CLOUD_METADATA = "CloudMetadata"
    # Cloud only (web/API)
    SQL_INJECTION = "SqlInjection"
    CROSS_SITE_SCRIPTING = "CrossSiteScripting"
    PATH_TRAVERSAL = "PathTraversal"
    COMMAND_INJECTION = "CommandInjection"
    SERVER_SIDE_REQUEST_FORGERY = "ServerSideRequestForgery"
    LDAP_INJECTION = "LdapInjection"
    XML_EXTERNAL_ENTITY = "XmlExternalEntity"
    NO_SQL_INJECTION = "NoSqlInjection"
    TEMPLATE_INJECTION = "TemplateInjection"
    UNSAFE_DESERIALIZATION = "UnsafeDeserialization"
    OPEN_REDIRECT = "OpenRedirect"
    HTTP_RESPONSE_SPLITTING = "HttpResponseSplitting"
    LLM_PROMPT_INJECTION = "LlmPromptInjection"
    # Cloud only (web/API) - request-level (run once per request over the full context)
    JWT_ATTACK = "JwtAttack"
    UNAUTHENTICATED_ACCESS = "UnauthenticatedAccess"
    MASS_ASSIGNMENT = "MassAssignment"
    BROKEN_AUTH = "BrokenAuthentication"
    BOLA_ENUMERATION = "BolaEnumeration"
    # Cloud only (web/API) - response-level (run once per request over the outgoing response)
    DATA_EXPOSURE = "DataExposure"

    @property
    def value_str(self) -> str:
        return self.value

    @classmethod
    def cloud_modules(cls) -> list[ProtectionModuleType]:
        return [
            cls.SQL_INJECTION,
            cls.CROSS_SITE_SCRIPTING,
            cls.PATH_TRAVERSAL,
            cls.COMMAND_INJECTION,
            cls.SERVER_SIDE_REQUEST_FORGERY,
            cls.LDAP_INJECTION,
            cls.XML_EXTERNAL_ENTITY,
            cls.NO_SQL_INJECTION,
            cls.LLM_PROMPT_INJECTION,
        ]

    @classmethod
    def from_value(cls, value: str | None) -> ProtectionModuleType | None:
        """Parse a module name (case-insensitive); ``None`` when unknown/empty."""
        if not value:
            return None
        normalized = value.strip().lower()
        for module in cls:
            if module.value.lower() == normalized:
                return module
        return None

    def __str__(self) -> str:
        return self.value

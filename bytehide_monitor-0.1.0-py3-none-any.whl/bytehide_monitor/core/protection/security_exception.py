"""Exception raised by an in-app sink when an attack is detected and must block.

A sink wrapper raises this to abort the dangerous operation (SQL query, command,
file access, outbound request) before it runs. The framework source adapters catch it
and convert it into the RFC 7807 block response (equivalent to the .NET
``SecurityExceptionHandlerMiddleware``).
"""

from __future__ import annotations

from bytehide_monitor.cloud.scanner.block_decision import BlockDecision


class SecurityException(Exception):
    def __init__(self, decision: BlockDecision) -> None:
        super().__init__(decision.reason or "Security threat blocked")
        self.decision = decision

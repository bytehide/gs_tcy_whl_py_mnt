"""Detection engine primitives shared across layers."""

"""Action types executed when a threat is detected (1:1 with Java/.NET ActionType)."""

from __future__ import annotations

import enum


class ActionType(enum.Enum):
    NONE = "none"  # detect only (monitoring)
    LOG = "log"  # log the incident (default)
    BLOCK = "block"  # block the request (cloud only)
    CLOSE = "close"  # terminate the application (desktop/mobile)
    ERASE = "erase"  # erase sensitive data and close (desktop/mobile)
    CUSTOM = "custom"  # execute a registered custom handler

    @property
    def value_str(self) -> str:
        return self.value

    @classmethod
    def from_value(cls, value: str | None, default: ActionType | None = None) -> ActionType:
        if value is None:
            if default is not None:
                return default
            raise ValueError("Action type cannot be None")
        normalized = value.strip().lower()
        for action in cls:
            if action.value == normalized:
                return action
        if default is not None:
            return default
        raise ValueError(f"Unknown action type: {value}")

    def __str__(self) -> str:
        return self.value

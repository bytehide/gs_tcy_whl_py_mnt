"""Context passed to action handlers when a threat is detected (1:1 with .NET).

A handler may set :attr:`should_block` to signal that the request must be blocked
(the built-in ``block`` action does this; custom handlers decide for themselves).
"""

from __future__ import annotations

from bytehide_monitor.core.protection.attack_context import AttackContext
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class ThreatContext:
    def __init__(
        self,
        module_type: ProtectionModuleType,
        threat_type: str | None = None,
        description: str | None = None,
        detection_result: DetectionResult | None = None,
        attack_context: AttackContext | None = None,
    ) -> None:
        self.module_type = module_type
        self.threat_type = threat_type
        self.description = description
        self.detection_result = detection_result
        self.attack_context = attack_context
        self.should_block = False

    @staticmethod
    def from_detection(module_type: ProtectionModuleType, result: DetectionResult) -> ThreatContext:
        return ThreatContext(
            module_type=module_type,
            threat_type=result.threat_type,
            description=result.description,
            detection_result=result,
        )

"""Action registry (1:1 with .NET/Java ``ActionRegistry``).

Resolves an action name to a handler and executes it against a :class:`ThreatContext`.
Built-in actions: ``none`` (detect only), ``log``, ``block`` (sets ``should_block``),
``close``/``erase`` (parity; in a server they block the request rather than terminate
the process). Custom named handlers are registered by the application.
"""

from __future__ import annotations

import threading
from collections.abc import Callable

from bytehide_monitor.core.action.threat_context import ThreatContext
from bytehide_monitor.core.logging.logger import MonitorLogger

# A custom action handler receives the threat context and may set ``should_block``.
ActionHandler = Callable[[ThreatContext], None]

_BUILTIN_NAMES = ("none", "log", "block", "close", "erase")


class ActionRegistry:
    def __init__(self) -> None:
        self._custom: dict[str, ActionHandler] = {}
        self._lock = threading.RLock()

    def register_custom_action(self, name: str, handler: ActionHandler) -> None:
        if not name or not name.strip():
            raise ValueError("Action name cannot be empty")
        if handler is None:
            raise ValueError("Action handler cannot be None")
        with self._lock:
            self._custom[name.lower()] = handler
        MonitorLogger.info("I005_MODULE_LOADED", f"Registered custom action: {name}")

    def unregister_custom_action(self, name: str) -> None:
        with self._lock:
            self._custom.pop(name.lower(), None)

    def is_registered(self, name: str) -> bool:
        return name is not None and name.lower() in self._custom

    def clear_custom_actions(self) -> None:
        with self._lock:
            self._custom.clear()

    def execute(self, action_name: str | None, context: ThreatContext) -> None:
        """Execute the named action against ``context`` (fail-safe)."""
        name = (action_name or "log").strip().lower()
        try:
            if name in _BUILTIN_NAMES:
                _execute_builtin(name, context)
                return
            handler = self._custom.get(name)
            if handler is None:
                MonitorLogger.error("E008_INIT_FAILED", f"Custom action not found: {action_name}")
                return
            handler(context)
        except Exception as exc:  # noqa: BLE001 - an action must never crash the request
            MonitorLogger.error("E008_INIT_FAILED", f"Action execution failed: {action_name}", exc)


def _execute_builtin(name: str, context: ThreatContext) -> None:
    if name == "none":
        return
    if name == "log":
        _log(context)
        return
    if name in ("block", "close", "erase"):
        # In a server context, close/erase block the request rather than terminating the
        # process (which would take down the whole application).
        if name in ("close", "erase"):
            MonitorLogger.warning(
                "W006_ACTION", f"Action '{name}' is not applicable to cloud; blocking the request"
            )
        _log(context)
        context.should_block = True
        return


def _log(context: ThreatContext) -> None:
    MonitorLogger.warning(
        "C003_THREAT_DETECTED",
        f"Threat detected [{context.module_type.value}]: {context.description}",
    )


_INSTANCE = ActionRegistry()


def instance() -> ActionRegistry:
    return _INSTANCE

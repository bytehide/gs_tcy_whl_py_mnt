"""Best-effort runtime taint marking for user-controlled strings.

This is a lightweight dataflow SIGNAL, not a full taint engine. Values that enter from the HTTP
request (query / body / path / headers / cookies) are wrapped in :class:`TaintedStr` by a taint
*source* (see ``sinks/taint_source.py``). The wrapper propagates the taint through the string
operations apps commonly use to BUILD a URL (concatenation where the tainted value is on the left,
``%`` formatting, ``str.format``, slicing, ``join``, case/whitespace normalisation, ``replace``).

A detector that only matters when the value is genuinely user-controlled (SSRF: a server-side fetch
to a user-supplied URL) consults :func:`is_tainted` on the value that reaches the sink. If the URL is
tainted we KNOW it derives from the request -> evaluate it. If it is a plain ``str`` we do NOT treat
absence of taint as proof of safety (see leaks below); the caller keeps a host-level correlation
heuristic as a fallback.

Note ``"prefix" + tainted`` DOES propagate: because :class:`TaintedStr` is a ``str`` subclass that
defines ``__radd__``, Python gives the (right) subclass operand priority, so the result stays tainted.

Known, deliberate leaks (CPython builds these in C and always returns a plain ``str``):
  * f-strings (``f"http://{x}"``) and ``"".join(generator)``;
  * ``bytes`` round-trips and any other C-level transform not overridden above.
Because of these, taint is authoritative for a POSITIVE ("user-controlled") but not for a NEGATIVE.
That is why the SSRF detector uses ``is_tainted(target) OR host_correlates(...)``: taint gives high
confidence when it survives, and the correlation heuristic covers the leak cases without the false
positives of naive whole-URL substring matching.
"""
from __future__ import annotations

import threading
from typing import Any

_active = False
_lock = threading.Lock()


def set_active() -> None:
    """Marks the taint layer as installed, so detectors know tainted values may be present."""
    global _active
    with _lock:
        _active = True


def active() -> bool:
    """Whether a taint source has been installed in this process."""
    return _active


class TaintedStr(str):
    """A ``str`` that remembers it came from user input and propagates that across common string ops.

    Only the operations realistically used to assemble a URL/host from request data are overridden;
    everything else falls back to ``str`` (and silently drops the taint - see the module docstring).
    """

    __slots__ = ()

    @staticmethod
    def _wrap(value: Any) -> Any:
        if isinstance(value, TaintedStr):
            return value
        return TaintedStr(value) if isinstance(value, str) else value

    def __add__(self, other: Any) -> Any:
        return TaintedStr._wrap(str.__add__(self, other))

    def __radd__(self, other: Any) -> Any:
        # Reached only when the left operand is not a str (str + TaintedStr is handled by str.__add__,
        # which loses the taint - a documented leak). Kept for non-str left operands.
        if isinstance(other, str):
            return TaintedStr._wrap(other + str(self))
        return NotImplemented

    def __mod__(self, other: Any) -> Any:
        return TaintedStr._wrap(str.__mod__(self, other))

    def __getitem__(self, item: Any) -> Any:
        return TaintedStr._wrap(str.__getitem__(self, item))

    def __mul__(self, n: int) -> Any:
        return TaintedStr._wrap(str.__mul__(self, n))

    __rmul__ = __mul__

    def format(self, *args: Any, **kwargs: Any) -> Any:  # noqa: A003 - mirrors str.format
        return TaintedStr._wrap(str.format(self, *args, **kwargs))

    def format_map(self, mapping: Any) -> Any:
        return TaintedStr._wrap(str.format_map(self, mapping))

    def join(self, iterable: Any) -> Any:
        return TaintedStr._wrap(str.join(self, iterable))

    def strip(self, *args: Any) -> Any:
        return TaintedStr._wrap(str.strip(self, *args))

    def lstrip(self, *args: Any) -> Any:
        return TaintedStr._wrap(str.lstrip(self, *args))

    def rstrip(self, *args: Any) -> Any:
        return TaintedStr._wrap(str.rstrip(self, *args))

    def lower(self) -> Any:
        return TaintedStr._wrap(str.lower(self))

    def upper(self) -> Any:
        return TaintedStr._wrap(str.upper(self))

    def replace(self, *args: Any, **kwargs: Any) -> Any:
        return TaintedStr._wrap(str.replace(self, *args, **kwargs))


def taint(value: Any) -> Any:
    """Wrap a ``str`` as :class:`TaintedStr` (idempotent; non-str values are returned unchanged)."""
    if isinstance(value, TaintedStr):
        return value
    if isinstance(value, str):
        return TaintedStr(value)
    return value


def is_tainted(value: Any) -> bool:
    """Whether ``value`` is a user-controlled :class:`TaintedStr`."""
    return isinstance(value, TaintedStr)

"""Central monitor logger (Python port of Java ``MonitorLogger`` / .NET ``SLog``).

Multi-sink, thread-safe, code-prefixed structured logging. Static-style API via a
module-level singleton; logging failures never propagate to the host application.
"""

from __future__ import annotations

import os
import threading
from collections.abc import Mapping, Sequence
from typing import Any

from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.logging.log_level import LogLevel
from bytehide_monitor.core.logging.sinks.base import LogSink
from bytehide_monitor.core.logging.sinks.console import ConsoleSink
from bytehide_monitor.core.logging.sinks.file import FileSink


def _is_debug_mode() -> bool:
    value = os.environ.get("BYTEHIDE_MONITOR_DEBUG", "")
    return value.lower() in ("true", "1")


class _Logger:
    def __init__(self) -> None:
        self._sinks: list[LogSink] = []
        self._minimum_level = LogLevel.INFO
        self._initialized = False
        self._lock = threading.RLock()

    def initialize(self) -> None:
        with self._lock:
            if self._initialized:
                return
            env_level = os.environ.get("BYTEHIDE_MONITOR_LOG_LEVEL")
            if env_level:
                try:
                    self._minimum_level = LogLevel[env_level.upper()]
                except KeyError:
                    pass
            if _is_debug_mode():
                self._sinks.append(ConsoleSink(self._minimum_level))
            try:
                self._sinks.append(FileSink(self._minimum_level))
            except Exception:  # noqa: BLE001 - file sink is best-effort
                pass
            self._initialized = True

    def add_sink(self, sink: LogSink) -> None:
        with self._lock:
            if sink not in self._sinks:
                self._sinks.append(sink)

    def clear_sinks(self) -> None:
        with self._lock:
            self._sinks.clear()

    def set_minimum_level(self, level: LogLevel) -> None:
        self._minimum_level = level

    @property
    def minimum_level(self) -> LogLevel:
        return self._minimum_level

    def log(
        self,
        level: LogLevel,
        code: str,
        message: str,
        context: Mapping[str, Any] | None = None,
        metadata: Mapping[str, Any] | None = None,
        tags: Sequence[str] | None = None,
        correlation_id: str | None = None,
        exception: BaseException | None = None,
    ) -> None:
        if not level.is_enabled(self._minimum_level):
            return
        if not self._initialized:
            self.initialize()
        # Mark log-file I/O as monitor-internal so the filesystem sink does not intercept
        # (and recurse into) the monitor's own log writes.
        with reentry_guard.internal():
            for sink in list(self._sinks):
                try:
                    if sink.is_enabled(level):
                        sink.write(
                            level, code, message, context, metadata, tags, correlation_id, exception
                        )
                except Exception:  # noqa: BLE001 - sink errors must not crash the app
                    pass

    def flush(self) -> None:
        for sink in list(self._sinks):
            try:
                sink.flush()
            except Exception:  # noqa: BLE001
                pass

    def shutdown(self) -> None:
        self.flush()
        for sink in list(self._sinks):
            try:
                sink.close()
            except Exception:  # noqa: BLE001
                pass
        with self._lock:
            self._sinks.clear()
            self._initialized = False


_INSTANCE = _Logger()


class MonitorLogger:
    """Static facade over the module-level logger instance."""

    @staticmethod
    def initialize() -> None:
        _INSTANCE.initialize()

    @staticmethod
    def add_sink(sink: LogSink) -> None:
        _INSTANCE.add_sink(sink)

    @staticmethod
    def clear_sinks() -> None:
        _INSTANCE.clear_sinks()

    @staticmethod
    def set_minimum_level(level: LogLevel) -> None:
        _INSTANCE.set_minimum_level(level)

    @staticmethod
    def debug(code: str, message: str, exception: BaseException | None = None) -> None:
        _INSTANCE.log(LogLevel.DEBUG, code, message, exception=exception)

    @staticmethod
    def info(code: str, message: str, exception: BaseException | None = None) -> None:
        _INSTANCE.log(LogLevel.INFO, code, message, exception=exception)

    @staticmethod
    def warning(code: str, message: str, exception: BaseException | None = None) -> None:
        _INSTANCE.log(LogLevel.WARNING, code, message, exception=exception)

    @staticmethod
    def error(code: str, message: str, exception: BaseException | None = None) -> None:
        _INSTANCE.log(LogLevel.ERROR, code, message, exception=exception)

    @staticmethod
    def critical(code: str, message: str, exception: BaseException | None = None) -> None:
        _INSTANCE.log(LogLevel.CRITICAL, code, message, exception=exception)

    @staticmethod
    def log_threat(
        level: LogLevel,
        code: str,
        message: str,
        context: Mapping[str, Any] | None = None,
        metadata: Mapping[str, Any] | None = None,
        tags: Sequence[str] | None = None,
        correlation_id: str | None = None,
    ) -> None:
        _INSTANCE.log(level, code, message, context, metadata, tags, correlation_id)

    @staticmethod
    def flush() -> None:
        _INSTANCE.flush()

    @staticmethod
    def shutdown() -> None:
        _INSTANCE.shutdown()

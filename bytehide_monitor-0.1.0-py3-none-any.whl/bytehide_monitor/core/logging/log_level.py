"""Log severity levels (1:1 with the Java/.NET LogLevel enum)."""

from __future__ import annotations

import enum


class LogLevel(enum.IntEnum):
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4

    def is_enabled(self, minimum: LogLevel) -> bool:
        return self.value >= minimum.value

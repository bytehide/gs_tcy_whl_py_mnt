"""Log sinks: destinations that receive formatted log records."""

from bytehide_monitor.core.logging.sinks.console import ConsoleSink
from bytehide_monitor.core.logging.sinks.file import FileSink

__all__ = ["ConsoleSink", "FileSink"]

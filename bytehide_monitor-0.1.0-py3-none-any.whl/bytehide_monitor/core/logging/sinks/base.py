"""Log sink interface and shared record formatting."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

from bytehide_monitor.core.logging.log_level import LogLevel


class LogSink:
    """Base sink. Subclasses override :meth:`emit`."""

    def __init__(self, minimum_level: LogLevel = LogLevel.INFO) -> None:
        self.minimum_level = minimum_level

    def is_enabled(self, level: LogLevel) -> bool:
        return level.is_enabled(self.minimum_level)

    def format(
        self,
        level: LogLevel,
        code: str,
        message: str,
        exception: BaseException | None = None,
    ) -> str:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        line = f"{ts} [{level.name:<8}] [{code}] {message}"
        if exception is not None:
            line += f" | {type(exception).__name__}: {exception}"
        return line

    def write(
        self,
        level: LogLevel,
        code: str,
        message: str,
        context: Mapping[str, Any] | None = None,
        metadata: Mapping[str, Any] | None = None,
        tags: Sequence[str] | None = None,
        correlation_id: str | None = None,
        exception: BaseException | None = None,
    ) -> None:
        self.emit(level, self.format(level, code, message, exception))

    def emit(self, level: LogLevel, line: str) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass

"""Rotating file log sink.

Writes to a hidden per-user directory:
- Windows: ``%LOCALAPPDATA%/.bytehide/monitor/logs``
- Unix/macOS: ``~/.bytehide/monitor/logs``
Size-based rotation keeps a bounded number of backups.
"""

from __future__ import annotations

import os
import threading
from pathlib import Path

from bytehide_monitor.core.logging.log_level import LogLevel
from bytehide_monitor.core.logging.sinks.base import LogSink

_MAX_BYTES = 10 * 1024 * 1024
_MAX_FILES = 7


def _default_log_dir() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    else:
        base = os.path.expanduser("~")
    return Path(base) / ".bytehide" / "monitor" / "logs"


class FileSink(LogSink):
    def __init__(
        self,
        minimum_level: LogLevel = LogLevel.INFO,
        directory: Path | None = None,
        max_bytes: int = _MAX_BYTES,
        max_files: int = _MAX_FILES,
    ) -> None:
        super().__init__(minimum_level)
        self._dir = directory or _default_log_dir()
        self._max_bytes = max_bytes
        self._max_files = max_files
        self._lock = threading.Lock()
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / "monitor.log"

    def emit(self, level: LogLevel, line: str) -> None:
        with self._lock:
            try:
                self._rotate_if_needed()
                with open(self._path, "a", encoding="utf-8") as handle:
                    handle.write(line + "\n")
            except Exception:  # noqa: BLE001 - logging must never raise
                pass

    def _rotate_if_needed(self) -> None:
        try:
            if not self._path.exists() or self._path.stat().st_size < self._max_bytes:
                return
        except OSError:
            return
        oldest = self._dir / f"monitor.{self._max_files}.log"
        if oldest.exists():
            oldest.unlink(missing_ok=True)
        for index in range(self._max_files - 1, 0, -1):
            src = self._dir / f"monitor.{index}.log"
            if src.exists():
                src.rename(self._dir / f"monitor.{index + 1}.log")
        self._path.rename(self._dir / "monitor.1.log")

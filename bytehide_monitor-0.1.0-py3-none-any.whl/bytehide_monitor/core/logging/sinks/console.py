"""Console log sink (writes to stderr to avoid polluting application stdout)."""

from __future__ import annotations

import sys

from bytehide_monitor.core.logging.log_level import LogLevel
from bytehide_monitor.core.logging.sinks.base import LogSink


class ConsoleSink(LogSink):
    def emit(self, level: LogLevel, line: str) -> None:
        stream = sys.stderr
        try:
            stream.write(line + "\n")
            stream.flush()
        except Exception:  # noqa: BLE001 - logging must never raise
            pass

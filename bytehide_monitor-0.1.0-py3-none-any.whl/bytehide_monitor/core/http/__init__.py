"""Backend HTTP client and retry strategy."""

"""Shared TLS context builder for the monitor's outbound HTTP clients.

Every client verifies the peer fully (``create_default_context``); this centralizes the one extra hardening the
platform store cannot guarantee on its own. Windows materializes public root CAs lazily: a root needed for the
first time (for example ISRG Root X1 behind ``*.bytehide.com``) can be absent from the system store on first
contact, so verification fails until another process triggers its download. When ``certifi`` is importable its
deterministic CA bundle is added on top of the platform store to close that gap. certifi stays optional - the
engine keeps zero required third-party runtime dependencies, so its absence simply leaves the platform store in
effect - and an explicit ``SSL_CERT_FILE`` continues to win because ``create_default_context`` honors it.
"""

from __future__ import annotations

import ssl


def create_ssl_context() -> ssl.SSLContext:
    """Builds a full-verification TLS context, augmenting the platform trust store with certifi when present."""
    context = ssl.create_default_context()
    try:
        import certifi

        context.load_verify_locations(certifi.where())
    except Exception:  # noqa: BLE001 - certifi is optional; the platform trust store remains in effect
        pass
    return context

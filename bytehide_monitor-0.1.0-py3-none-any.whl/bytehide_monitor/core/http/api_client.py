"""Backend HTTP client for the ByteHide Monitor API v2.

Stdlib-only (``urllib`` + ``ssl``); snake_case JSON, omit nulls, ignore unknown
response fields. Synchronous methods returning an :class:`ApiResponse`; the
reporting layer drives them from a background daemon thread. Offline mode
(``BYTEHIDE_MONITOR_OFFLINE=true``) returns synthetic success without any network
call.

TLS uses the platform trust store with full verification. Certificate pinning is
intentionally not implemented: the .NET cloud HTTP client does not pin either
(pinning was a Java/OkHttp-only feature), so standard TLS verification is 1:1.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.http import retry_strategy
from bytehide_monitor.core.http.tls import create_ssl_context
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.platform.application_info_provider import get_monitor_version
from bytehide_monitor.models.requests.device_registration import DeviceRegistrationRequest
from bytehide_monitor.models.requests.heartbeat import HeartbeatRequest
from bytehide_monitor.models.requests.incident_report import IncidentReportRequest
from bytehide_monitor.models.requests.session_creation import SessionCreationRequest
from bytehide_monitor.models.requests.session_end import SessionEndRequest
from bytehide_monitor.models.responses.api_response import ApiResponse

PRODUCTION_BASE_URL = "https://monitor.microservice.bytehide.com/api"
STAGING_BASE_URL = "https://api.stage1.monitor.bytehide.com/api"
_TIMEOUT_SECONDS = 15
_USER_AGENT = f"ByteHide-Monitor/{get_monitor_version()} (Python)"


class MonitorApiClient:
    def __init__(self, project_token: str, use_staging: bool | None = None) -> None:
        self._token = project_token
        if use_staging is None:
            use_staging = env_vars.get_bool(env_vars.STAGING, False)
        self._base_url = STAGING_BASE_URL if use_staging else PRODUCTION_BASE_URL
        self._offline = env_vars.get_bool(env_vars.OFFLINE, False)
        self._ssl_context = create_ssl_context()
        if self._offline:
            MonitorLogger.warning("W005_OFFLINE_MODE", "API client running in offline mode")
        else:
            MonitorLogger.info("I010_API_CONNECTED", f"API client initialized: {self._base_url}")

    @property
    def offline(self) -> bool:
        return self._offline

    # ---------- API methods ----------

    def register_device(self, request: DeviceRegistrationRequest) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Device registered (offline)", None)
        return self._post(f"/device/{self._token}", request.to_json())

    def create_session(self, request: SessionCreationRequest) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Session created (offline)", None)
        return self._post(f"/session/{self._token}", request.to_json())

    def end_session(self, session_id: str, request: SessionEndRequest) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Session ended (offline)", None)
        return self._put(f"/session/{self._token}/{session_id}/end", request.to_json())

    def send_heartbeat(self, request: HeartbeatRequest) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Heartbeat received (offline)", None)
        return self._post(f"/heartbeat/{self._token}", request.to_json())

    def report_incident(self, request: IncidentReportRequest) -> ApiResponse:
        if self._offline:
            MonitorLogger.warning("W005_OFFLINE_MODE", "Incident not reported (offline mode)")
            return ApiResponse.ok("Incident logged locally", None)
        return self._post(f"/incidence/{self._token}", request.to_json())

    def get_config(self) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Config (offline)", None)
        return self._get(f"/config/{self._token}")

    def get_config_updated_at(self) -> ApiResponse:
        if self._offline:
            return ApiResponse.ok("Config updated-at (offline)", None)
        return self._get(f"/config/updated-at/{self._token}")

    # ---------- HTTP plumbing ----------

    def _post(self, endpoint: str, body: str) -> ApiResponse:
        return self._send("POST", endpoint, body)

    def _put(self, endpoint: str, body: str) -> ApiResponse:
        return self._send("PUT", endpoint, body)

    def _get(self, endpoint: str) -> ApiResponse:
        return self._send("GET", endpoint, None)

    def _send(self, method: str, endpoint: str, body: str | None) -> ApiResponse:
        url = self._base_url + endpoint
        try:
            return retry_strategy.execute(lambda: self._execute(method, url, body))
        except Exception as exc:  # noqa: BLE001 - converted to an error envelope
            MonitorLogger.error("E004_API_FAILED", f"{method} request failed: {endpoint}", exc)
            return ApiResponse.fail("Request failed", "INTERNAL_ERROR", str(exc))

    def _execute(self, method: str, url: str, body: str | None) -> ApiResponse:
        data = body.encode("utf-8") if body is not None else None
        request = urllib.request.Request(url=url, data=data, method=method)
        request.add_header("User-Agent", _USER_AGENT)
        request.add_header("Content-Type", "application/json")
        request.add_header("Accept", "application/json")
        try:
            # The monitor's own outbound HTTP must not be intercepted by the SSRF sink.
            with reentry_guard.internal(), urllib.request.urlopen(  # noqa: S310 - fixed https backend URL
                request, timeout=_TIMEOUT_SECONDS, context=self._ssl_context
            ) as response:
                payload = response.read().decode("utf-8")
                return self._parse(response.status, payload)
        except urllib.error.HTTPError as exc:
            payload = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
            MonitorLogger.error("E004_API_FAILED", f"API request failed: HTTP {exc.code}")
            return ApiResponse.fail(f"HTTP error: {exc.code}", f"HTTP_{exc.code}", payload or None)

    @staticmethod
    def _parse(status: int, payload: str) -> ApiResponse:
        if not payload:
            return ApiResponse.ok("Success", None)
        try:
            return ApiResponse.from_dict(json.loads(payload))
        except (json.JSONDecodeError, TypeError) as exc:
            return ApiResponse.fail("Invalid response", "PARSE_ERROR", str(exc))

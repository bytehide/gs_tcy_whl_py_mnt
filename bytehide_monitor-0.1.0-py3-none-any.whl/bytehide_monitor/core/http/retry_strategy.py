"""Retry strategy for HTTP requests: incremental backoff, up to 3 attempts.

Matches the .NET ``RetryHelper`` defaults: the delay grows linearly with the attempt
number (1s after the first failure, 2s after the second).
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import TypeVar

from bytehide_monitor.core.logging.logger import MonitorLogger

T = TypeVar("T")

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 1.0


def execute(operation: Callable[[], T]) -> T:
    """Run ``operation`` with retry; re-raise the last error if all attempts fail."""
    attempt = 0
    last_error: Exception = RuntimeError("retry never executed")
    while attempt < MAX_RETRIES:
        try:
            return operation()
        except Exception as exc:  # noqa: BLE001 - retried then re-raised
            last_error = exc
            attempt += 1
            if attempt >= MAX_RETRIES:
                MonitorLogger.error(
                    "E004_API_FAILED", f"Request failed after {MAX_RETRIES} retries", exc
                )
                raise
            delay = RETRY_DELAY_SECONDS * attempt
            MonitorLogger.warning(
                "W006_RETRY",
                f"Request failed (attempt {attempt}/{MAX_RETRIES}), retrying in {delay}s",
            )
            time.sleep(delay)
    raise last_error

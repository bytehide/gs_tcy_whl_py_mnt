"""Configuration loading and resolution."""

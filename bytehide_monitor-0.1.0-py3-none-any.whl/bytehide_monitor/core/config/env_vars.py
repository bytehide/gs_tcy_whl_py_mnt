"""ByteHide Monitor environment variables (mirrors .NET ConfigurationLoader).

All reads are defensive and never raise, so configuration loading degrades
gracefully in locked-down runtimes.
"""

from __future__ import annotations

import os

# Project token (highest priority).
MONITOR_TOKEN = "BYTEHIDE_MONITOR_TOKEN"
# Project token (fallback).
TOKEN = "BYTEHIDE_TOKEN"
# Path to the monitor configuration JSON file.
CONFIG = "BYTEHIDE_MONITOR_CONFIG"
# When truthy, the SDK runs without contacting the backend (offline mode).
OFFLINE = "BYTEHIDE_MONITOR_OFFLINE"
# When truthy, enables debug responses / verbose diagnostics.
DEBUG = "BYTEHIDE_MONITOR_DEBUG"
# When truthy, disables monitoring entirely.
DISABLE = "BYTEHIDE_DISABLE"
# ByteHide Logs integration token.
LOGS_TOKEN = "BYTEHIDE_LOGS_TOKEN"
# Optional minimum log level override.
LOG_LEVEL = "BYTEHIDE_MONITOR_LOG_LEVEL"
# When truthy, use the staging backend instead of production.
STAGING = "BYTEHIDE_MONITOR_STAGING"
# Base URL of the ByteHide AI gateway. When set, AI SDK calls (OpenAI/Anthropic) are guarded by it.
# Unset disables AI protection entirely (both modes). See AI_MODE for how the guard is applied.
AI_GATEWAY_URL = "BYTEHIDE_AI_GATEWAY_URL"
# Explicit local override for how the gateway guards AI SDK calls (see sinks/ai.py). When unset, the mode is
# taken from the gateway's GET /monitor/config (keyed by the project token); set this to force a mode locally:
#   "gateway" - transparently reroute the SDK base_url through the gateway, which calls the provider on the
#               host's behalf and applies its guardrails inline.
#   "inline"  - keep the host calling the provider directly, but pre-validate every request against the
#               gateway's POST /validate endpoint first and block on a guardrail hit.
AI_MODE = "BYTEHIDE_AI_MODE"
# Tenant credential sent as the x-gateway-key header when routing AI SDK calls through the gateway.
AI_GATEWAY_KEY = "BYTEHIDE_AI_GATEWAY_KEY"
# Optional JSON map of extra OpenAI-compatible provider hosts to gateway provider slugs, so custom/self-hosted
# providers (e.g. an Ollama host, a corporate LLM) are also redirected through the gateway. Example:
# {"llm.corp": "mycorp", "localhost": "myollama"}. The slug must be configured on the gateway (CUSTOM_PROVIDERS).
AI_EXTRA_PROVIDERS = "BYTEHIDE_AI_EXTRA_PROVIDERS"
# Per-request timeout (seconds) for the inline-mode gateway POST /validate call. The guard may run an ML model,
# so the default is generous (15s); lower it to bound latency. On timeout the guard fails open (the host call
# proceeds, never blocked by a slow gateway) and is not retried. Invalid/non-positive values fall back to 15.
AI_VALIDATE_TIMEOUT = "BYTEHIDE_AI_VALIDATE_TIMEOUT"


def get(name: str) -> str | None:
    """Return the trimmed env var value, or ``None`` when unset/empty/unreadable."""
    try:
        value = os.environ.get(name)
    except Exception:  # noqa: BLE001 - never raise on env access
        return None
    if value is None:
        return None
    value = value.strip()
    return value or None


def get_bool(name: str, default: bool = False) -> bool:
    """Return a boolean env var; truthy values are ``"true"`` (any case) and ``"1"``."""
    value = get(name)
    if value is None:
        return default
    return value.lower() == "true" or value == "1"


def resolve_token() -> str | None:
    """Resolve the project token from env vars in priority order."""
    return get(MONITOR_TOKEN) or get(TOKEN)

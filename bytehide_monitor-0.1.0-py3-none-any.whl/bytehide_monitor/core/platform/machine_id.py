"""Stable machine identifier (SHA-256 of hardware/OS identifiers).

Compatible with the .NET/Java algorithm: gather platform identifiers, join with
``|``, SHA-256, lowercase hex. Falls back to user/host identifiers when hardware
identifiers are unavailable. The result is cached for the process lifetime.
"""

from __future__ import annotations

import hashlib
import os
import platform
import subprocess
import threading
import uuid

from bytehide_monitor.core import reentry_guard

_cache: str | None = None
_lock = threading.Lock()


def get_machine_id() -> str:
    global _cache
    if _cache is None:
        with _lock:
            if _cache is None:
                # The identifier-gathering subprocess/file reads are monitor-internal and
                # must not be intercepted by the command/filesystem sinks.
                with reentry_guard.internal():
                    _cache = _generate()
    return _cache


def reset_cache() -> None:
    global _cache
    _cache = None


def _generate() -> str:
    identifiers: list[str] = []
    system = platform.system().lower()
    if system == "windows":
        identifiers.extend(_windows_identifiers())
    elif system == "darwin":
        identifiers.extend(_macos_identifiers())
    elif system == "linux":
        identifiers.extend(_linux_identifiers())

    identifiers = [i for i in identifiers if i and i.strip()]
    if not identifiers:
        identifiers = [
            os.environ.get("USERNAME") or os.environ.get("USER") or "unknown",
            os.path.expanduser("~"),
            platform.python_version(),
            f"{uuid.getnode():x}",
        ]
    combined = "|".join(identifiers)
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()


def _exec(*command: str) -> str | None:
    try:
        output = subprocess.run(  # noqa: S603 - fixed, non-user commands
            list(command),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:  # noqa: BLE001 - identifier collection is best-effort
        return None
    result = (output.stdout or "").strip()
    return result or None


def _windows_identifiers() -> list[str]:
    ids: list[str] = []
    guid = _exec(
        "reg", "query",
        r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography",
        "/v", "MachineGuid",
    )
    if guid:
        parts = guid.split()
        if parts:
            ids.append(parts[-1])
    board = _exec("wmic", "baseboard", "get", "serialnumber")
    if board:
        lines = [line.strip() for line in board.splitlines() if line.strip()]
        if len(lines) > 1:
            ids.append(lines[1])
    return ids


def _macos_identifiers() -> list[str]:
    ids: list[str] = []
    profile = _exec("ioreg", "-rd1", "-c", "IOPlatformExpertDevice")
    if profile:
        for line in profile.splitlines():
            if "IOPlatformUUID" in line and "=" in line:
                ids.append(line.split("=", 1)[1].strip().strip('"'))
                break
    return ids


def _linux_identifiers() -> list[str]:
    ids: list[str] = []
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id", "/sys/class/dmi/id/product_uuid"):
        try:
            with open(path, encoding="utf-8") as handle:
                value = handle.read().strip()
                if value:
                    ids.append(value)
        except OSError:
            continue
    return ids

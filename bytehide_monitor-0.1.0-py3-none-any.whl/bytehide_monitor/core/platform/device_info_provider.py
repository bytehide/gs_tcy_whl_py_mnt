"""Server/web device information provider.

Populates the cloud-relevant subset of the Device model (OS, architecture, CPU
count, runtime, locale, timezone, hostname). Mobile/desktop-only fields stay
``None`` and are omitted from the payload.
"""

from __future__ import annotations

import locale as _locale
import os
import platform
import socket
import time

from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.platform.application_info_provider import (
    get_runtime_framework,
    get_runtime_version,
)
from bytehide_monitor.models.device import Device

_OS_NAMES = {"windows": "Windows", "linux": "Linux", "darwin": "macOS"}


def collect_device() -> Device:
    # platform.architecture() shells out to ``file`` on POSIX (and other platform.*
    # helpers may spawn subprocesses); this is monitor-internal I/O and must not be
    # intercepted by the command sink — same guard as machine_id collection.
    with reentry_guard.internal():
        return _collect_device()


def _collect_device() -> Device:
    system = platform.system().lower()
    lang = _detect_locale()
    try:
        tz = time.tzname[0] if time.tzname else None
    except Exception:  # noqa: BLE001
        tz = None
    return Device(
        schema_version=2,
        name=_hostname(),
        os_name=_OS_NAMES.get(system, platform.system() or None),
        os=platform.platform(),
        version=platform.release() or None,
        architecture=platform.machine() or None,
        is_64bit_process=platform.architecture()[0] == "64bit",
        processor_count=os.cpu_count(),
        processor_name=platform.processor() or None,
        runtime_version=get_runtime_version(),
        runtime_framework=get_runtime_framework(),
        locale=lang,
        timezone=tz,
    )


def _detect_locale() -> str | None:
    try:
        lang = _locale.getlocale()[0]
        if lang:
            return lang
    except Exception:  # noqa: BLE001
        pass
    for var in ("LC_ALL", "LC_CTYPE", "LANG"):
        value = os.environ.get(var)
        if value:
            return value.split(".")[0]
    return None


def _hostname() -> str:
    try:
        return socket.gethostname()
    except Exception:  # noqa: BLE001
        return "unknown"

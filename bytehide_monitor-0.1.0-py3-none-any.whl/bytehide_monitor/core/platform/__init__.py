"""Platform, machine identity and application info providers."""

"""Application and agent identity providers."""

from __future__ import annotations

import platform

from bytehide_monitor.models.agent import Agent
from bytehide_monitor.models.application import Application, ApplicationRuntime
from bytehide_monitor.version import LIBRARY_NAME, VERSION


def get_monitor_version() -> str:
    return VERSION


def build_agent() -> Agent:
    """Agent block sent to the backend identifying this library build."""
    return Agent(version=VERSION, library=LIBRARY_NAME)


# Alias matching the Java/.NET naming used by the reporting layer.
def get_agent_info() -> Agent:
    return build_agent()


def get_application_info(name: str, version: str | None = None, framework: str | None = None) -> Application:
    """Application metadata for device registration (cloud/web platform)."""
    return Application(
        name=name,
        version=version or VERSION,
        type="web",
        language="Python",
        runtime=ApplicationRuntime(
            platform="web",
            framework=framework,
            version=get_runtime_version(),
        ),
    )


def get_runtime_version() -> str:
    return platform.python_version()


def get_runtime_framework() -> str:
    """Python implementation (CPython, PyPy, ...)."""
    return platform.python_implementation()

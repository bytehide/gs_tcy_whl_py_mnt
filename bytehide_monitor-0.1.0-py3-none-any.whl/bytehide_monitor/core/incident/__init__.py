"""Offline-first incident queue."""

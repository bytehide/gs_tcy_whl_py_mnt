"""Offline-first incident queue (bounded, thread-safe, FIFO).

Incidents that fail to send (offline or backend error) are enqueued and retried by
the reporter. The queue is bounded so a long outage cannot exhaust memory; the oldest
entries are dropped when full.
"""

from __future__ import annotations

import threading
from collections import deque

from bytehide_monitor.models.requests.incident_report import IncidentReportRequest

_DEFAULT_MAX_SIZE = 1000


class IncidentQueue:
    def __init__(self, max_size: int = _DEFAULT_MAX_SIZE) -> None:
        self._queue: deque[IncidentReportRequest] = deque(maxlen=max_size)
        self._lock = threading.Lock()

    def enqueue(self, request: IncidentReportRequest) -> None:
        if request is None:
            return
        with self._lock:
            self._queue.append(request)

    def peek(self) -> IncidentReportRequest | None:
        with self._lock:
            return self._queue[0] if self._queue else None

    def dequeue(self) -> IncidentReportRequest | None:
        with self._lock:
            return self._queue.popleft() if self._queue else None

    def is_empty(self) -> bool:
        with self._lock:
            return not self._queue

    def size(self) -> int:
        with self._lock:
            return len(self._queue)

    def clear(self) -> None:
        with self._lock:
            self._queue.clear()


_INSTANCE = IncidentQueue()


def get_instance() -> IncidentQueue:
    return _INSTANCE

"""HTTP client for the ByteHide threat-intelligence IP feed (1:1 with .NET client).

Fetches IPv4 ranges (uint32 ``[from, to]`` pairs) for blocked countries and threat
actors. Stdlib-only; honors offline mode. Responses can be large, so a generous
timeout is used.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from collections.abc import Iterable

from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.http.tls import create_ssl_context
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.threat_intel.threat_intel_store import IpRange

BASE_URL = "https://threat-intel.bytehide.com"
COUNTRY_ENDPOINT = "/api/country-ips"
ACTORS_ENDPOINT = "/api/threat-actors"
_TIMEOUT_SECONDS = 300


class ThreatIntelClient:
    def __init__(self) -> None:
        self._offline = env_vars.get_bool(env_vars.OFFLINE, False)
        self._ssl_context = create_ssl_context()

    def fetch_country_ips(self, countries: Iterable[str]) -> dict[str, list[IpRange]]:
        country_list = ",".join(c for c in countries if c)
        if not country_list or self._offline:
            return {}
        return self._fetch(f"{BASE_URL}{COUNTRY_ENDPOINT}?country={country_list}", "country")

    def fetch_threat_actor_ips(self, threat_actors: Iterable[str]) -> dict[str, list[IpRange]]:
        actor_list = ",".join(a for a in threat_actors if a)
        if not actor_list or self._offline:
            return {}
        return self._fetch(f"{BASE_URL}{ACTORS_ENDPOINT}?type={actor_list}", "threat-actor")

    def _fetch(self, url: str, label: str) -> dict[str, list[IpRange]]:
        try:
            request = urllib.request.Request(url=url, method="GET")
            request.add_header("Accept", "application/json")
            with reentry_guard.internal(), urllib.request.urlopen(  # noqa: S310 - fixed https feed URL
                request, timeout=_TIMEOUT_SECONDS, context=self._ssl_context
            ) as response:
                payload = json.loads(response.read().decode("utf-8"))
            return _convert(payload.get("data"))
        except (urllib.error.URLError, json.JSONDecodeError, ValueError, TimeoutError) as exc:
            MonitorLogger.error("E004_API_FAILED", f"ThreatIntel {label} fetch failed: {exc}")
            return {}


def _convert(data: object) -> dict[str, list[IpRange]]:
    if not isinstance(data, dict):
        return {}
    result: dict[str, list[IpRange]] = {}
    for key, ranges in data.items():
        if not isinstance(ranges, list):
            continue
        parsed: list[IpRange] = []
        for entry in ranges:
            if isinstance(entry, (list, tuple)) and len(entry) == 2:
                try:
                    parsed.append((int(entry[0]), int(entry[1])))
                except (TypeError, ValueError):
                    continue
        result[key] = parsed
    return result

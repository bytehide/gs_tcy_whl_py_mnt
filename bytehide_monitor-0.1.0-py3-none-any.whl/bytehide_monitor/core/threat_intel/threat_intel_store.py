"""In-memory threat-intelligence IP store (1:1 with .NET ``ThreatIntelStore``).

Holds IPv4 ranges (as ``uint32`` ``[from, to]`` pairs) for blocked countries and
threat actors, merged into a sorted list for O(log n) blocked-IP lookup via binary
search. Thread-safe.
"""

from __future__ import annotations

import threading
from collections.abc import Iterable

# A range is an inclusive (from, to) pair of uint32 IPv4 addresses.
IpRange = tuple[int, int]


def parse_ip_to_uint(ip: str | None) -> int | None:
    """Parse an IPv4 string to its uint32 value (big-endian); ``None`` when invalid."""
    if not ip:
        return None
    parts = ip.split(".")
    if len(parts) != 4:
        return None
    value = 0
    for part in parts:
        if not part.isdigit():
            return None
        octet = int(part)
        if octet > 255:
            return None
        value = (value << 8) | octet
    return value


def uint_to_ip(value: int) -> str:
    return f"{(value >> 24) & 0xFF}.{(value >> 16) & 0xFF}.{(value >> 8) & 0xFF}.{value & 0xFF}"


class ThreatIntelStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._country_data: dict[str, list[IpRange]] = {}
        self._threat_actor_data: dict[str, list[IpRange]] = {}
        self._active_countries: set[str] = set()
        self._active_threat_actors: set[str] = set()
        self._merged: list[IpRange] = []

    def is_blocked(self, ip: int | str | None) -> bool:
        if isinstance(ip, str):
            parsed = parse_ip_to_uint(ip)
            if parsed is None:
                return False
            ip = parsed
        if not isinstance(ip, int):
            return False
        ranges = self._merged  # snapshot reference (replaced atomically on rebuild)
        return _binary_search_contains(ranges, ip)

    def update_countries(
        self, data: dict[str, list[IpRange]], active_countries: Iterable[str]
    ) -> None:
        with self._lock:
            self._country_data = data or {}
            self._active_countries = {c.lower() for c in (active_countries or [])}
            self._rebuild()

    def update_threat_actors(
        self, data: dict[str, list[IpRange]], active_threat_actors: Iterable[str]
    ) -> None:
        with self._lock:
            self._threat_actor_data = data or {}
            self._active_threat_actors = {a.lower() for a in (active_threat_actors or [])}
            self._rebuild()

    def clear_countries(self) -> None:
        with self._lock:
            self._country_data = {}
            self._active_countries = set()
            self._rebuild()

    def clear_threat_actors(self) -> None:
        with self._lock:
            self._threat_actor_data = {}
            self._active_threat_actors = set()
            self._rebuild()

    def _rebuild(self) -> None:
        ranges: list[IpRange] = []
        for code, code_ranges in self._country_data.items():
            if code.lower() in self._active_countries:
                ranges.extend(code_ranges)
        for actor, actor_ranges in self._threat_actor_data.items():
            if actor.lower() in self._active_threat_actors:
                ranges.extend(actor_ranges)
        self._merged = _merge_ranges(ranges)


def _merge_ranges(ranges: list[IpRange]) -> list[IpRange]:
    if not ranges:
        return []
    ordered = sorted(ranges, key=lambda r: r[0])
    merged: list[IpRange] = []
    current_from, current_to = ordered[0]
    for next_from, next_to in ordered[1:]:
        if current_to + 1 >= next_from:  # overlapping or adjacent
            current_to = max(current_to, next_to)
        else:
            merged.append((current_from, current_to))
            current_from, current_to = next_from, next_to
    merged.append((current_from, current_to))
    return merged


def _binary_search_contains(ranges: list[IpRange], ip: int) -> bool:
    left, right = 0, len(ranges) - 1
    while left <= right:
        mid = left + (right - left) // 2
        start, end = ranges[mid]
        if ip < start:
            right = mid - 1
        elif ip > end:
            left = mid + 1
        else:
            return True
    return False

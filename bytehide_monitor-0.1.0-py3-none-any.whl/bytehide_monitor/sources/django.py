"""Django integration (new-style middleware).

Add to ``MIDDLEWARE`` near the top::

    MIDDLEWARE = [
        "bytehide_monitor.sources.django.ByteHideMonitorMiddleware",
        ...
    ]

Initialize the runtime once at startup (e.g. in ``settings.py`` or ``apps.py``)::

    import bytehide_monitor
    bytehide_monitor.protect(token="...")
"""

from __future__ import annotations

import json
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.context.user import User
from bytehide_monitor.cloud.runtime import get_active
from bytehide_monitor.core.protection.security_exception import SecurityException
from bytehide_monitor.sinks._patcher import clear_pending_block, consume_pending_block
from bytehide_monitor.sinks.orm import reset_request_state as reset_mass_assign_state


class ByteHideMonitorMiddleware:
    def __init__(self, get_response: Any) -> None:
        self._get_response = get_response

    def __call__(self, request: Any):
        runtime = get_active()
        if runtime is None or not runtime.enabled:
            return self._get_response(request)

        context = _build_context(request)
        clear_pending_block()  # no stale block from a previous request on this worker
        reset_mass_assign_state()  # fresh per-request mass-assignment allowlist (gthread reuse)
        try:
            decision = runtime.web_request.report(context)
            if decision is not None:
                return _block_response(runtime, decision, context)
            try:
                response = self._get_response(request)
            except SecurityException as exc:
                consume_pending_block()
                runtime.report_sink_incident(exc.decision)
                return _block_response(runtime, exc.decision, _RouteHolder(_route_of(request)))
            # A sink may have decided to block but the view swallowed the SecurityException
            # (e.g. a broad ``except`` that returns 500). Honour the recorded block as a 403.
            pending = consume_pending_block()
            if pending is not None:
                runtime.report_sink_incident(pending)
                return _block_response(runtime, pending, _RouteHolder(_route_of(request)))
            blocked = _scan_response(runtime, request, response)
            if blocked is not None:
                response = blocked
            try:
                runtime.web_response.report(getattr(response, "status_code", 200))
            except Exception:  # noqa: BLE001
                pass
            return response
        finally:
            runtime.web_request.clear()
            clear_pending_block()
            reset_mass_assign_state()

    def process_exception(self, request: Any, exception: Exception):
        """Convert a sink-raised SecurityException into the RFC 7807 block response."""
        if not isinstance(exception, SecurityException):
            return None
        runtime = get_active()
        if runtime is None:
            return None
        consume_pending_block()
        runtime.report_sink_incident(exception.decision)
        return _block_response(runtime, exception.decision, _RouteHolder(_route_of(request)))


def _route_of(request: Any) -> str:
    route = request.path
    resolver = getattr(request, "resolver_match", None)
    if resolver is not None and getattr(resolver, "route", None):
        route = resolver.route
    return route


class _RouteHolder:
    def __init__(self, route: str) -> None:
        self.route = route


def _block_response(runtime, decision, context):
    from django.http import HttpResponse

    problem = runtime.build_block_response(decision, context.route)
    return HttpResponse(
        problem.to_json(),
        status=decision.http_status,
        content_type=problem.CONTENT_TYPE,
    )


def _scan_response(runtime, request, response):
    """Reflected-XSS analysis of a Django response; returns a 403 response when blocked."""
    try:
        if getattr(response, "streaming", False):
            return None
        content_type = response.get("Content-Type", "")
        body = response.content.decode(response.charset or "utf-8", "replace")
        decision = runtime.scan_response(body, content_type, getattr(response, "status_code", 200))
        if decision is None:
            return None
        runtime.report_sink_incident(decision)
        if not decision.blocked:
            return None
        return _block_response(runtime, decision, _RouteHolder(request.path))
    except Exception:  # noqa: BLE001 - response analysis must never break the response
        return None


def _build_context(request: Any) -> ContextObject:
    route = request.path
    resolver = getattr(request, "resolver_match", None)
    if resolver is not None and getattr(resolver, "route", None):
        route = resolver.route
    headers = {key: value for key, value in request.headers.items()}
    return ContextObject(
        method=request.method,
        url=request.build_absolute_uri(),
        route=route,
        remote_address=request.META.get("REMOTE_ADDR"),
        headers=headers,
        query={key: request.GET.get(key) for key in request.GET},
        cookies={key: value for key, value in request.COOKIES.items()},
        body=_extract_body(request),
        user=_extract_user(request),
    )


def _extract_body(request: Any) -> Any:
    content_type = (request.content_type or "").lower()
    if content_type.startswith("application/json"):
        try:
            return json.loads(request.body.decode("utf-8")) if request.body else None
        except (ValueError, UnicodeDecodeError):
            return None
    if request.method in ("POST", "PUT", "PATCH") and request.POST:
        return {key: request.POST.get(key) for key in request.POST}
    try:
        return request.body.decode("utf-8") or None if request.body else None
    except (ValueError, UnicodeDecodeError):
        return None


def _extract_user(request: Any) -> User | None:
    user = getattr(request, "user", None)
    if user is None or not getattr(user, "is_authenticated", False):
        return None
    user_id = getattr(user, "pk", None) or getattr(user, "username", None)
    if user_id is None:
        return None
    name = getattr(user, "username", None)
    return User(id=str(user_id), name=str(name) if name is not None else None)

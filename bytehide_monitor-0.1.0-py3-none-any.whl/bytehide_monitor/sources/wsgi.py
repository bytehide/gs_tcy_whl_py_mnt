"""Generic WSGI middleware.

Wraps any WSGI application: builds a context from the request, runs the inbound
collector, returns an RFC 7807 block response on a block, otherwise calls the wrapped
app and records response-time analytics. Works standalone and is the basis for the
Flask integration.

Usage::

    from bytehide_monitor.sources.wsgi import ByteHideMonitorWSGI
    app = ByteHideMonitorWSGI(app, runtime)  # runtime from bytehide_monitor.protect(...)
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.response.response_xss import is_analyzable
from bytehide_monitor.cloud.runtime import CloudRuntime, get_active
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.security_exception import SecurityException
from bytehide_monitor.sinks.orm import reset_request_state as reset_mass_assign_state
from bytehide_monitor.sources._common import build_wsgi_context

StartResponse = Callable[..., Any]


def _header(headers: list[tuple[str, str]], name: str) -> str | None:
    lowered = name.lower()
    for key, value in headers or []:
        if key.lower() == lowered:
            return value
    return None


class ByteHideMonitorWSGI:
    def __init__(self, app: Callable, runtime: CloudRuntime | None = None) -> None:
        self._app = app
        self._runtime = runtime

    def _resolve_runtime(self) -> CloudRuntime | None:
        return self._runtime or get_active()

    def __call__(self, environ: dict[str, Any], start_response: StartResponse) -> Iterable[bytes]:
        runtime = self._resolve_runtime()
        if runtime is None or not runtime.enabled:
            return self._app(environ, start_response)
        # Re-entrancy guard: skip if an outer ByteHide layer already handled this request (avoid double scanning).
        if environ.get("bytehide.seen"):
            return self._app(environ, start_response)
        environ["bytehide.seen"] = True

        context, environ = build_wsgi_context(environ)
        reset_mass_assign_state()  # fresh per-request mass-assignment allowlist
        try:
            decision = runtime.web_request.report(context)
            if decision is not None:
                return _write_block(runtime, decision, context, start_response)
            return self._run_app(runtime, environ, context, start_response)
        finally:
            runtime.web_request.clear()
            reset_mass_assign_state()

    def _run_app(
        self,
        runtime: CloudRuntime,
        environ: dict[str, Any],
        context: ContextObject,
        start_response: StartResponse,
    ) -> Iterable[bytes]:
        # Capture the app's status/headers WITHOUT calling the real start_response yet, so
        # the response body can be analyzed (reflected XSS) and the status changed to 403.
        captured: dict[str, Any] = {"status": "200 OK", "headers": [], "code": 200}

        def _capture(status: str, headers: list[tuple[str, str]], exc_info=None):
            captured["status"] = status
            captured["headers"] = headers
            try:
                captured["code"] = int(status.split(" ", 1)[0])
            except (ValueError, IndexError):
                captured["code"] = 200
            return lambda _data: None

        try:
            result = self._app(environ, _capture)
            content_type = _header(captured["headers"], "Content-Type")
            if not is_analyzable(content_type) or not (200 <= captured["code"] < 300):
                return self._passthrough(runtime, captured, result, start_response)
            body = b"".join(result)
        except SecurityException as exc:
            # An in-app sink (SQL/command/file/HTTP/LDAP/NoSQL/XML) blocked the operation.
            runtime.report_sink_incident(exc.decision)
            return _write_block(runtime, exc.decision, context, start_response)

        decision = runtime.scan_response(
            body.decode("utf-8", "replace"), content_type, captured["code"]
        )
        if decision is not None:
            runtime.report_sink_incident(decision)
            if decision.blocked:
                return _write_block(runtime, decision, context, start_response)

        start_response(captured["status"], captured["headers"])
        self._report(runtime, captured["code"])
        return [body]

    @staticmethod
    def _passthrough(runtime, captured, result, start_response) -> Iterable[bytes]:
        start_response(captured["status"], captured["headers"])
        ByteHideMonitorWSGI._report(runtime, captured["code"])
        return result

    @staticmethod
    def _report(runtime: CloudRuntime, status_code: int) -> None:
        try:
            runtime.web_response.report(status_code)
        except Exception:  # noqa: BLE001 - analytics must never break the response
            pass


def _write_block(
    runtime: CloudRuntime,
    decision: BlockDecision,
    context: ContextObject,
    start_response: StartResponse,
) -> Iterable[bytes]:
    problem = runtime.build_block_response(decision, context.route)
    body = problem.to_json().encode("utf-8")
    status_line = f"{decision.http_status} {_reason_phrase(decision.http_status)}"
    headers = [
        ("Content-Type", problem.CONTENT_TYPE),
        ("Content-Length", str(len(body))),
    ]
    start_response(status_line, headers)
    return [body]


def _reason_phrase(status: int) -> str:
    return {403: "Forbidden", 429: "Too Many Requests"}.get(status, "Blocked")

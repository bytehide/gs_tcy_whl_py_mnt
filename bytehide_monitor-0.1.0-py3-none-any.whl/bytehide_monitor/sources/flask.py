"""Flask integration (extension using request hooks).

Registers ``before_request``/``after_request``/``teardown_request`` hooks so the
matched route template is available and the request body is read through Flask's
cached accessor (the view can still read it).

Wiring is idempotent: the hooks are registered exactly once per app and the active
runtime is kept behind ``app.extensions``, so calling ``protect()`` (which auto-
integrates Flask) and also wiring ``ByteHideMonitor(app, runtime)`` by hand does not
double-register the hooks. An explicitly provided runtime takes precedence.

Usage::

    import bytehide_monitor
    from bytehide_monitor.sources.flask import ByteHideMonitor

    runtime = bytehide_monitor.protect(token="...")
    app = Flask(__name__)
    ByteHideMonitor(app, runtime)
"""

from __future__ import annotations

from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.context.user import User
from bytehide_monitor.cloud.runtime import CloudRuntime, get_active
from bytehide_monitor.core.protection.security_exception import SecurityException

# Key under ``app.extensions`` holding the per-app monitor state: the wiring instance and
# the active runtime. Shared with sources.auto, which wires Flask via ByteHideMonitor.
_EXTENSION_KEY = "bytehide_monitor"


class ByteHideMonitor:
    def __init__(self, app: Any = None, runtime: CloudRuntime | None = None) -> None:
        self._runtime = runtime
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Any) -> None:
        # Idempotent via indirection: register the hooks once and keep the runtime behind
        # app.extensions, so re-wiring the app (auto-integration + a manual
        # ByteHideMonitor(app, runtime)) only updates which runtime the single hook set
        # uses. An explicit runtime takes precedence over an auto-integrated one.
        extensions = getattr(app, "extensions", None)
        if extensions is None:
            extensions = app.extensions = {}
        state = extensions.get(_EXTENSION_KEY)
        if state is None:
            app.before_request(self._before_request)
            app.after_request(self._after_request)
            app.teardown_request(self._teardown_request)
            app.register_error_handler(SecurityException, self._handle_security)
            extensions[_EXTENSION_KEY] = {"instance": self, "runtime": self._runtime}
        else:
            if self._runtime is not None:
                state["runtime"] = self._runtime
            state["instance"] = self

    def _handle_security(self, exc: SecurityException):
        from flask import Response, request

        runtime = self._resolve_runtime()
        if runtime is None:
            raise exc
        runtime.report_sink_incident(exc.decision)
        problem = runtime.build_block_response(exc.decision, request.path)
        return Response(
            problem.to_json(),
            status=exc.decision.http_status,
            content_type=problem.CONTENT_TYPE,
        )

    def _resolve_runtime(self) -> CloudRuntime | None:
        # Prefer the runtime recorded on the app (re-wiring updates it in place); fall back
        # to this instance's runtime, then the global active runtime.
        try:
            from flask import current_app

            state = current_app.extensions.get(_EXTENSION_KEY)
        except Exception:  # noqa: BLE001 - no application context bound
            state = None
        if state is not None and state.get("runtime") is not None:
            return state["runtime"]
        return self._runtime or get_active()

    def _before_request(self):
        runtime = self._resolve_runtime()
        if runtime is None or not runtime.enabled:
            return None
        from flask import Response, request

        from bytehide_monitor.sinks.orm import reset_request_state
        reset_request_state()  # fresh per-request mass-assignment allowlist

        context = _build_context(request)
        decision = runtime.web_request.report(context)
        if decision is not None:
            problem = runtime.build_block_response(decision, context.route)
            return Response(
                problem.to_json(),
                status=decision.http_status,
                content_type=problem.CONTENT_TYPE,
            )
        return None

    def _after_request(self, response):
        runtime = self._resolve_runtime()
        if runtime is not None and runtime.enabled:
            blocked = self._scan_response(runtime, response)
            if blocked is not None:
                response = blocked
            try:
                runtime.web_response.report(response.status_code)
            except Exception:  # noqa: BLE001
                pass
        return response

    def _scan_response(self, runtime, response):
        from flask import Response

        try:
            if getattr(response, "is_streamed", False) or getattr(response, "direct_passthrough", False):
                return None
            body = response.get_data(as_text=True)
            decision = runtime.scan_response(body, response.content_type, response.status_code)
            if decision is None:
                return None
            runtime.report_sink_incident(decision)
            if not decision.blocked:
                return None
            from flask import request

            problem = runtime.build_block_response(decision, request.path)
            return Response(
                problem.to_json(), status=decision.http_status, content_type=problem.CONTENT_TYPE
            )
        except Exception:  # noqa: BLE001 - response analysis must never break the response
            return None

    def _teardown_request(self, _exc=None):
        runtime = self._resolve_runtime()
        if runtime is not None:
            runtime.web_request.clear()


def _build_context(request: Any) -> ContextObject:
    route = request.url_rule.rule if request.url_rule is not None else request.path
    return ContextObject(
        method=request.method,
        url=request.url,
        route=route,
        remote_address=request.remote_addr,
        headers={key: value for key, value in request.headers.items()},
        query={key: request.args.get(key) for key in request.args},
        cookies={key: request.cookies.get(key) for key in request.cookies},
        path_params=dict(request.view_args or {}),
        body=_extract_body(request),
        user=_extract_user(request),
    )


def _extract_body(request: Any) -> Any:
    if request.is_json:
        data = request.get_json(silent=True)
        if data is not None:
            return data
    if request.form:
        return {key: request.form.get(key) for key in request.form}
    try:
        return request.get_data(cache=True, as_text=True) or None
    except Exception:  # noqa: BLE001
        return None


def _extract_user(request: Any) -> User | None:
    user = getattr(request, "user", None)
    if user is None:
        return None
    user_id = getattr(user, "id", None) or getattr(user, "username", None)
    if user_id is None:
        return None
    name = getattr(user, "username", None) or getattr(user, "name", None)
    return User(id=str(user_id), name=str(name) if name is not None else None)

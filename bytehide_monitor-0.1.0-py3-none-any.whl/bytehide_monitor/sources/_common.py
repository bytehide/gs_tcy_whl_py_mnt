"""Shared request-extraction helpers for the framework source adapters.

Builds a framework-agnostic :class:`ContextObject` from a WSGI ``environ`` (the body
is buffered and re-exposed so the application can still read it) and from raw request
parts (used by ASGI/Django adapters).
"""

from __future__ import annotations

import io
import json
from collections.abc import Mapping
from http.cookies import SimpleCookie
from typing import Any
from urllib.parse import parse_qs

from bytehide_monitor.cloud.context.context_object import ContextObject

# Maximum request body bytes inspected (avoids buffering unbounded uploads).
MAX_BODY_BYTES = 1024 * 1024


def parse_body(raw: bytes, content_type: str | None) -> Any:
    """Parse a raw body into a dict/list (JSON, form) or a decoded string."""
    if not raw:
        return None
    ctype = (content_type or "").lower()
    text = raw.decode("utf-8", errors="replace")
    if "application/json" in ctype:
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return text
    if "application/x-www-form-urlencoded" in ctype:
        return {key: values[0] for key, values in parse_qs(text, keep_blank_values=True).items()}
    return text


def query_to_map(query_string: str) -> dict[str, str]:
    if not query_string:
        return {}
    return {
        key: values[0]
        for key, values in parse_qs(query_string, keep_blank_values=True).items()
    }


def cookies_to_map(cookie_header: str | None) -> dict[str, str]:
    if not cookie_header:
        return {}
    jar: SimpleCookie = SimpleCookie()
    try:
        jar.load(cookie_header)
    except Exception:  # noqa: BLE001 - malformed cookies are ignored
        return {}
    return {name: morsel.value for name, morsel in jar.items()}


def headers_from_wsgi(environ: Mapping[str, Any]) -> dict[str, str]:
    headers: dict[str, str] = {}
    for key, value in environ.items():
        if key.startswith("HTTP_"):
            name = key[5:].replace("_", "-").title()
            headers[name] = value
    if environ.get("CONTENT_TYPE"):
        headers["Content-Type"] = environ["CONTENT_TYPE"]
    if environ.get("CONTENT_LENGTH"):
        headers["Content-Length"] = environ["CONTENT_LENGTH"]
    return headers


def _build_url(environ: Mapping[str, Any]) -> str:
    scheme = environ.get("wsgi.url_scheme", "http")
    host = environ.get("HTTP_HOST") or environ.get("SERVER_NAME", "")
    path = environ.get("PATH_INFO", "")
    query = environ.get("QUERY_STRING", "")
    url = f"{scheme}://{host}{path}"
    return f"{url}?{query}" if query else url


def build_wsgi_context(environ: dict[str, Any]) -> tuple[ContextObject, dict[str, Any]]:
    """Build a context from a WSGI environ, buffering the body for re-reading.

    Returns the context and the (possibly mutated) environ whose ``wsgi.input`` has
    been replaced with a fresh stream so the downstream application can read the body.
    """
    headers = headers_from_wsgi(environ)
    try:
        length = int(environ.get("CONTENT_LENGTH") or 0)
    except (TypeError, ValueError):
        length = 0
    raw = b""
    stream = environ.get("wsgi.input")
    if stream is not None and length > 0:
        to_read = min(length, MAX_BODY_BYTES)
        raw = stream.read(to_read)
        # Re-expose the consumed body so the application can read it again.
        environ["wsgi.input"] = io.BytesIO(raw)

    context = ContextObject(
        method=environ.get("REQUEST_METHOD"),
        url=_build_url(environ),
        route=environ.get("PATH_INFO"),
        remote_address=environ.get("REMOTE_ADDR"),
        headers=headers,
        query=query_to_map(environ.get("QUERY_STRING", "")),
        cookies=cookies_to_map(headers.get("Cookie")),
        body=parse_body(raw, headers.get("Content-Type")),
    )
    return context, environ

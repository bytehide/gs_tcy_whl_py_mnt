"""Automatic framework integration.

A single ``bytehide_monitor.protect()`` call instruments whatever web framework the host app uses, with no manual
middleware wiring - the same one-command experience as Aikido's ``protect()``. It registers lazy import hooks (via
wrapt) that patch each supported framework's application construction, so every app built AFTER ``protect()`` is
wrapped automatically:

- Flask: each ``Flask(...)`` instance gets the request hooks registered (``sources.flask.ByteHideMonitor``).
- Starlette / FastAPI: the composed ASGI app is wrapped with ``sources.asgi.ByteHideMonitorASGI``.
- Django: the middleware is inserted at the top of ``settings.MIDDLEWARE`` when the request handler loads.

Opt out with ``protect(..., auto_integrate=False)`` to wire a framework adapter by hand instead. Best-effort and
fail-open: a framework that is absent or cannot be patched is skipped, never breaking app startup. Call
``protect()`` before the app is constructed (ideally at the very top of the entrypoint), since the hooks
instrument apps created afterwards; an app already built before ``protect()`` is not retro-instrumented.
"""

from __future__ import annotations

from typing import Any

from bytehide_monitor.core.logging.logger import MonitorLogger

_DJANGO_MIDDLEWARE = "bytehide_monitor.sources.django.ByteHideMonitorMiddleware"

_installed = False


def install() -> None:
    """Registers the framework import hooks. Idempotent; a no-op when wrapt is unavailable (manual wiring only)."""
    global _installed
    if _installed:
        return
    try:
        import wrapt
    except ImportError:
        return  # auto-integration needs wrapt (the `sinks` extra); without it, wire a framework adapter by hand
    _installed = True
    wrapt.register_post_import_hook(_instrument_flask, "flask")
    wrapt.register_post_import_hook(_instrument_starlette, "starlette.applications")
    # FastAPI subclasses Starlette but OVERRIDES build_middleware_stack, so patching only the
    # Starlette method misses FastAPI apps (its override shadows the patched parent). Patch the
    # FastAPI method too; the ASGI wrapper is idempotent (re-entrancy guard) if both fire.
    wrapt.register_post_import_hook(_instrument_fastapi, "fastapi.applications")
    wrapt.register_post_import_hook(_instrument_django, "django.core.handlers.base")
    MonitorLogger.info("I_AUTO_INTEGRATE", "Auto framework integration armed (flask, starlette/fastapi, django)")


def _safe_wrap(module: Any, name: str, wrapper: Any) -> None:
    """Wraps ``module.name`` with wrapt, skipping a framework variant that lacks the symbol."""
    import wrapt

    try:
        wrapt.wrap_function_wrapper(module, name, wrapper)
    except Exception:  # noqa: BLE001 - framework variant without this symbol; skip it
        pass


def _instrument_flask(module: Any) -> None:
    def _after_init(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
        result = wrapped(*args, **kwargs)
        try:
            from bytehide_monitor.sources.flask import ByteHideMonitor

            # init_app() is idempotent (it records state on app.extensions), so this is a
            # no-op if the app is later wired again by a manual ByteHideMonitor(app, ...).
            ByteHideMonitor(instance)
        except Exception:  # noqa: BLE001 - never break Flask app construction
            pass
        return result

    _safe_wrap(module, "Flask.__init__", _after_init)


def _chain_contains(node: Any, cls: type) -> bool:
    """True if ``cls`` appears anywhere along the ASGI ``.app`` middleware chain."""
    seen = 0
    while node is not None and seen < 40:
        if isinstance(node, cls):
            return True
        node = getattr(node, "app", None)
        seen += 1
    return False


def _after_build_middleware_stack(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Insert the ByteHide ASGI middleware just INSIDE the outer error layer of the built stack.

    ``build_middleware_stack()`` returns ``ServerErrorMiddleware(...)`` as the outermost layer.
    Wrapping that result from the outside would catch inbound attacks but let a SecurityException
    raised at an in-app sink reach ServerErrorMiddleware first - which turns it into a 500 instead
    of a 403. So we splice our middleware into ``stack.app`` (inside the error layer, like
    ``add_middleware`` does). Idempotent: if the app is already wired (manual middleware, or both
    the Starlette and FastAPI hooks firing), the chain already contains it and we leave it alone.
    """
    stack = wrapped(*args, **kwargs)
    try:
        from bytehide_monitor.sources.asgi import ByteHideMonitorASGI

        if _chain_contains(stack, ByteHideMonitorASGI):
            return stack
        inner = getattr(stack, "app", None)
        if inner is not None:
            stack.app = ByteHideMonitorASGI(inner)
            return stack
        return ByteHideMonitorASGI(stack)
    except Exception:  # noqa: BLE001 - never break ASGI app startup
        return stack


def _instrument_starlette(module: Any) -> None:
    _safe_wrap(module, "Starlette.build_middleware_stack", _after_build_middleware_stack)


def _instrument_fastapi(module: Any) -> None:
    _safe_wrap(module, "FastAPI.build_middleware_stack", _after_build_middleware_stack)


def _ensure_django_middleware(dj_settings: Any) -> None:
    """Inserts the ByteHide middleware at the top of ``settings.MIDDLEWARE`` (idempotent)."""
    middleware = list(getattr(dj_settings, "MIDDLEWARE", None) or [])
    if _DJANGO_MIDDLEWARE not in middleware:
        middleware.insert(0, _DJANGO_MIDDLEWARE)
        dj_settings.MIDDLEWARE = middleware


def _instrument_django(module: Any) -> None:
    def _before_load(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
        try:
            from django.conf import settings as dj_settings

            _ensure_django_middleware(dj_settings)
        except Exception:  # noqa: BLE001 - never break Django startup
            pass
        return wrapped(*args, **kwargs)

    _safe_wrap(module, "BaseHandler.load_middleware", _before_load)

"""Framework inbound integrations (Aikido sources)."""

"""Generic ASGI middleware (Starlette / FastAPI and any ASGI app).

Buffers the request body, builds a context, runs the inbound collector, and returns
an RFC 7807 block response on a block. Otherwise it replays the buffered body to the
wrapped app and records the response status. Relies on ``contextvars`` propagating the
request context into the awaited application coroutine within the same task.

Usage::

    import bytehide_monitor
    from bytehide_monitor.sources.asgi import ByteHideMonitorASGI

    runtime = bytehide_monitor.protect(token="...")
    app.add_middleware(ByteHideMonitorASGI, runtime=runtime)
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.response.response_xss import is_analyzable
from bytehide_monitor.cloud.runtime import CloudRuntime, get_active
from bytehide_monitor.core.protection.security_exception import SecurityException
from bytehide_monitor.sinks.orm import reset_request_state as reset_mass_assign_state
from bytehide_monitor.sources._common import (
    cookies_to_map,
    parse_body,
    query_to_map,
)

Scope = dict[str, Any]
Receive = Callable[[], Awaitable[dict[str, Any]]]
Send = Callable[[dict[str, Any]], Awaitable[None]]


class ByteHideMonitorASGI:
    def __init__(self, app: Any, runtime: CloudRuntime | None = None) -> None:
        self.app = app
        self._runtime = runtime

    def _resolve_runtime(self) -> CloudRuntime | None:
        return self._runtime or get_active()

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        runtime = self._resolve_runtime()
        if scope.get("type") != "http" or runtime is None or not runtime.enabled:
            await self.app(scope, receive, send)
            return
        # Re-entrancy guard: if an outer ByteHide layer already handled this request (e.g. auto-integration plus
        # manual wiring), pass straight through so the request is never scanned twice.
        if scope.get("bytehide.seen"):
            await self.app(scope, receive, send)
            return
        scope["bytehide.seen"] = True

        body, replay_receive = await _buffer_body(receive)
        context = _build_context(scope, body)
        reset_mass_assign_state()  # fresh per-request mass-assignment allowlist
        try:
            decision = runtime.web_request.report(context)
            if decision is not None:
                await _send_block(runtime, decision, context, send)
                return
            await self._run_app(runtime, scope, context, replay_receive, send)
        finally:
            runtime.web_request.clear()
            reset_mass_assign_state()

    async def _run_app(
        self, runtime: CloudRuntime, scope: Scope, context: ContextObject, receive: Receive, send: Send
    ) -> None:
        buf = _ResponseBuffer(runtime, context, send)
        try:
            await self.app(scope, receive, buf.send)
        except SecurityException as exc:
            if buf.committed:
                raise
            runtime.report_sink_incident(exc.decision)
            await _send_block(runtime, exc.decision, context, send)
            return
        await buf.finish()
        try:
            runtime.web_response.report(buf.status_code)
        except Exception:  # noqa: BLE001
            pass


class _ResponseBuffer:
    """Buffers an ASGI response so its body can be analyzed for reflected XSS.

    Textual 2xx responses are held until complete, then scanned: a reflected XSS payload
    swaps the response for a 403. Non-textual or non-2xx responses stream through
    untouched (no buffering).
    """

    def __init__(self, runtime: CloudRuntime, context: ContextObject, send: Send) -> None:
        self._runtime = runtime
        self._context = context
        self._send = send
        self._start: dict[str, Any] | None = None
        self._chunks: list[bytes] = []
        self._passthrough = False
        self.committed = False
        self.status_code = 200
        self._content_type: str | None = None

    async def send(self, message: dict[str, Any]) -> None:
        mtype = message.get("type")
        if mtype == "http.response.start":
            self.status_code = int(message.get("status", 200))
            self._content_type = _header_value(message.get("headers") or [], b"content-type")
            self._passthrough = not is_analyzable(self._content_type) or not (
                200 <= self.status_code < 300
            )
            if self._passthrough:
                self.committed = True
                await self._send(message)
            else:
                self._start = message
            return

        if mtype == "http.response.body":
            if self._passthrough:
                await self._send(message)
                return
            self._chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                await self._flush()
            return

        await self._send(message)

    async def _flush(self) -> None:
        if self.committed or self._start is None:
            return
        body = b"".join(self._chunks)
        decision = self._runtime.scan_response(
            body.decode("utf-8", "replace"), self._content_type, self.status_code
        )
        if decision is not None:
            self._runtime.report_sink_incident(decision)
            if decision.blocked:
                self.committed = True
                await _send_block(self._runtime, decision, self._context, self._send)
                return
        self.committed = True
        await self._send(self._start)
        await self._send({"type": "http.response.body", "body": body})

    async def finish(self) -> None:
        if not self.committed and self._start is not None:
            await self._flush()


def _header_value(headers: list[tuple[bytes, bytes]], name: bytes) -> str | None:
    lowered = name.lower()
    for key, value in headers:
        if key.lower() == lowered:
            return value.decode("latin-1")
    return None


async def _buffer_body(receive: Receive) -> tuple[bytes, Receive]:
    chunks: list[bytes] = []
    more = True
    messages: list[dict[str, Any]] = []
    while more:
        message = await receive()
        messages.append(message)
        if message.get("type") == "http.request":
            chunks.append(message.get("body", b""))
            more = message.get("more_body", False)
        else:
            more = False
    body = b"".join(chunks)

    delivered = {"done": False}

    async def replay() -> dict[str, Any]:
        if not delivered["done"]:
            delivered["done"] = True
            return {"type": "http.request", "body": body, "more_body": False}
        return await receive()

    return body, replay


def _build_context(scope: Scope, body: bytes) -> ContextObject:
    headers = _headers_to_map(scope.get("headers") or [])
    client = scope.get("client")
    remote = client[0] if isinstance(client, (list, tuple)) and client else None
    query_string = (scope.get("query_string") or b"").decode("latin-1")
    return ContextObject(
        method=scope.get("method"),
        url=_build_url(scope),
        route=scope.get("path"),
        remote_address=remote,
        headers=headers,
        query=query_to_map(query_string),
        cookies=cookies_to_map(headers.get("Cookie")),
        body=parse_body(body, headers.get("Content-Type")),
    )


def _headers_to_map(raw_headers: list[tuple[bytes, bytes]]) -> dict[str, str]:
    headers: dict[str, str] = {}
    for key, value in raw_headers:
        name = key.decode("latin-1").title()
        headers[name] = value.decode("latin-1")
    return headers


def _build_url(scope: Scope) -> str:
    scheme = scope.get("scheme", "http")
    headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in (scope.get("headers") or [])}
    host = headers.get("host", "")
    path = scope.get("path", "")
    query = (scope.get("query_string") or b"").decode("latin-1")
    url = f"{scheme}://{host}{path}"
    return f"{url}?{query}" if query else url


async def _send_block(
    runtime: CloudRuntime, decision: Any, context: ContextObject, send: Send
) -> None:
    problem = runtime.build_block_response(decision, context.route)
    body = problem.to_json().encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": decision.http_status,
            "headers": [
                (b"content-type", problem.CONTENT_TYPE.encode("latin-1")),
                (b"content-length", str(len(body)).encode("latin-1")),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})

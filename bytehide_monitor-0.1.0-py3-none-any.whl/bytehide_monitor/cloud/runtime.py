"""Cloud runtime: composition root and lifecycle for the in-process engine.

Builds the engine and all collectors from a resolved configuration, optionally starts
background reporting, and exposes the per-request entry points used by the framework
source adapters. One active runtime is tracked at module level so adapters and sink
wrappers can resolve it without threading it through every call.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.collectors.command_collector import CommandCollector
from bytehide_monitor.cloud.collectors.deserialization_collector import DeserializationCollector
from bytehide_monitor.cloud.collectors.file_collector import FileCollector
from bytehide_monitor.cloud.collectors.ldap_collector import LdapCollector
from bytehide_monitor.cloud.collectors.open_redirect_collector import OpenRedirectCollector
from bytehide_monitor.cloud.collectors.response_splitting_collector import ResponseSplittingCollector
from bytehide_monitor.cloud.collectors.template_collector import TemplateCollector
from bytehide_monitor.cloud.collectors.nosql_collector import NoSqlCollector
from bytehide_monitor.cloud.collectors.sql_collector import SqlCollector
from bytehide_monitor.cloud.collectors.url_collector import UrlCollector
from bytehide_monitor.cloud.collectors.web_request_collector import WebRequestCollector
from bytehide_monitor.cloud.collectors.web_response_collector import WebResponseCollector
from bytehide_monitor.cloud.collectors.xml_collector import XmlCollector
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.response import block_response_builder
from bytehide_monitor.cloud.response.problem_details import ProblemDetails
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.cloud.session import cloud_session_context
from bytehide_monitor.core.logging.logger import MonitorLogger

_active_lock = threading.Lock()
_active: CloudRuntime | None = None


class CloudRuntime:
    def __init__(self, config: CloudMonitorConfig) -> None:
        self.config = config
        self.engine = CloudEngine.create(config)
        self.web_request = WebRequestCollector(self.engine)
        self.web_response = WebResponseCollector(self.engine)
        self.sql = SqlCollector(self.engine)
        self.command = CommandCollector(self.engine)
        self.file = FileCollector(self.engine)
        self.url = UrlCollector(self.engine)
        self.ldap = LdapCollector(self.engine)
        self.nosql = NoSqlCollector(self.engine)
        self.xml = XmlCollector(self.engine)
        self.template = TemplateCollector(self.engine)
        self.deserialization = DeserializationCollector(self.engine)
        self.redirect = OpenRedirectCollector(self.engine)
        self.response_splitting = ResponseSplittingCollector(self.engine)
        self._reporter: Any = None
        self._shutdown_hooks: list[Callable[[], None]] = []
        self._shutdown_done = False

    @property
    def enabled(self) -> bool:
        return self.config.enabled

    @property
    def debug_responses(self) -> bool:
        return self.config.debug_responses

    def build_block_response(
        self, decision: BlockDecision, instance: str | None
    ) -> ProblemDetails:
        return block_response_builder.build(decision, instance, self.config.debug_responses)

    def scan_response(
        self,
        response_text: str | None,
        content_type: str | None,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
    ) -> BlockDecision | None:
        """Response-level analysis of an outgoing response for the current request context.

        Runs two independent passes, in order, over the same captured response so the existing
        reflected-XSS behavior is preserved exactly:

        1. Reflected-XSS analysis (unchanged: ``response_xss.scan``).
        2. Response-level detectors (data-exposure / sensitive-data leak) via the generic
           ``Scanner.scan_response`` seam, wrapped in fail-open guards.

        The first decision found (XSS first, then response-level) is returned, matching how the
        sources already consume a single :class:`BlockDecision` from this method. The seam is the
        same point every source adapter already calls, so no ``sources/*`` adapter changes.
        """
        from bytehide_monitor.cloud.response import response_xss

        context = context_holder.get()
        xss_decision = response_xss.scan(
            self.engine, context, response_text, content_type, status_code
        )
        if xss_decision is not None:
            return xss_decision

        # Response-level detector pass (fail-open end to end). Reuse the response the source
        # already captured as a minimal ResponseView (status, headers, body).
        try:
            from bytehide_monitor.cloud.detectors.detector import ResponseView

            response = ResponseView(
                status_code=status_code, headers=headers, body=response_text
            )
            return self.engine.scanner.scan_response(
                context, response, self.engine.config, self.engine.protections
            )
        except Exception:  # noqa: BLE001 - response-level scan must never break the response
            return None

    def report_sink_incident(self, decision: BlockDecision) -> None:
        """Report an incident for a detection found off the inbound request path.

        Covers in-app sink detections (SQL/LDAP/XXE/... via ``SecurityException``) and
        reflected XSS found during response analysis. Inbound detections are reported by
        the request collector's block listener instead. A blocking decision also blocks
        the originating session (mirroring the inbound path); a ``log``/``none`` detection
        only reports the incident. Fire-and-forget, fail-safe.
        """
        session = cloud_session_context.current()
        # Block the originating session only when the action enforces a block.
        if session is not None and decision.blocked:
            try:
                self.engine.session_manager.block_session(session.session_id, decision.reason)
            except Exception:  # noqa: BLE001
                pass
        reporter = self._reporter
        if reporter is None:
            return
        try:
            from bytehide_monitor.cloud.reporting import incident_factory
            from bytehide_monitor.core.platform.machine_id import get_machine_id

            context = context_holder.get()
            reporter.report_incident(
                incident_factory.build(decision, session, context, get_machine_id())
            )
        except Exception:  # noqa: BLE001 - reporting must never break the request
            pass

    def start_reporting(self) -> None:
        """Start background device registration, heartbeat and incident reporting."""
        from bytehide_monitor.cloud.reporting import reporting_bootstrap

        self._reporter = reporting_bootstrap.start(self.engine, self.web_request, self.config)

    def on_shutdown(self, hook: Callable[[], None]) -> None:
        self._shutdown_hooks.append(hook)

    def shutdown(self) -> None:
        if self._shutdown_done:
            return
        self._shutdown_done = True
        if self._reporter is not None:
            try:
                self._reporter.shutdown()
            except Exception:  # noqa: BLE001
                pass
        for hook in self._shutdown_hooks:
            try:
                hook()
            except Exception:  # noqa: BLE001
                pass
        MonitorLogger.info("RT_STOP", "Cloud runtime shut down")


def set_active(runtime: CloudRuntime) -> None:
    global _active
    with _active_lock:
        _active = runtime


def get_active() -> CloudRuntime | None:
    return _active


def clear_active() -> None:
    global _active
    with _active_lock:
        _active = None

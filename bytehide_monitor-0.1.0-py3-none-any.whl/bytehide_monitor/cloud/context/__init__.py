"""Per-request context model and holder."""

"""Flattens all user-controlled parts of a request into an ordered map.

Source paths are prefixed by origin so the scanner and incident reporter can point
at the exact location of a payload:
- query parameters -> ``query.<name>``
- request body     -> ``body.<path>`` (objects/arrays flattened recursively)
- headers          -> ``header.<name>``
- cookies          -> ``cookie.<name>``
- path parameters  -> ``path.<name>``

Insertion order is preserved (query, body, headers, cookies, path). Empty and
whitespace-only values are skipped.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from bytehide_monitor.cloud.context.context_object import ContextObject


def extract(context: ContextObject | None) -> dict[str, str]:
    """Flatten every user input (query, body, headers, cookies, path params).

    Used for sink attribution: a sink value (SQL query, command, path, URL) is checked
    against ALL request inputs, including headers and cookies, so an injection sourced
    from any of them is caught at the operation.
    """
    inputs: dict[str, str] = {}
    if context is None:
        return inputs
    _add_string_map(inputs, "query", context.query)
    _add_body(inputs, "body", context.body)
    _add_string_map(inputs, "header", context.headers)
    _add_string_map(inputs, "cookie", context.cookies)
    _add_string_map(inputs, "path", context.path_params)
    return inputs


def extract_inbound(context: ContextObject | None) -> dict[str, str]:
    """Flatten only the inbound-scan inputs (query, body, path params).

    Headers and cookies are intentionally excluded from the blanket inbound detector
    scan: this mirrors the .NET HTTP-level detection (which inspects query string, form
    data and the URL path) and avoids false positives from benign header values that
    legitimately contain shell/LDAP metacharacters (e.g. ``Accept: */*``,
    ``Accept-Encoding: gzip, deflate``). Headers and cookies are still inspected for
    attribution at in-app sinks via :func:`extract`.
    """
    inputs: dict[str, str] = {}
    if context is None:
        return inputs
    _add_string_map(inputs, "query", context.query)
    _add_body(inputs, "body", context.body)
    _add_string_map(inputs, "path", context.path_params)
    return inputs


def _add_string_map(inputs: dict[str, str], prefix: str, source: Mapping[str, str] | None) -> None:
    if not source:
        return
    for key, value in source.items():
        if key is None:
            continue
        _put(inputs, f"{prefix}.{key}", value)


def _add_body(inputs: dict[str, str], prefix: str, body: Any) -> None:
    if body is None:
        return
    if isinstance(body, str):
        _put(inputs, prefix, body)
        return
    _flatten(inputs, prefix, body)


def _flatten(inputs: dict[str, str], prefix: str, value: Any) -> None:
    if value is None:
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key is None:
                continue
            _flatten(inputs, f"{prefix}.{key}", item)
        return
    if isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _flatten(inputs, f"{prefix}[{index}]", item)
        return
    _put(inputs, prefix, _to_str(value))


def _to_str(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _put(inputs: dict[str, str], path: str, value: Any) -> None:
    if value is None:
        return
    text = value if isinstance(value, str) else _to_str(value)
    if not text or not text.strip():
        return
    inputs[path] = text

"""Framework-agnostic model of a single inbound HTTP request.

Source adapters build a ``ContextObject`` from their native request types and publish
it on the request-scoped :class:`~bytehide_monitor.cloud.context.context.Context`.
Flattened user inputs are computed lazily on first access and cached, since the
scanner walks them once per request.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from bytehide_monitor.cloud.context import user_input_extractor
from bytehide_monitor.cloud.context.route_metadata import RouteMetadata
from bytehide_monitor.cloud.context.user import User


class ContextObject:
    def __init__(
        self,
        method: str | None = None,
        url: str | None = None,
        route: str | None = None,
        remote_address: str | None = None,
        headers: Mapping[str, str] | None = None,
        query: Mapping[str, str] | None = None,
        cookies: Mapping[str, str] | None = None,
        path_params: Mapping[str, str] | None = None,
        body: Any = None,
        user: User | None = None,
    ) -> None:
        self.method = method
        self.url = url
        self.route = route
        self.remote_address = remote_address
        self._client_ip: str | None = None
        self.headers = headers
        self.query = query
        self.cookies = cookies
        self.path_params = path_params
        self.body = body
        self.user = user
        self._cached_user_inputs: dict[str, str] | None = None
        self._cached_inbound_inputs: dict[str, str] | None = None

    @property
    def client_ip(self) -> str | None:
        """Resolved real client IP (proxy-aware); falls back to the remote address."""
        return self._client_ip if self._client_ip is not None else self.remote_address

    @client_ip.setter
    def client_ip(self, value: str | None) -> None:
        self._client_ip = value

    def get_header(self, name: str) -> str | None:
        """Case-insensitive header lookup; returns the first matching value."""
        if not self.headers or name is None:
            return None
        lowered = name.lower()
        for key, value in self.headers.items():
            if key is not None and key.lower() == lowered:
                return value
        return None

    def get_user_inputs(self) -> dict[str, str]:
        """Ordered, cached map of ALL user inputs (incl. headers/cookies) for sink scans."""
        if self._cached_user_inputs is None:
            self._cached_user_inputs = dict(user_input_extractor.extract(self))
        return self._cached_user_inputs

    def get_inbound_inputs(self) -> dict[str, str]:
        """Ordered, cached map of inbound-scan inputs (query, body, path; no headers/cookies)."""
        if self._cached_inbound_inputs is None:
            self._cached_inbound_inputs = dict(user_input_extractor.extract_inbound(self))
        return self._cached_inbound_inputs

    def invalidate_user_inputs(self) -> None:
        """Clear the cached user-input maps (call after mutating a contributing field)."""
        self._cached_user_inputs = None
        self._cached_inbound_inputs = None

    def get_route_metadata(self) -> RouteMetadata:
        return RouteMetadata(self.method, self.route, self.url)

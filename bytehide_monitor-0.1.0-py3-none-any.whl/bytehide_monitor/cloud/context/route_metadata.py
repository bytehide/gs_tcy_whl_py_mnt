"""Immutable route descriptor: HTTP method, route template and concrete URL."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RouteMetadata:
    method: str | None
    route: str | None
    url: str | None

"""Per-request holder for the current :class:`ContextObject`.

Backed by a :class:`contextvars.ContextVar` so it is correct under both WSGI (sync
threads) and ASGI (async tasks) - the Python equivalent of the .NET ``AsyncLocal``
and Java ``ThreadLocal`` request context. Source adapters call :func:`set` at the
start of a request and :func:`reset` in a ``finally`` block; sink collectors read
:func:`get` to access the originating request's user inputs.
"""

from __future__ import annotations

import contextvars

from bytehide_monitor.cloud.context.context_object import ContextObject

_CURRENT: contextvars.ContextVar[ContextObject | None] = contextvars.ContextVar(
    "bytehide_monitor_context", default=None
)


def get() -> ContextObject | None:
    """Return the context bound to the current execution, or ``None``."""
    return _CURRENT.get()


def set(context: ContextObject | None) -> contextvars.Token:
    """Bind ``context`` to the current execution; returns a token for :func:`reset`."""
    return _CURRENT.set(context)


def reset(token: contextvars.Token | None = None) -> None:
    """Clear the bound context. Pass the token from :func:`set` for precise restore."""
    if token is not None:
        _CURRENT.reset(token)
    else:
        _CURRENT.set(None)

"""Authenticated end user associated with a request.

When present, the user id is folded into the cloud session identity so the same
browser/IP tracked anonymously becomes a distinct, user-bound session after login.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class User:
    id: str | None = None
    name: str | None = None

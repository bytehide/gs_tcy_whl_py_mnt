"""Background cloud reporting bridge.

Reuses the core :class:`MonitorApiClient` as transport and the core
:class:`IncidentQueue` for offline-first incident delivery. Registers the device and
applies the returned config, sends incremental heartbeats on a daemon thread at the
backend interval (applying config/firewall changes and resetting counters after
success), reports incidents fire-and-forget (queueing on failure), and flushes plus
sends a final heartbeat on shutdown.

All background work runs on daemon threads. Offline mode is honored through the API
client, which short-circuits network calls.
"""

from __future__ import annotations

import os
import threading
from concurrent.futures import ThreadPoolExecutor

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.reporting import config_applier, heartbeat_payload_factory
from bytehide_monitor.core.helpers.datetime import now_unix_ms
from bytehide_monitor.core.http.api_client import MonitorApiClient
from bytehide_monitor.core.incident.incident_queue import IncidentQueue, get_instance
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.platform.application_info_provider import (
    get_agent_info,
    get_application_info,
    get_monitor_version,
)
from bytehide_monitor.core.platform.device_info_provider import collect_device
from bytehide_monitor.core.platform.machine_id import get_machine_id
from bytehide_monitor.models.requests.device_registration import DeviceRegistrationRequest
from bytehide_monitor.models.requests.incident_report import IncidentReportRequest
from bytehide_monitor.models.responses.device_registration import DeviceRegistrationResponse
from bytehide_monitor.models.responses.heartbeat import HeartbeatResponse

_DEFAULT_HEARTBEAT_INTERVAL_MS = 60000
# Optional env override of the heartbeat cadence (ms). Takes precedence over the backend-provided
# interval - intended for demos/PoCs where faster dashboard->runtime rule propagation is wanted.
# Floored at 5s so a tiny value cannot hammer the backend. Unset -> backend interval, else 60s.
_HEARTBEAT_ENV = "BYTEHIDE_HEARTBEAT_MS"
_MIN_HEARTBEAT_INTERVAL_MS = 5000


def _env_heartbeat_interval_ms() -> int | None:
    raw = os.environ.get(_HEARTBEAT_ENV, "").strip()
    if not raw:
        return None
    try:
        value = int(raw)
    except (ValueError, TypeError):
        return None
    if value <= 0:
        return None
    return max(value, _MIN_HEARTBEAT_INTERVAL_MS)


class CloudReporter:
    def __init__(self, api_client: MonitorApiClient, incident_queue: IncidentQueue | None = None) -> None:
        if api_client is None:
            raise ValueError("api_client must not be None")
        self._api_client = api_client
        self._incident_queue = incident_queue or get_instance()
        self._started = False
        self._start_lock = threading.Lock()
        self._stop_event = threading.Event()
        self._stats_window_start = now_unix_ms()
        self._last_config_updated_at = 0
        self._engine: CloudEngine | None = None
        self._machine_id: str | None = None
        self._heartbeat_thread: threading.Thread | None = None
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ByteHide-Incident")

    def start(self, engine: CloudEngine, config: CloudMonitorConfig) -> None:
        if engine is None or config is None:
            raise ValueError("engine and config must not be None")
        with self._start_lock:
            if self._started:
                return
            self._started = True
        self._engine = engine
        self._machine_id = get_machine_id()
        self._register_device(config)
        self._start_heartbeat_thread()
        self._register_fork_handler()

    def _register_fork_handler(self) -> None:
        """Restart the heartbeat in forked children (gunicorn/uwsgi prefork workers).

        Auto-start runs ``protect()`` at interpreter start - i.e. in the gunicorn MASTER, before it
        forks its workers. Threads do not survive ``fork``, so each worker would inherit a frozen
        config snapshot and never heartbeat again (a dashboard block->log change would never reach the
        process actually serving traffic). Re-create the background threads in every child so each
        worker syncs config and flushes incidents on its own."""
        if getattr(self, "_fork_registered", False) or not hasattr(os, "register_at_fork"):
            return
        self._fork_registered = True
        try:
            os.register_at_fork(after_in_child=self._reinit_after_fork)
        except Exception:  # noqa: BLE001 - fork hook registration must never break startup
            pass

    def _reinit_after_fork(self) -> None:
        # Runs in the child right after fork. The inherited thread/executor are dead here; rebuild
        # them and force the first child heartbeat to re-apply config (last-seen ts reset to 0).
        try:
            self._stop_event = threading.Event()
            self._heartbeat_thread = None
            self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ByteHide-Incident")
            self._last_config_updated_at = 0
            self._stats_window_start = now_unix_ms()
            self._start_heartbeat_thread()
        except Exception:  # noqa: BLE001 - a failed child re-init must never break the worker
            pass

    def _register_device(self, config: CloudMonitorConfig) -> None:
        try:
            request = DeviceRegistrationRequest(
                machine_id=self._machine_id,
                device=collect_device(),
                application=get_application_info(
                    config.name or "bytehide-monitor-python", get_monitor_version()
                ),
                agent=get_agent_info(),
            )
            response = self._api_client.register_device(request)
            if response.is_success and isinstance(response.data, dict):
                data = response.data_as(DeviceRegistrationResponse)
                if data is not None:
                    self._apply_device_block(data.blocked, data.reason)
                    config_applier.apply(self._engine, data.config)
                    if data.config_updated_at is not None:
                        self._last_config_updated_at = data.config_updated_at
                MonitorLogger.info("CR_DEVICE_OK", "Cloud device registered")
            else:
                MonitorLogger.warning("CR_DEVICE_FAIL", "Device registration did not return config")
        except Exception as exc:  # noqa: BLE001 - registration failure is non-fatal
            MonitorLogger.error("CR_DEVICE_ERR", f"Device registration error: {exc}")

    def _start_heartbeat_thread(self) -> None:
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop, name="ByteHide-CloudReporter", daemon=True
        )
        self._heartbeat_thread.start()
        MonitorLogger.info("CR_HB_START", "Cloud heartbeat thread started")

    def _heartbeat_loop(self) -> None:
        # First heartbeat is sent immediately (not after a full interval): device registration only returns the
        # desktop plugin config, so the real web ``modules`` rules come from /heartbeat. Running it here on the
        # daemon thread (rather than synchronously in start()) means a dead/slow backend never delays app startup;
        # until it lands the SDK protects with the local cloud preset.
        self._send_heartbeat()
        while not self._stop_event.is_set():
            interval_ms = self._current_interval_ms()
            # Wait the interval (interruptible on shutdown); send when the wait times out.
            if self._stop_event.wait(interval_ms / 1000.0):
                break
            self._send_heartbeat()

    def _current_interval_ms(self) -> int:
        # Env override wins (demo/PoC), then the backend-provided interval, then the 60s default.
        env_interval = _env_heartbeat_interval_ms()
        if env_interval is not None:
            return env_interval
        if self._engine is not None and self._engine.heartbeat_interval_ms > 0:
            return self._engine.heartbeat_interval_ms
        return _DEFAULT_HEARTBEAT_INTERVAL_MS

    def _send_heartbeat(self) -> None:
        if self._engine is None:
            return
        try:
            request = heartbeat_payload_factory.build(
                self._engine.session_manager,
                self._engine.statistics,
                self._machine_id or "",
                self._stats_window_start,
            )
            response = self._api_client.send_heartbeat(request)
            if response.is_success:
                if isinstance(response.data, dict):
                    self._apply_heartbeat_response(response.data_as(HeartbeatResponse))
                self._reset_counters_after_send()
                MonitorLogger.debug("CR_HB_OK", "Cloud heartbeat acknowledged")
            else:
                MonitorLogger.warning("CR_HB_FAIL", "Cloud heartbeat failed - retaining stats")
        except Exception as exc:  # noqa: BLE001
            MonitorLogger.error("CR_HB_ERR", f"Cloud heartbeat error: {exc}")

    def _apply_device_block(self, blocked: bool | None, reason: str | None) -> None:
        """Disable protection when the backend reports this device/license as blocked."""
        if blocked and self._engine is not None and self._engine.config is not None:
            MonitorLogger.critical(
                "C008_LICENSE_REVOKED", f"Device blocked by backend: {reason or 'no reason given'}"
            )
            self._engine.config.enabled = False

    def _apply_heartbeat_response(self, data: HeartbeatResponse | None) -> None:
        if data is None:
            return
        self._apply_device_block(data.blocked, data.blocked_reason)
        if data.firewall is not None:
            config_applier.apply_firewall(self._engine, data.firewall)
        newer = data.config_updated_at is not None and data.config_updated_at > self._last_config_updated_at
        if data.config is not None and (newer or data.config_updated_at is None):
            config_applier.apply(self._engine, data.config)
        if data.config_updated_at is not None:
            self._last_config_updated_at = data.config_updated_at

    def _reset_counters_after_send(self) -> None:
        if self._engine is None:
            return
        self._engine.statistics.reset()
        self._engine.session_manager.reset_counters_after_heartbeat()
        self._stats_window_start = now_unix_ms()

    def report_incident(self, request: IncidentReportRequest | None) -> None:
        if request is None:
            return
        try:
            self._executor.submit(self._send_incident, request)
        except RuntimeError:
            # Executor already shut down: queue for the next run.
            self._incident_queue.enqueue(request)

    def _send_incident(self, request: IncidentReportRequest) -> None:
        try:
            response = self._api_client.report_incident(request)
            if not response.is_success:
                self._incident_queue.enqueue(request)
                MonitorLogger.debug("CR_INC_QUEUE", "Incident queued for retry")
            else:
                MonitorLogger.debug("CR_INC_OK", "Incident reported")
        except Exception as exc:  # noqa: BLE001
            self._incident_queue.enqueue(request)
            MonitorLogger.warning("CR_INC_ERR", f"Incident send error - queued: {exc}")

    def flush_incident_queue(self) -> int:
        sent = 0
        while not self._incident_queue.is_empty():
            queued = self._incident_queue.peek()
            if queued is None:
                break
            try:
                response = self._api_client.report_incident(queued)
                if response.is_success:
                    self._incident_queue.dequeue()
                    sent += 1
                else:
                    break
            except Exception as exc:  # noqa: BLE001
                MonitorLogger.warning("CR_FLUSH_ERR", f"Incident flush error: {exc}")
                break
        return sent

    def shutdown(self) -> None:
        with self._start_lock:
            if not self._started:
                return
            self._started = False
        self._stop_event.set()
        try:
            self.flush_incident_queue()
            self._send_heartbeat()
        except Exception as exc:  # noqa: BLE001
            MonitorLogger.debug("CR_SHUTDOWN", f"Shutdown flush error: {exc}")
        self._executor.shutdown(wait=False)
        thread = self._heartbeat_thread
        if thread is not None:
            thread.join(timeout=5)
        MonitorLogger.info("CR_STOP", "Cloud reporter stopped")

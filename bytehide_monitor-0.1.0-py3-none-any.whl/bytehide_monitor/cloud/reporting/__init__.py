"""Cloud backend reporting bridge."""

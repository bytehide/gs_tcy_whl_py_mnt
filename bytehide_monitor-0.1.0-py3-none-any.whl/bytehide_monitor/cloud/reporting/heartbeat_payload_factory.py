"""Builds the cloud heartbeat request from session/statistics stores.

Stats and the sessions array are incremental: only sessions with activity since the
last heartbeat are included; counters are reset by the caller after a successful send.
Route activity travels per session only (1:1 with the .NET ``BuildCloudHeartbeat``
wire shape; there is no aggregated top-level routes array).
Pure: produces a request, performs no I/O.
"""

from __future__ import annotations

from bytehide_monitor.cloud.session.cloud_session import CloudSession
from bytehide_monitor.cloud.session.cloud_session_manager import CloudSessionManager
from bytehide_monitor.cloud.statistics.statistics_store import StatisticsSnapshot, StatisticsStore
from bytehide_monitor.core.helpers.datetime import now_unix_ms
from bytehide_monitor.core.platform.application_info_provider import get_agent_info
from bytehide_monitor.models.requests.heartbeat import (
    CloudSessionDetail,
    HeartbeatRequest,
    HeartbeatStats,
    IncidentStats,
    ModuleStats,
    RequestStats,
    RouteHit,
)


def build(
    session_manager: CloudSessionManager,
    statistics: StatisticsStore,
    machine_id: str,
    stats_started_at: int,
) -> HeartbeatRequest:
    now = now_unix_ms()
    active = session_manager.snapshot_for_heartbeat()
    snapshot = statistics.snapshot()
    return HeartbeatRequest(
        type="heartbeat",
        time=now,
        machine_id=machine_id,
        sessions=_build_sessions(active),
        stats=_build_stats(snapshot, stats_started_at, now),
        agent=get_agent_info(),
    )


def _build_sessions(sessions: list[CloudSession]) -> list[CloudSessionDetail]:
    details: list[CloudSessionDetail] = []
    for session in sessions:
        details.append(
            CloudSessionDetail(
                session_id=session.session_id,
                ip=session.ip,
                user_agent=session.user_agent,
                user_id=session.user_id,
                user_name=session.user_name,
                started_at=session.started_at,
                last_activity_at=session.last_activity_at,
                total_requests=session.total_requests,
                blocked=session.is_blocked,
                block_reason=session.block_reason,
                routes=_build_session_routes(session.top_routes()),
            )
        )
    return details


def _build_session_routes(top_routes: dict[str, int]) -> list[RouteHit]:
    hits: list[RouteHit] = []
    for key, count in top_routes.items():
        space = key.find(" ")
        method = key[:space] if space > 0 else "UNKNOWN"
        route = key[space + 1 :] if space > 0 else key
        hits.append(RouteHit(method=method, route=route, hits=count))
    hits.sort(key=lambda h: h.hits or 0, reverse=True)
    return hits


def _build_stats(snapshot: StatisticsSnapshot, started_at: int, ended_at: int) -> HeartbeatStats:
    return HeartbeatStats(
        started_at=started_at,
        ended_at=ended_at,
        requests=RequestStats(
            total=snapshot.requests_total,
            blocked=snapshot.requests_blocked,
            successful=snapshot.requests_successful,
        ),
        incidents=IncidentStats(
            total=snapshot.incidents_total,
            blocked=snapshot.incidents_blocked,
            by_module={m.value: c for m, c in snapshot.incidents_by_module.items()},
        ),
        modules=_build_module_stats(snapshot),
    )


def _build_module_stats(snapshot: StatisticsSnapshot) -> list[ModuleStats]:
    detections = snapshot.module_detections
    return [
        ModuleStats(
            type=module.value,
            executions=executions,
            detections=detections.get(module, 0),
            compressed_timings=None,
        )
        for module, executions in snapshot.module_executions.items()
    ]

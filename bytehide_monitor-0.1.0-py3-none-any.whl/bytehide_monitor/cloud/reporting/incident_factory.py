"""Builds a cloud incident report from a block decision, session and context.

Fills the incident block (module_type, level, blocked, action, payload, metadata,
stack), the cloud session block and the ``platform = "web"`` context. Pure: no I/O.

Incidents are only ever built from detector/sink matches, so ``decision.module`` is
always set and ``module_type`` is the detector enum value (matching .NET's
``moduleType.ToString()``). Firewall, session-blocked, rate-limit and anomaly blocks
are not reported as incidents.
"""

from __future__ import annotations

import uuid

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.cloud.session.cloud_session import CloudSession
from bytehide_monitor.core.helpers.datetime import now_unix_ms
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.models.incident import Incident
from bytehide_monitor.models.requests.incident_report import (
    IncidentContext,
    IncidentReportRequest,
    IncidentSession,
)

PLATFORM_WEB = "web"


def build(
    decision: BlockDecision,
    session: CloudSession | None,
    context: ContextObject | None,
    machine_id: str,
) -> IncidentReportRequest:
    if decision is None:
        raise ValueError("decision must not be None")

    now = now_unix_ms()
    result = decision.result
    module = decision.module

    incident = Incident(
        incident_id=str(uuid.uuid4()),
        module_type=module.value if module is not None else None,
        level=_level(decision),
        blocked=decision.blocked,
        action=decision.action,
        payload=_payload(result, decision.reason),
        metadata=result.metadata if result is not None else None,
        stack=_stack(result, context),
    )

    session_info = _build_session(session, context, now)
    return IncidentReportRequest(
        type="detected_incident",
        time=now,
        machine_id=machine_id,
        incident=incident,
        session=session_info,
        # The origin IP is also surfaced on the context block so the dashboard's
        # "Origin Information" shows it for web incidents (where the .NET cloud builder
        # otherwise leaves context.ip null). Local addresses (e.g. 127.0.0.1) are kept.
        context=IncidentContext(platform=PLATFORM_WEB, ip=_origin_ip(session_info, context)),
    )


def _origin_ip(session_info: IncidentSession, context: ContextObject | None) -> str | None:
    if session_info.ip is not None:
        return session_info.ip
    return context.client_ip if context is not None else None


def _build_session(
    session: CloudSession | None, context: ContextObject | None, now: int
) -> IncidentSession:
    if session is not None:
        info = IncidentSession(
            session_id=session.session_id,
            ip=session.ip,
            user_agent=session.user_agent,
            user_id=session.user_id,
            user_name=session.user_name,
            started_at=session.started_at,
            last_activity_at=now,
            total_requests=session.total_requests,
            method=session.last_method,
            url=session.last_url,
            route=session.last_route,
        )
        if context is not None:
            if info.method is None:
                info.method = context.method
            if info.url is None:
                info.url = context.url
            if info.route is None:
                info.route = context.route
        return info

    if context is not None:
        return IncidentSession(
            ip=context.client_ip,
            user_agent=context.get_header("User-Agent"),
            started_at=now,
            last_activity_at=now,
            total_requests=0,
            method=context.method,
            url=context.url,
            route=context.route,
        )

    return IncidentSession(
        session_id="offline_detection",
        ip="0.0.0.0",
        user_agent="Background Protection Module",
        started_at=now,
        last_activity_at=now,
        total_requests=0,
        method="BACKGROUND",
        url="background_detection",
        route="background",
    )


def _stack(result: DetectionResult | None, context: ContextObject | None) -> list[str] | None:
    """The sanitized application stack, or a synthesized request-location frame for inbound hits.

    Sink detections (SQL, command, path, LDAP, NoSQL) carry a real application stack. Inbound
    detections (XSS, XXE, SSRF, LLM) are caught in the middleware before any application frame
    runs, so the captured stack is empty; synthesize a single frame from the request so the
    dashboard still shows where the request was caught.
    """
    if result is not None and result.stack:
        return result.stack
    if context is not None:
        location = context.route or context.url or "unknown"
        method = context.method or "?"
        return [f"inbound request ({method} {location})"]
    return result.stack if result is not None else None


def _payload(result: DetectionResult | None, reason: str | None) -> str:
    if result is not None and result.description is not None:
        return result.description
    if reason is not None:
        return reason
    return "No description provided"


def _level(decision: BlockDecision) -> str:
    result = decision.result
    if result is None:
        return "high"
    confidence = result.confidence
    if confidence >= 0.9:
        return "critical"
    if confidence >= 0.7:
        return "high"
    if confidence >= 0.5:
        return "medium"
    return "low"

"""Starts background cloud reporting and wires incident reporting to the request flow.

Both integration surfaces (framework adapters and the programmatic ``protect`` API)
call :func:`start` so the wiring is identical: it builds the API client transport,
starts the :class:`CloudReporter` (device registration, heartbeat, config/firewall
sync) and connects the :class:`WebRequestCollector` block listener to
``report_incident`` so every blocked request is reported off the request path.

Fully fail-safe: any error here is logged and swallowed so the monitored application
is never affected and detection keeps working offline.
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.collectors.web_request_collector import WebRequestCollector
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.reporting import incident_factory
from bytehide_monitor.cloud.reporting.cloud_reporter import CloudReporter
from bytehide_monitor.core.http.api_client import MonitorApiClient
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.platform.machine_id import get_machine_id


def start(
    engine: CloudEngine,
    web_request_collector: WebRequestCollector | None,
    config: CloudMonitorConfig,
) -> CloudReporter | None:
    if engine is None or config is None:
        return None
    try:
        api_client = MonitorApiClient(config.project_token or "")
        reporter = CloudReporter(api_client)
        reporter.start(engine, config)

        machine_id = get_machine_id()
        if web_request_collector is not None:

            def _on_blocked(decision, session, context) -> None:
                try:
                    reporter.report_incident(
                        incident_factory.build(decision, session, context, machine_id)
                    )
                except Exception:  # noqa: BLE001 - reporting must never break the request
                    pass

            web_request_collector.set_block_listener(_on_blocked)

        MonitorLogger.info("I055_REPORTING_STARTED", "Background cloud reporting started")
        return reporter
    except Exception as exc:  # noqa: BLE001 - reporting startup is best-effort
        MonitorLogger.warning("W052_REPORTING_START", f"Failed to start background reporting: {exc}")
        return None

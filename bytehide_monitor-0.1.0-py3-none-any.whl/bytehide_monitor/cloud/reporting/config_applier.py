"""Applies backend configuration (device/heartbeat response) into the engine.

Meaningful backend-driven state for the cloud engine is block mode, heartbeat
interval, the firewall lists and the per-module protection rules. Translates the
backend ``FirewallConfiguration`` into the engine's :class:`FirewallRules` and the
backend ``modules`` list into the scanner's :class:`ProtectionConfig` map (so a
dashboard rule change - e.g. block -> log - takes effect on the next heartbeat).
Never raises: malformed config is logged and skipped (offline-first).
"""

from __future__ import annotations

import threading

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.collectors.firewall_rules import EMPTY as EMPTY_RULES
from bytehide_monitor.cloud.collectors.firewall_rules import FirewallRules
from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType
from bytehide_monitor.models.firewall_configuration import FirewallConfiguration, IpRange
from bytehide_monitor.models.module_configuration import ModuleConfiguration
from bytehide_monitor.models.responses.configuration import RemoteConfiguration

# Backend action synonyms, 1:1 with .NET ``HeartbeatManager.ParseActionType``. Names
# outside this map are treated as registered custom actions (the registry logs and
# no-ops when the handler is missing, matching the .NET unknown -> none fallback).
_ACTION_SYNONYMS = {
    "none": "none",
    "ignore": "none",
    "log": "log",
    "logging": "log",
    "block": "block",
    "blocking": "block",
    "close": "close",
    "terminate": "close",
    "exit": "close",
    "erase": "erase",
    "delete": "erase",
}


def apply(engine: CloudEngine | None, config: RemoteConfiguration | None) -> None:
    if engine is None or config is None:
        return
    try:
        engine.apply_backend_config(config.block_mode, config.heartbeat_interval_ms)
        apply_firewall(engine, config.firewall)
        apply_modules(engine, config.modules)
    except Exception as exc:  # noqa: BLE001 - config apply must never break the app
        MonitorLogger.error("CFG_CLOUD_APPLY", f"Cloud config apply failed: {exc}")


def apply_modules(engine: CloudEngine | None, modules: list[ModuleConfiguration] | None) -> None:
    """Overlay backend module rules on the live protection map.

    Mirrors .NET ``HeartbeatManager.ApplyConfigurationAsync``: an absent/empty list keeps
    the current protections untouched. Listed modules replace their live entry (so a
    dashboard block<->log change takes effect); a module that was previously backend-set
    but is no longer listed reverts to the preset/file baseline. Overlaying on the live
    map (not a fresh rebuild) preserves runtime mutations of other modules - e.g. a
    programmatic ``protections[module].action`` override the host set after ``protect()``.
    """
    if engine is None or not modules:
        return
    merged = dict(engine.protections)
    new_keys: set[str] = set()
    for module_config in modules:
        if module_config is None:
            continue
        module = ProtectionModuleType.from_value(module_config.type)
        if module is None:
            MonitorLogger.warning(
                "W007_CONFIG_INVALID", f"Unknown module type in config: {module_config.type}"
            )
            continue
        merged[module.value] = _to_protection_config(module_config, merged.get(module.value))
        new_keys.add(module.value)

    # Revert modules that were backend-managed last time but dropped from the rule list.
    for stale_key in engine.backend_module_keys - new_keys:
        baseline = engine.baseline_protection(stale_key)
        if baseline is not None:
            merged[stale_key] = baseline
        else:
            merged.pop(stale_key, None)

    engine.protections = merged
    engine.backend_module_keys = new_keys
    MonitorLogger.info(
        "I007_CONFIG_LOADED", f"Applied {len(new_keys)} backend module rules to protections"
    )


def _to_protection_config(
    module_config: ModuleConfiguration, baseline: ProtectionConfig | None
) -> ProtectionConfig:
    action, custom_name = _normalize_action(module_config.action, baseline)
    if module_config.enabled is not None:
        enabled = module_config.enabled
    else:
        enabled = baseline.enabled if baseline is not None else True
    return ProtectionConfig(
        enabled=enabled,
        action=action,
        custom_action_name=custom_name,
        interval_ms=module_config.interval_ms,
        config=module_config.config or None,
    )


def _normalize_action(
    action: str | None, baseline: ProtectionConfig | None
) -> tuple[str, str | None]:
    """Resolve the backend action string to (action, custom_action_name)."""
    if action is None or not action.strip():
        if baseline is not None:
            return baseline.action, baseline.custom_action_name
        return "none", None
    normalized = _ACTION_SYNONYMS.get(action.strip().lower())
    if normalized is not None:
        return normalized, None
    return "custom", action.strip()


def apply_firewall(engine: CloudEngine | None, firewall: FirewallConfiguration | None) -> None:
    if engine is None:
        return
    if firewall is None:
        engine.apply_firewall_rules(EMPTY_RULES)
        _apply_blocked_sessions(engine, None)
        engine.threat_intel_store.clear_countries()
        engine.threat_intel_store.clear_threat_actors()
        return
    rules = FirewallRules(
        allowed_ips=firewall.allowed_ips,
        blocked_ips=_blocked_ip_entries(firewall.blocked_ips),
        blocked_user_agents=firewall.blocked_user_agents,
        blocked_users=firewall.blocked_users,
    )
    engine.apply_firewall_rules(rules)
    _apply_blocked_sessions(engine, firewall.blocked_sessions)
    _apply_blocked_devices(engine, firewall.blocked_devices)
    _apply_threat_intel(engine, firewall.blocked_countries, firewall.blocked_threat_actors)


def _apply_blocked_devices(engine: CloudEngine, device_ids: list[str] | None) -> None:
    if not device_ids:
        return
    from bytehide_monitor.core.platform.machine_id import get_machine_id

    if get_machine_id() in device_ids and engine.config is not None:
        MonitorLogger.critical("C008_LICENSE_REVOKED", "This device is blocked by the backend")
        engine.config.enabled = False


def _apply_blocked_sessions(engine: CloudEngine, session_ids: list[str] | None) -> None:
    """Diff the backend blocklist against the previous apply (.NET parity).

    Sessions removed from the dashboard blocklist are unblocked; sessions blocked
    locally by a detector (never in ``backend_blocked_sessions``) are left untouched.
    """
    blocked = {session_id for session_id in (session_ids or []) if session_id}
    for session_id in engine.backend_blocked_sessions - blocked:
        engine.session_manager.unblock_session(session_id)
    for session_id in blocked:
        engine.session_manager.block_session(session_id, "session_blocked")
    engine.backend_blocked_sessions = blocked


def _apply_threat_intel(
    engine: CloudEngine,
    countries: list[str] | None,
    threat_actors: list[str] | None,
) -> None:
    """Fetch and apply country/threat-actor IP ranges in the background (large feeds)."""
    active_countries = [c for c in (countries or []) if c]
    active_actors = [a for a in (threat_actors or []) if a]
    if not active_countries:
        engine.threat_intel_store.clear_countries()
    if not active_actors:
        engine.threat_intel_store.clear_threat_actors()
    if not active_countries and not active_actors:
        return

    def _fetch() -> None:
        from bytehide_monitor.core.threat_intel.threat_intel_client import ThreatIntelClient

        client = ThreatIntelClient()
        if active_countries:
            data = client.fetch_country_ips(active_countries)
            engine.threat_intel_store.update_countries(data, active_countries)
        if active_actors:
            data = client.fetch_threat_actor_ips(active_actors)
            engine.threat_intel_store.update_threat_actors(data, active_actors)

    thread = threading.Thread(target=_guarded_fetch(_fetch), name="ByteHide-ThreatIntel", daemon=True)
    thread.start()


def _guarded_fetch(fetch):
    def runner() -> None:
        try:
            fetch()
        except Exception as exc:  # noqa: BLE001 - threat-intel fetch must never crash
            MonitorLogger.error("E004_API_FAILED", f"ThreatIntel update failed: {exc}")

    return runner


def _blocked_ip_entries(ranges: list[IpRange] | None) -> list[str] | None:
    if not ranges:
        return None
    entries: list[str] = []
    for range_ in ranges:
        if range_ is None:
            continue
        if range_.start:
            entries.append(range_.start)
        if range_.end and range_.end != range_.start:
            entries.append(range_.end)
    return entries or None

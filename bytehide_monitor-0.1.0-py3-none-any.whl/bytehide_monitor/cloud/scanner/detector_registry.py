"""Holds the cloud web detectors keyed by ``ProtectionModuleType``.

Detectors are stateless and thread-safe, so a single instance of each is shared. The
registry is built once and treated as immutable; enable/disable lives in
configuration and is applied by the :class:`Scanner`.
"""

from __future__ import annotations

from bytehide_monitor.cloud.detectors.command_injection import CommandInjectionDetector
from bytehide_monitor.cloud.detectors.cross_site_scripting import CrossSiteScriptingDetector
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.cloud.detectors.ldap_injection import LdapInjectionDetector
from bytehide_monitor.cloud.detectors.nosql_injection import NoSqlInjectionDetector
from bytehide_monitor.cloud.detectors.path_traversal import PathTraversalDetector
from bytehide_monitor.cloud.detectors.sql_injection import SqlInjectionDetector
from bytehide_monitor.cloud.detectors.ssrf import SsrfDetector
from bytehide_monitor.cloud.detectors.xxe import XxeDetector
from bytehide_monitor.cloud.detectors.template_injection import TemplateInjectionDetector
from bytehide_monitor.cloud.detectors.unsafe_deserialization import UnsafeDeserializationDetector
from bytehide_monitor.cloud.detectors.open_redirect import OpenRedirectDetector
from bytehide_monitor.cloud.detectors.http_response_splitting import HttpResponseSplittingDetector
from bytehide_monitor.cloud.detectors.jwt_attack import JwtAttackDetector
from bytehide_monitor.cloud.detectors.unauthenticated_access import UnauthenticatedAccessDetector
from bytehide_monitor.cloud.detectors.mass_assignment import MassAssignmentDetector
from bytehide_monitor.cloud.detectors.broken_auth import BrokenAuthBruteForceDetector
from bytehide_monitor.cloud.detectors.bola_enumeration import BolaEnumerationDetector
from bytehide_monitor.cloud.detectors.response_data_exposure import ResponseDataExposureDetector
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class DetectorRegistry:
    def __init__(self) -> None:
        detectors = (
            SqlInjectionDetector(),
            CrossSiteScriptingDetector(),
            PathTraversalDetector(),
            CommandInjectionDetector(),
            SsrfDetector(),
            LdapInjectionDetector(),
            XxeDetector(),
            NoSqlInjectionDetector(),
            TemplateInjectionDetector(),
            UnsafeDeserializationDetector(),
            OpenRedirectDetector(),
            HttpResponseSplittingDetector(),
            # Request-level detectors: run once per request over the full ContextObject
            # (via run_request), not per flattened input. They read fields excluded from the
            # per-input scan (headers, cookies, method, route as a unit).
            JwtAttackDetector(),
            UnauthenticatedAccessDetector(),
            MassAssignmentDetector(),
            # Broken-auth brute force is request-level (+ optional response failure signal) and holds
            # in-memory sliding-window state keyed by (client_ip, route); see its module docstring.
            BrokenAuthBruteForceDetector(),
            # BOLA/IDOR enumeration is request-level (+ in-memory per-(identity,route) sliding window of
            # distinct object IDs); it catches the enumeration pattern, not a single unauthorized access.
            BolaEnumerationDetector(),
            # Response-level detector: runs once per request over the OUTGOING response (via
            # run_response), inspecting the response body for sensitive-data leakage.
            ResponseDataExposureDetector(),
            # LlmPromptInjection has no local detector: AI/LLM prompt-injection is enforced at the gateway
            # (AI sink proxy or /monitor/validate), never on the local detector path. The module type and its
            # protection rule still exist (they gate the gateway guard); only the dead local regex detector is gone.
        )
        self._detectors: dict[ProtectionModuleType, CloudDetector] = {
            detector.type(): detector for detector in detectors
        }

    def get(self, module: ProtectionModuleType | None) -> CloudDetector | None:
        if module is None:
            return None
        return self._detectors.get(module)

    def all(self) -> dict[ProtectionModuleType, CloudDetector]:
        return dict(self._detectors)

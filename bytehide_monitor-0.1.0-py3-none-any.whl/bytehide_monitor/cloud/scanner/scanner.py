"""Cloud detection orchestration (port of .NET ``SecurityDetectors`` + middleware loop).

``scan_inbound`` runs every enabled detector across every extracted user input and
returns a :class:`BlockDecision` on the first match whose configured action is
``block``. Endpoint ``force_protection_off`` short-circuits the scan; per-endpoint
protection overrides replace the global config for matching routes. Matches with a
``log``/``none`` action are recorded as incidents but do not block. LLM prompt
injection is excluded from the inbound scan (the .NET middleware entry is a no-op
placeholder); it is detected at the LLM call site by the AI sink instead.

``scan_sink`` is the entry point for in-app sink collectors (SQL, file, command,
URL): it runs the single relevant detector across the request's user inputs with the
sink context supplied as detector arguments.

Stateless except for the injected statistics store; safe for concurrent use.
"""

from __future__ import annotations

import uuid
from collections.abc import Sequence
from typing import TYPE_CHECKING

from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.config.endpoint_config import EndpointConfig
from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector, ResponseView
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.cloud.scanner.detector_registry import DetectorRegistry
from bytehide_monitor.core.action import action_registry
from bytehide_monitor.core.action.action_type import ActionType
from bytehide_monitor.core.action.threat_context import ThreatContext
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

if TYPE_CHECKING:
    from bytehide_monitor.cloud.statistics.statistics_store import StatisticsStore


class Scanner:
    def __init__(
        self, registry: DetectorRegistry, statistics: StatisticsStore | None = None
    ) -> None:
        if registry is None:
            raise ValueError("registry must not be None")
        self._registry = registry
        self._statistics = statistics

    def scan_inbound(
        self,
        context: ContextObject | None,
        config: CloudMonitorConfig | None,
        protections: dict[str, ProtectionConfig] | None,
    ) -> BlockDecision | None:
        if context is None or not protections:
            return None

        endpoint = _match_endpoint(context, config)
        if endpoint is not None and endpoint.force_protection_off:
            return None

        # Inbound scan covers query/body/path only (not headers/cookies), matching the
        # .NET HTTP-level detection and avoiding false positives from benign header
        # values with shell/LDAP metacharacters. Headers/cookies are still scanned at
        # sinks via get_user_inputs().
        user_inputs = context.get_inbound_inputs()
        if not user_inputs:
            return None

        for name, global_protection in protections.items():
            module = ProtectionModuleType.from_value(name)
            if module is None:
                continue
            # LLM prompt injection is not an HTTP-level detection: the .NET middleware
            # entry is a no-op placeholder and detection happens at the LLM call site
            # (here, the AI sink validating against the gateway guard).
            if module is ProtectionModuleType.LLM_PROMPT_INJECTION:
                continue
            protection = _effective_protection(module, global_protection, endpoint)
            if protection is None or not protection.enabled:
                continue
            detector = self._registry.get(module)
            if detector is None:
                continue
            decision = self._run_detector(detector, module, protection, user_inputs, context)
            if decision is not None:
                return decision
        return None

    def scan_request(
        self,
        context: ContextObject | None,
        config: CloudMonitorConfig | None,
        protections: dict[str, ProtectionConfig] | None,
    ) -> BlockDecision | None:
        """Run request-level detectors once per request over the full context.

        Mirrors ``scan_inbound`` for module resolution / endpoint overrides / action handling,
        but invokes each enabled detector's ``run_request(context)`` exactly once with the whole
        ``ContextObject`` (so it can read headers/cookies/method/route as a unit) instead of the
        per-input ``run``. Returns the first detection's :class:`BlockDecision`. Fully fail-open:
        any error in a single detector is swallowed and the scan continues.
        """
        try:
            if context is None or not protections:
                return None
            endpoint = _match_endpoint(context, config)
            if endpoint is not None and endpoint.force_protection_off:
                return None
            for name, global_protection in protections.items():
                try:
                    module = ProtectionModuleType.from_value(name)
                    if module is None:
                        continue
                    protection = _effective_protection(module, global_protection, endpoint)
                    if protection is None or not protection.enabled:
                        continue
                    detector = self._registry.get(module)
                    if detector is None:
                        continue
                    decision = self._evaluate_request(detector, module, protection, context)
                    if decision is not None:
                        return decision
                except Exception:  # noqa: BLE001 - one bad detector must not break the request
                    continue
            return None
        except Exception:  # noqa: BLE001 - request-level scan is fail-open end to end
            return None

    def _evaluate_request(
        self,
        detector: CloudDetector,
        module: ProtectionModuleType,
        protection: ProtectionConfig,
        context: ContextObject,
    ) -> BlockDecision | None:
        self._record(module)
        # Hand the module's free-form config to the detector via a private context attribute,
        # so run_request(context) keeps the base-class signature. Cleared after the call.
        try:
            context._request_detector_config = protection.config or {}  # type: ignore[attr-defined]
            result = detector.run_request(context)
        finally:
            try:
                context._request_detector_config = None  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass

        if result is None or not result.threat_detected:
            return None

        self._record_detection(module)
        block, action_name = execute_action(module, protection, result)
        self._record_incident(module, block)
        reference_id = str(uuid.uuid4())
        reason = result.description if result.description is not None else module.value
        return BlockDecision.detected(
            module, reason, result, reference_id, blocked=block, action=action_name
        )

    def scan_response(
        self,
        context: ContextObject | None,
        response: ResponseView | None,
        config: CloudMonitorConfig | None,
        protections: dict[str, ProtectionConfig] | None,
    ) -> BlockDecision | None:
        """Run response-level detectors once per request over the outgoing response.

        Mirror of ``scan_request`` for the response side: same module resolution / endpoint
        overrides / action handling, but invokes each enabled detector's ``run_response(context,
        response)`` exactly once with the full ``ContextObject`` plus a :class:`ResponseView`
        (status, headers, body). Returns the first detection's :class:`BlockDecision`. Fully
        fail-open: any error in a single detector is swallowed and the scan continues.
        """
        try:
            if context is None or response is None or not protections:
                return None
            endpoint = _match_endpoint(context, config)
            if endpoint is not None and endpoint.force_protection_off:
                return None
            for name, global_protection in protections.items():
                try:
                    module = ProtectionModuleType.from_value(name)
                    if module is None:
                        continue
                    protection = _effective_protection(module, global_protection, endpoint)
                    if protection is None or not protection.enabled:
                        continue
                    detector = self._registry.get(module)
                    if detector is None:
                        continue
                    decision = self._evaluate_response(detector, module, protection, context, response)
                    if decision is not None:
                        return decision
                except Exception:  # noqa: BLE001 - one bad detector must not break the response
                    continue
            return None
        except Exception:  # noqa: BLE001 - response-level scan is fail-open end to end
            return None

    def _evaluate_response(
        self,
        detector: CloudDetector,
        module: ProtectionModuleType,
        protection: ProtectionConfig,
        context: ContextObject,
        response: ResponseView,
    ) -> BlockDecision | None:
        self._record(module)
        # Hand the module's free-form config to the detector via the same private context attribute
        # used by the request path, so run_response(context, response) keeps the base signature.
        try:
            context._request_detector_config = protection.config or {}  # type: ignore[attr-defined]
            result = detector.run_response(context, response)
        finally:
            try:
                context._request_detector_config = None  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass

        if result is None or not result.threat_detected:
            return None

        self._record_detection(module)
        block, action_name = execute_action(module, protection, result)
        self._record_incident(module, block)
        reference_id = str(uuid.uuid4())
        reason = result.description if result.description is not None else module.value
        return BlockDecision.detected(
            module, reason, result, reference_id, blocked=block, action=action_name
        )

    def scan_sink(
        self,
        module: ProtectionModuleType | None,
        sink_value: str | None,
        context: ContextObject | None,
        config: CloudMonitorConfig | None,
        protections: dict[str, ProtectionConfig] | None,
        *extra_args: str,
        scan_value_directly: bool = False,
    ) -> BlockDecision | None:
        if module is None or protections is None:
            return None

        endpoint = _match_endpoint(context, config) if context is not None else None
        if endpoint is not None and endpoint.force_protection_off:
            return None

        global_protection = protections.get(module.value)
        protection = _effective_protection(module, global_protection, endpoint)
        if protection is None or not protection.enabled:
            return None

        detector = self._registry.get(module)
        if detector is None:
            return None

        arguments = _build_arguments(sink_value, extra_args)

        # XXE inspects the full payload (the sink value) itself, not individual request
        # inputs, so it scans the value directly regardless of the bound context.
        if scan_value_directly:
            return self._evaluate(detector, module, protection, sink_value, arguments)

        # A sink correlates a REQUEST INPUT against the dangerous operation: only a value that arrived as
        # untrusted request input can make a sink fire (mirroring .NET, whose interceptors see no inputs when
        # there is no Agent context). Without a bound request - or a request that carried no user inputs - there
        # is nothing untrusted to correlate, so the sink does not fire. Scanning the sink value as its OWN
        # "user input" here would false-positive: e.g. any absolute library data-file path
        # (``c:\...\botocore\data\endpoints.json``, LiteLLM's provider configs) trivially satisfies the
        # path-traversal absolute-start heuristic since input == path, blocking boto3/LiteLLM client setup.
        if context is None:
            return None
        user_inputs = context.get_user_inputs()
        if not user_inputs:
            return None
        for value in user_inputs.values():
            decision = self._evaluate(detector, module, protection, value, arguments)
            if decision is not None:
                return decision
        return None

    def _run_detector(
        self,
        detector: CloudDetector,
        module: ProtectionModuleType,
        protection: ProtectionConfig,
        user_inputs: dict[str, str],
        context: ContextObject | None,
    ) -> BlockDecision | None:
        # Pass the input source key (e.g. "query.q", "body.text") so detectors can report
        # the input location in the incident description, matching the .NET HTTP detectors.
        for name, value in user_inputs.items():
            decision = self._evaluate(
                detector, module, protection, value, (), source=name, context=context
            )
            if decision is not None:
                return decision
        return None

    def _evaluate(
        self,
        detector: CloudDetector,
        module: ProtectionModuleType,
        protection: ProtectionConfig,
        value: str | None,
        arguments: Sequence[str],
        source: str | None = None,
        context: ContextObject | None = None,
    ) -> BlockDecision | None:
        if value is None:
            return None

        self._record(module)
        if detector.return_early(value, arguments):
            return None

        # Expose the module's free-form config to the detector for the duration of the call (same
        # private attribute the request/response paths use), so sink detectors that read config
        # (e.g. SSRF strict-mode allowlist) see the dashboard settings. Cleared afterwards.
        set_cfg = context is not None
        if set_cfg:
            try:
                context._request_detector_config = protection.config or {}  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                set_cfg = False
        try:
            result = detector.run(value, arguments)
        finally:
            if set_cfg:
                try:
                    context._request_detector_config = None  # type: ignore[attr-defined]
                except Exception:  # noqa: BLE001
                    pass
        if result is None or not result.threat_detected:
            return None

        # Inbound detections carry the input source: let the detector restate the
        # description in terms of the location (e.g. "XSS detected in query string") and
        # enrich the metadata with request context (e.g. XSS RequestMethod / RequestPath).
        if source is not None:
            inbound_description = detector.describe_inbound(source)
            if inbound_description is not None:
                result.description = inbound_description
            if context is not None:
                extra = detector.inbound_metadata(context)
                if extra:
                    result.metadata.update(extra)

        self._record_detection(module)

        # Resolve and run the configured action; the action decides whether to block.
        block, action_name = execute_action(module, protection, result)
        self._record_incident(module, block)

        # A detector match always yields a decision so the incident is reported (.NET
        # reports on every detection regardless of action). ``blocked`` gates the 403:
        # a ``log``/``none`` action reports the incident but lets the request through.
        reference_id = str(uuid.uuid4())
        reason = result.description if result.description is not None else module.value
        return BlockDecision.detected(
            module, reason, result, reference_id, blocked=block, action=action_name
        )

    def _record(self, module: ProtectionModuleType) -> None:
        if self._statistics is not None:
            self._statistics.record_module_execution(module)

    def _record_detection(self, module: ProtectionModuleType) -> None:
        if self._statistics is not None:
            self._statistics.record_module_detection(module)

    def _record_incident(self, module: ProtectionModuleType, block: bool) -> None:
        if self._statistics is not None:
            self._statistics.record_incident(module, block)


def _effective_protection(
    module: ProtectionModuleType,
    global_protection: ProtectionConfig | None,
    endpoint: EndpointConfig | None,
) -> ProtectionConfig | None:
    if endpoint is not None and endpoint.protections is not None:
        override = endpoint.protections.get(module.value)
        if override is not None:
            return override
    return global_protection


def _match_endpoint(
    context: ContextObject | None, config: CloudMonitorConfig | None
) -> EndpointConfig | None:
    if (
        context is None
        or config is None
        or config.cloud is None
        or config.cloud.endpoints is None
    ):
        return None
    for endpoint in config.cloud.endpoints:
        if _method_matches(endpoint.method, context.method) and _route_matches(
            endpoint.route, context.route
        ):
            return endpoint
    return None


def _method_matches(pattern: str | None, method: str | None) -> bool:
    if not pattern or pattern == "*":
        return True
    return method is not None and pattern.lower() == method.lower()


def _route_matches(pattern: str | None, route: str | None) -> bool:
    if not pattern or pattern == "*":
        return True
    if route is None:
        return False
    if pattern.endswith("/*"):
        return route.startswith(pattern[:-1])
    return pattern == route


def _build_arguments(sink_value: str | None, extra_args: Sequence[str]) -> list[str]:
    arguments: list[str] = [sink_value if sink_value is not None else ""]
    arguments.extend(extra_args)
    return arguments


def _resolve_action(action: str | None) -> ActionType:
    if not action:
        return ActionType.LOG
    return ActionType.from_value(action, default=ActionType.LOG)


def execute_action(
    module: ProtectionModuleType,
    protection: ProtectionConfig | None,
    result: DetectionResult,
) -> tuple[bool, str]:
    """Resolve and run the configured action for a detection; the action decides blocking.

    Shared by the request scanner and the AI sink. Returns ``(should_block, action_name)``.
    A missing protection config falls back to ``block``, matching the .NET interceptors'
    null-config default.
    """
    if protection is None:
        action = ActionType.BLOCK
        action_name: str | None = ActionType.BLOCK.value
    else:
        action = _resolve_action(protection.action)
        action_name = (
            protection.custom_action_name if action == ActionType.CUSTOM else action.value
        )
    threat_context = ThreatContext.from_detection(module, result)
    action_registry.instance().execute(action_name, threat_context)
    return threat_context.should_block, action_name or action.value

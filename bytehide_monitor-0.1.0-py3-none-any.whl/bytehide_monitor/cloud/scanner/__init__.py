"""Scan orchestration and block decisions."""

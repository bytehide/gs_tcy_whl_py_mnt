"""Immutable outcome of a security evaluation that matched a threat.

Carries the HTTP status (403 for a detection/firewall block, 429 for rate limiting),
the originating module, a human-readable reason, the underlying
:class:`DetectionResult` (when a detector produced it), a reference id for correlation,
and the resolved action. ``blocked`` distinguishes an enforced block (the request is
rejected) from a detect-only match (action ``log``/``none`` - the request is allowed but
the incident is still reported, matching the .NET middleware which reports on every
detection regardless of action). The scanner returns ``None`` only when no threat matched.
"""

from __future__ import annotations

from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

STATUS_FORBIDDEN = 403
STATUS_TOO_MANY_REQUESTS = 429


class BlockDecision:
    __slots__ = ("http_status", "module", "reason", "result", "reference_id", "blocked", "action")

    def __init__(
        self,
        http_status: int,
        module: ProtectionModuleType | None,
        reason: str | None,
        result: DetectionResult | None,
        reference_id: str | None,
        blocked: bool = True,
        action: str = "block",
    ) -> None:
        self.http_status = http_status
        self.module = module
        self.reason = reason
        self.result = result
        self.reference_id = reference_id
        self.blocked = blocked
        self.action = action

    @staticmethod
    def forbidden(
        module: ProtectionModuleType | None,
        reason: str | None,
        result: DetectionResult | None,
        reference_id: str | None,
    ) -> BlockDecision:
        return BlockDecision(STATUS_FORBIDDEN, module, reason, result, reference_id)

    @staticmethod
    def detected(
        module: ProtectionModuleType | None,
        reason: str | None,
        result: DetectionResult | None,
        reference_id: str | None,
        *,
        blocked: bool,
        action: str,
    ) -> BlockDecision:
        """A detector match with the resolved action; ``blocked`` gates the 403."""
        return BlockDecision(
            STATUS_FORBIDDEN, module, reason, result, reference_id, blocked=blocked, action=action
        )

    @staticmethod
    def rate_limited(reason: str, reference_id: str) -> BlockDecision:
        return BlockDecision(STATUS_TOO_MANY_REQUESTS, None, reason, None, reference_id)

    @staticmethod
    def firewall(reason: str, reference_id: str) -> BlockDecision:
        return BlockDecision(STATUS_FORBIDDEN, None, reason, None, reference_id)

    @property
    def is_blocked(self) -> bool:
        return self.blocked

"""Standalone input validation across every cloud detection system.

Runs the cloud detectors against a single value and returns *every* match, mirroring how
the request-bound firewall treats inbound input.

By default the value is inspected on its own, exactly as the inbound
:class:`~bytehide_monitor.cloud.scanner.scanner.Scanner` does: the input-pattern detectors
(XSS, XXE, LLM prompt injection, SSRF) evaluate the raw value, while the sink-bound
detectors (SQL, command, path, LDAP, NoSQL) return early. Those are *differential*
detectors that compare the input against the real operation it is embedded in; without
that operation they cannot run without flagging any value that merely contains shell/SQL
metacharacters (a space, ``;``, ``,`` ...). To evaluate them, pass the surrounding
``operation`` (the query, command, path or filter) so they can run meaningfully.

Differences from the request-bound :class:`Scanner`:

- Runs *all* selected detectors and collects *all* findings (the Scanner stops at the
  first blocking match).
- Pure and stateless: no request context, no configured actions, no incident reporting,
  no session blocking, no backend or AI calls.
- Never blocks: it only reports. Callers decide what to do with the verdict.

Detectors are pure and thread-safe, so a single shared :class:`DetectorRegistry` backs
all calls.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from bytehide_monitor.cloud.response import threat_taxonomy
from bytehide_monitor.cloud.scanner.detector_registry import DetectorRegistry
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

# Metadata keys carrying the matched evidence, in priority order across detectors.
_EVIDENCE_KEYS = (
    "InjectedContent", "MatchedPattern", "Hostname", "evidence", "matched",
)

_registry: DetectorRegistry | None = None


def _shared_registry() -> DetectorRegistry:
    global _registry
    if _registry is None:
        _registry = DetectorRegistry()
    return _registry


@dataclass(frozen=True)
class DetectorFinding:
    """A single detector match for a validated input."""

    module: str
    code: str
    attack_type: str
    category: str
    description: str
    confidence: float
    evidence: str | None = None

    def to_dict(self) -> dict[str, Any]:
        raw = {
            "module": self.module,
            "code": self.code,
            "attackType": self.attack_type,
            "category": self.category,
            "description": self.description,
            "confidence": self.confidence,
            "evidence": self.evidence,
        }
        return {key: value for key, value in raw.items() if value is not None}


@dataclass(frozen=True)
class InputValidationReport:
    """Aggregated verdict for a validated input across all evaluated detectors."""

    safe: bool
    input_length: int
    evaluated_modules: list[str]
    findings: list[DetectorFinding]

    def to_dict(self) -> dict[str, Any]:
        return {
            "safe": self.safe,
            "inputLength": self.input_length,
            "evaluatedModules": self.evaluated_modules,
            "findings": [finding.to_dict() for finding in self.findings],
        }


def validate_input(
    value: str,
    *,
    operation: str | None = None,
    modules: Sequence[ProtectionModuleType] | None = None,
    registry: DetectorRegistry | None = None,
) -> InputValidationReport:
    """Validate ``value`` against the cloud detectors and return every match.

    Args:
        value: The raw input to inspect.
        operation: Optional surrounding operation (SQL query, shell command, file path or
            LDAP/NoSQL filter) the input is embedded in. Required for the sink-bound
            detectors (SQL, command, path, LDAP, NoSQL) to run; without it they are
            skipped, exactly as in the inbound firewall scan.
        modules: Detection modules to run; defaults to all nine cloud modules.
        registry: Detector registry to use; defaults to the shared instance.

    Returns:
        An :class:`InputValidationReport` with ``safe == True`` when no detector matched.
        ``evaluated_modules`` lists only the detectors that actually inspected the input
        (a sink-bound detector skipped for lack of ``operation`` is not listed).
    """
    if not isinstance(value, str):
        raise TypeError("value must be a string")

    active_registry = registry if registry is not None else _shared_registry()
    selected = list(modules) if modules is not None else ProtectionModuleType.cloud_modules()

    # No operation -> inbound semantics: sink-bound detectors return early. With an
    # operation, it becomes the sink argument so those detectors evaluate the input.
    arguments: tuple[str, ...] = (operation,) if operation is not None else ()

    evaluated: list[str] = []
    findings: list[DetectorFinding] = []
    for module in selected:
        detector = active_registry.get(module)
        if detector is None:
            continue
        if detector.return_early(value, arguments):
            continue
        evaluated.append(module.value)
        result = detector.run(value, arguments)
        if result is None or not result.threat_detected:
            continue
        findings.append(_to_finding(module, result))

    return InputValidationReport(
        safe=not findings,
        input_length=len(value),
        evaluated_modules=evaluated,
        findings=findings,
    )


def _to_finding(module: ProtectionModuleType, result: DetectionResult) -> DetectorFinding:
    return DetectorFinding(
        module=module.value,
        code=threat_taxonomy.code_for_module(module),
        attack_type=threat_taxonomy.attack_type_for_module(module),
        category=threat_taxonomy.category_for_module(module),
        description=result.description,
        confidence=result.confidence,
        evidence=_evidence_from(result),
    )


def _evidence_from(result: DetectionResult) -> str | None:
    for key in _EVIDENCE_KEYS:
        value = result.metadata.get(key)
        if value:
            return str(value)
    return None

"""In-memory store and lifecycle manager for cloud sessions (port of .NET manager).

Sessions are keyed by session id. Time is injectable so expiry is deterministic in
tests; the same clock is handed to every session it creates.
"""

from __future__ import annotations

import threading
from collections.abc import Callable

from bytehide_monitor.cloud.session.cloud_session import CloudSession, generate_session_id
from bytehide_monitor.core.helpers.datetime import now_unix_ms


class CloudSessionManager:
    def __init__(self, clock: Callable[[], int] = now_unix_ms) -> None:
        self._clock = clock
        self._sessions: dict[str, CloudSession] = {}
        self._lock = threading.RLock()

    def get_or_create(
        self,
        ip: str | None,
        user_agent: str | None,
        user_id: str | None = None,
        user_name: str | None = None,
    ) -> CloudSession | None:
        if not ip or not user_agent:
            return None
        session_id = generate_session_id(ip, user_agent, user_id)
        with self._lock:
            existing = self._sessions.get(session_id)
            if existing is not None:
                return existing
            created = CloudSession(ip, user_agent, user_id, user_name, self._clock)
            self._sessions[session_id] = created
            return created

    def get_session(self, session_id: str | None) -> CloudSession | None:
        if session_id is None:
            return None
        return self._sessions.get(session_id)

    def block_session(self, session_id: str, reason: str | None) -> bool:
        session = self.get_session(session_id)
        if session is None:
            return False
        session.block(reason)
        return True

    def unblock_session(self, session_id: str) -> bool:
        session = self.get_session(session_id)
        if session is None:
            return False
        session.unblock()
        return True

    def sweep_expired(self) -> int:
        with self._lock:
            expired = [sid for sid, session in self._sessions.items() if session.is_expired()]
            for sid in expired:
                del self._sessions[sid]
            return len(expired)

    def get_active_session_count(self) -> int:
        return sum(1 for session in self._sessions.values() if not session.is_expired())

    def get_total_session_count(self) -> int:
        return len(self._sessions)

    def snapshot_for_heartbeat(self) -> list[CloudSession]:
        return [session for session in self._sessions.values() if session.has_activity()]

    def reset_counters_after_heartbeat(self) -> None:
        for session in list(self._sessions.values()):
            session.reset_activity_counters()

    def clear(self) -> None:
        with self._lock:
            self._sessions.clear()

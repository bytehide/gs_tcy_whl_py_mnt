"""In-memory cloud session (1:1 port of .NET ``CloudSession``).

Tracked per IP+User-Agent (anonymous) or IP+User-Agent+UserId (authenticated). The
session id is the lowercase hex SHA-256 of ``ip|userAgent`` (plus ``|userId`` when
present). Time is injectable via a ``clock`` callable so rate-limit and expiry logic
are deterministic in tests.
"""

from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict, deque
from collections.abc import Callable

from bytehide_monitor.core.helpers.datetime import now_unix_ms

_MINUTE_MS = 60 * 1000
_DEFAULT_INACTIVITY_THRESHOLD_MINUTES = 30


def generate_session_id(ip: str, user_agent: str, user_id: str | None) -> str:
    """Lowercase hex SHA-256 of ``ip|userAgent[|userId]`` (identical to .NET/Java)."""
    raw = f"{ip}|{user_agent}|{user_id}" if user_id is not None else f"{ip}|{user_agent}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class CloudSession:
    def __init__(
        self,
        ip: str,
        user_agent: str,
        user_id: str | None = None,
        user_name: str | None = None,
        clock: Callable[[], int] = now_unix_ms,
    ) -> None:
        self._clock = clock
        self._lock = threading.RLock()
        self._request_timestamps: deque[int] = deque()
        self._top_routes: OrderedDict[str, int] = OrderedDict()

        self.ip = ip
        self.user_agent = user_agent
        self.user_id = user_id
        self.user_name = user_name
        self.original_ip = ip
        self.original_user_agent = user_agent
        self.session_id = generate_session_id(ip, user_agent, user_id)

        self.started_at = clock()
        self.last_activity_at = self.started_at
        self._total_requests = 0
        self._blocked = False
        self._block_reason: str | None = None

        self.last_method: str | None = None
        self.last_url: str | None = None
        self.last_route: str | None = None

    def record_activity(self, method: str | None, url: str | None, route: str | None) -> None:
        with self._lock:
            now = self._clock()
            self.last_activity_at = now
            self._total_requests += 1
            self.last_method = method
            self.last_url = url
            self.last_route = route
            self._request_timestamps.append(now)
            if route and method:
                route_key = f"{method} {route}"
                self._top_routes[route_key] = self._top_routes.get(route_key, 0) + 1

    def exceeds_rate_limit(self, max_requests_per_minute: int) -> bool:
        return self._prune_and_count() > max_requests_per_minute

    def get_requests_per_minute(self) -> int:
        return self._prune_and_count()

    def _prune_and_count(self) -> int:
        one_minute_ago = self._clock() - _MINUTE_MS
        with self._lock:
            while self._request_timestamps and self._request_timestamps[0] < one_minute_ago:
                self._request_timestamps.popleft()
            return len(self._request_timestamps)

    def has_ip_changed(self) -> bool:
        return self.ip != self.original_ip

    def has_user_agent_changed(self) -> bool:
        return self.user_agent != self.original_user_agent

    def associate_user(self, user_id: str, user_name: str | None) -> None:
        with self._lock:
            self.user_id = user_id
            self.user_name = user_name
            self.session_id = generate_session_id(self.ip, self.user_agent, user_id)

    def block(self, reason: str | None) -> None:
        with self._lock:
            self._blocked = True
            self._block_reason = reason

    def unblock(self) -> None:
        with self._lock:
            self._blocked = False
            self._block_reason = None

    def reset_activity_counters(self) -> None:
        with self._lock:
            self._total_requests = 0
            self._top_routes.clear()

    def has_activity(self) -> bool:
        with self._lock:
            return self._total_requests > 0

    def is_expired(self, inactivity_threshold_minutes: int = _DEFAULT_INACTIVITY_THRESHOLD_MINUTES) -> bool:
        inactivity_ms = self._clock() - self.last_activity_at
        return inactivity_ms > inactivity_threshold_minutes * _MINUTE_MS

    def top_routes(self) -> dict[str, int]:
        with self._lock:
            return OrderedDict(self._top_routes)

    @property
    def total_requests(self) -> int:
        with self._lock:
            return self._total_requests

    @property
    def is_blocked(self) -> bool:
        with self._lock:
            return self._blocked

    @property
    def block_reason(self) -> str | None:
        with self._lock:
            return self._block_reason

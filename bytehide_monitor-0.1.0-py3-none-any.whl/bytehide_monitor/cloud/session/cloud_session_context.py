"""Per-request holder for the active :class:`CloudSession`.

Backed by a :class:`contextvars.ContextVar` (async-safe under WSGI and ASGI). Set by
the inbound collector once the session is resolved; read by in-app sink collectors so
incidents can be attributed to the originating session.
"""

from __future__ import annotations

import contextvars

from bytehide_monitor.cloud.session.cloud_session import CloudSession

_CURRENT: contextvars.ContextVar[CloudSession | None] = contextvars.ContextVar(
    "bytehide_monitor_cloud_session", default=None
)


def current() -> CloudSession | None:
    return _CURRENT.get()


def set(session: CloudSession | None) -> contextvars.Token:
    return _CURRENT.set(session)


def clear(token: contextvars.Token | None = None) -> None:
    if token is not None:
        _CURRENT.reset(token)
    else:
        _CURRENT.set(None)

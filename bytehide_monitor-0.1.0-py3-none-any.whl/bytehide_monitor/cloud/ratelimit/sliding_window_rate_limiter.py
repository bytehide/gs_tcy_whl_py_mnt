"""Per-key sliding-window rate limiter (default 100 req / 60s).

Tracks request timestamps per key; a request is allowed while the count within the
trailing window stays at or below the maximum. Time is injectable for deterministic
tests. Thread-safe via per-key deques guarded by a shared lock.
"""

from __future__ import annotations

import threading
from collections import deque
from collections.abc import Callable

from bytehide_monitor.core.helpers.datetime import now_unix_ms

DEFAULT_MAX_REQUESTS = 100
DEFAULT_WINDOW_MS = 60000


class SlidingWindowRateLimiter:
    def __init__(self, clock: Callable[[], int] = now_unix_ms) -> None:
        self._clock = clock
        self._timestamps: dict[str, deque[int]] = {}
        self._lock = threading.Lock()

    def _queue_for(self, key: str) -> deque[int]:
        with self._lock:
            queue = self._timestamps.get(key)
            if queue is None:
                queue = deque()
                self._timestamps[key] = queue
            return queue

    def is_allowed(self, key: str, window_ms: int, max_requests: int) -> bool:
        if key is None:
            return True
        now = self._clock()
        window_start = now - window_ms
        queue = self._queue_for(key)
        with self._lock:
            queue.append(now)
            while queue and queue[0] < window_start:
                queue.popleft()
            return len(queue) <= max_requests

    def count_in_window(self, key: str, window_ms: int) -> int:
        with self._lock:
            queue = self._timestamps.get(key)
            if queue is None:
                return 0
            window_start = self._clock() - window_ms
            while queue and queue[0] < window_start:
                queue.popleft()
            return len(queue)

    def reset(self, key: str) -> None:
        with self._lock:
            self._timestamps.pop(key, None)

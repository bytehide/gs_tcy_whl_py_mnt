"""Sliding-window rate limiting."""

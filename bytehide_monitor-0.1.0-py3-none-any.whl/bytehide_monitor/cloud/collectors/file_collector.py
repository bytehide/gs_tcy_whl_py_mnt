"""In-app filesystem sink collector.

Called by open()/os/pathlib wrappers; runs the path-traversal detector over the
request's user inputs with the resolved path as sink context.
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class FileCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, path: str, operation: str | None = None) -> BlockDecision | None:
        context = context_holder.get()
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.PATH_TRAVERSAL,
            path,
            context,
            self._engine.config,
            self._engine.protections,
        )

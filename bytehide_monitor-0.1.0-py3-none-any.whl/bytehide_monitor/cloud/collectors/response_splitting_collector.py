"""In-app response-header sink collector (CRLF / HTTP response splitting). Scans the header/cookie value directly
for CR/LF (value-direct) - a newline in a header value is always illegitimate."""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class ResponseSplittingCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, value: str) -> BlockDecision | None:
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.HTTP_RESPONSE_SPLITTING,
            value,
            context_holder.get(),
            self._engine.config,
            self._engine.protections,
            scan_value_directly=True,
        )

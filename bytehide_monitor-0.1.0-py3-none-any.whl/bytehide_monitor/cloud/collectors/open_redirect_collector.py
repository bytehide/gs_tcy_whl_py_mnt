"""In-app open-redirect sink collector. Runs the open-redirect detector with the redirect Location as sink
context, correlated against request inputs (only flags when the user input itself is the off-site target)."""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class OpenRedirectCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, location: str) -> BlockDecision | None:
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.OPEN_REDIRECT,
            location,
            context_holder.get(),
            self._engine.config,
            self._engine.protections,
        )

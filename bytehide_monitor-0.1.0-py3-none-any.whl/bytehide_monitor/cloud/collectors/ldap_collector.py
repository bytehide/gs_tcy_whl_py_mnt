"""In-app LDAP sink collector.

Called by LDAP-client wrappers just before a search executes; runs the LDAP
injection detector over the request's user inputs with the full filter as sink
context (Python equivalent of the .NET ``LdapInjectionInterceptor``).
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class LdapCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, search_filter: str) -> BlockDecision | None:
        context = context_holder.get()
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.LDAP_INJECTION,
            search_filter,
            context,
            self._engine.config,
            self._engine.protections,
        )

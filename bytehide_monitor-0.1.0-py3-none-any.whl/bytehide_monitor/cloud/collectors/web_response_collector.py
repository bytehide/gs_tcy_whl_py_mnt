"""Response-time bookkeeping: per-route hit recording and attack-wave detection.

The detected attack-wave signal is returned so the caller can forward it to the
backend reporter; this collector performs no reporting itself.
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder


class WebResponseCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, status_code: int) -> bool:
        context = context_holder.get()
        if context is None:
            return False
        if context.method is not None and context.route is not None:
            self._engine.route_store.increment(context.method, context.route)
        return self._engine.attack_wave_detector.check(context)

"""Inbound request entry point (port of the .NET request flow + middleware).

:meth:`report` runs, in order: client-IP resolution, session get-or-create and
activity recording, firewall checks, session-blocked check, rate limiting, anomaly
detection, then the inbound detector scan. Returns a :class:`BlockDecision` when the
request should be blocked, or ``None`` to allow it. The context and session are
published on their context vars so in-app sink collectors can attribute incidents to
this request.

The caller (source adapter) builds the :class:`ContextObject`, calls ``report``,
applies the block response, and finally clears the context vars via :meth:`clear` in a
``finally`` block.

Only detector matches are reported as cloud incidents (parity with the .NET
middleware). Firewall, session-blocked, rate-limit and anomaly blocks still return a
:class:`BlockDecision` for the 403 response and are counted in request statistics, but
they do not emit an incident.
"""

from __future__ import annotations

import os
import uuid
from collections.abc import Callable


def _session_block_enabled() -> bool:
    """When BYTEHIDE_SESSION_BLOCK=0/false/off, a detection blocks only THAT request, not the whole session.
    Useful for red-team/eval runs (so one detected payload does not cascade-block the following requests from the
    same client). Default: enabled (block the offending session, the production behavior)."""
    return os.environ.get("BYTEHIDE_SESSION_BLOCK", "1").strip().lower() not in {"0", "false", "no", "off"}

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.collectors.firewall_rules import EMPTY as EMPTY_RULES
from bytehide_monitor.cloud.collectors.firewall_rules import FirewallRules
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.helpers.net import client_ip_resolver
from bytehide_monitor.cloud.ratelimit.sliding_window_rate_limiter import SlidingWindowRateLimiter
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.cloud.session import cloud_session_context
from bytehide_monitor.cloud.session.cloud_session import CloudSession

# Fire-and-forget block listener: (decision, session, context) -> None.
BlockListener = Callable[[BlockDecision, CloudSession | None, ContextObject | None], None]


class WebRequestCollector:
    def __init__(
        self,
        engine: CloudEngine,
        rate_limiter: SlidingWindowRateLimiter | None = None,
        firewall_rules: FirewallRules | None = None,
    ) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine
        self._rate_limiter = rate_limiter or SlidingWindowRateLimiter()
        self._firewall_rules = firewall_rules or EMPTY_RULES
        self._block_listener: BlockListener | None = None
        engine.register_firewall_sink(self.update_firewall_rules)

    def update_firewall_rules(self, firewall_rules: FirewallRules | None) -> None:
        self._firewall_rules = firewall_rules or EMPTY_RULES

    def set_block_listener(self, block_listener: BlockListener | None) -> None:
        self._block_listener = block_listener

    def _emit(
        self,
        decision: BlockDecision,
        session: CloudSession | None,
        context: ContextObject | None,
    ) -> BlockDecision:
        """Report a detector block as a cloud incident, then return the decision.

        Only detector matches are reported as incidents (parity with the .NET
        middleware, which calls ``ReportIncidentAsync`` solely on the detector path).
        Firewall, session-blocked, rate-limit and anomaly blocks are surfaced through
        request statistics on the heartbeat, not as individual incidents, so they must
        not pass through here.
        """
        listener = self._block_listener
        if listener is not None:
            try:
                listener(decision, session, context)
            except Exception:  # noqa: BLE001 - reporting must never break the request
                pass
        return decision

    def report(self, context: ContextObject | None) -> BlockDecision | None:
        if context is None:
            return None

        # 1. Resolve real client IP (proxy-aware) and publish the context.
        client_ip = client_ip_resolver.resolve(context.remote_address, context.headers)
        context.client_ip = client_ip
        context_holder.set(context)

        user_agent = context.get_header("User-Agent")
        user = context.user
        user_id = user.id if user is not None else None
        user_name = user.name if user is not None else None

        # 2. Firewall checks before creating a session (config rules + threat-intel IPs).
        firewall_reason = self._firewall_rules.evaluate(client_ip, user_agent, user_id)
        if firewall_reason is None and self._engine.threat_intel_store.is_blocked(client_ip):
            firewall_reason = "ip_blocked_by_threat_intel"
        if firewall_reason is not None:
            self._engine.statistics.record_request(True)
            return BlockDecision.firewall(firewall_reason, _new_reference_id())

        # 3. Get-or-create session and record activity.
        session_manager = self._engine.session_manager
        session = session_manager.get_or_create(client_ip, user_agent, user_id, user_name)
        if session is not None:
            cloud_session_context.set(session)
            session.record_activity(context.method, context.url, context.route)

            if session.is_blocked and _session_block_enabled():
                self._engine.statistics.record_request(True)
                reason = session.block_reason or "session_blocked"
                return BlockDecision.firewall(reason, _new_reference_id())

            # 4. Rate limiting (per session sliding window).
            rate_limit = self._check_rate_limit(session)
            if rate_limit is not None:
                if _session_block_enabled():
                    session_manager.block_session(session.session_id, rate_limit.reason)
                self._engine.statistics.record_request(True)
                return rate_limit

            # 5. Anomaly detection (IP / User-Agent change).
            anomaly = self._check_anomaly(session)
            if anomaly is not None:
                if _session_block_enabled():
                    session_manager.block_session(session.session_id, anomaly.reason)
                self._engine.statistics.record_request(True)
                return anomaly

        # 6. Inbound detector scan over all user inputs. A detector match always yields a
        # decision so the incident is reported (.NET reports on every detection); the
        # ``blocked`` flag decides whether the request is rejected or allowed through.
        decision = self._engine.scanner.scan_inbound(
            context, self._engine.config, self._engine.protections
        )
        if decision is not None:
            if decision.blocked:
                if session is not None and _session_block_enabled():
                    session_manager.block_session(session.session_id, decision.reason)
                self._engine.statistics.record_request(True)
                return self._emit(decision, session, context)
            # log/none action: report the incident but let the request through.
            self._engine.statistics.record_request(False)
            self._emit(decision, session, context)
            return None

        # 7. Request-level detector scan (JWT, unauthenticated access, mass assignment): run once
        # over the full context AFTER the per-input scan. Wrapped in fail-open guards (the scanner
        # is itself fail-open) so it can never break the host request. Same incident/block path as
        # the inbound scan above.
        try:
            request_decision = self._engine.scanner.scan_request(
                context, self._engine.config, self._engine.protections
            )
        except Exception:  # noqa: BLE001 - request-level scan must never break the request
            request_decision = None
        if request_decision is not None:
            if request_decision.blocked:
                if session is not None and _session_block_enabled():
                    session_manager.block_session(session.session_id, request_decision.reason)
                self._engine.statistics.record_request(True)
                return self._emit(request_decision, session, context)
            self._engine.statistics.record_request(False)
            self._emit(request_decision, session, context)
            return None

        self._engine.statistics.record_request(False)
        return None

    def clear(self) -> None:
        context_holder.reset()
        cloud_session_context.clear()

    def _check_rate_limit(self, session: CloudSession) -> BlockDecision | None:
        cloud = self._engine.config.cloud if self._engine.config is not None else None
        rate_limit = cloud.rate_limit if cloud is not None else None
        if rate_limit is None or not rate_limit.enabled or self._rate_limiter is None:
            return None
        allowed = self._rate_limiter.is_allowed(
            session.session_id, rate_limit.window_size_in_ms, rate_limit.max_requests
        )
        if allowed:
            return None
        count = self._rate_limiter.count_in_window(session.session_id, rate_limit.window_size_in_ms)
        reason = f"rate_limit_exceeded ({count} requests, max {rate_limit.max_requests})"
        return BlockDecision.rate_limited(reason, _new_reference_id())

    def _check_anomaly(self, session: CloudSession) -> BlockDecision | None:
        cloud = self._engine.config.cloud if self._engine.config is not None else None
        anomaly = cloud.anomaly_detection if cloud is not None else None
        if anomaly is None or not anomaly.enabled:
            return None
        if anomaly.detect_ip_changes and session.has_ip_changed():
            return BlockDecision.firewall("ip_changed", _new_reference_id())
        if anomaly.detect_user_agent_changes and session.has_user_agent_changed():
            return BlockDecision.firewall("user_agent_changed", _new_reference_id())
        return None


def _new_reference_id() -> str:
    return str(uuid.uuid4())

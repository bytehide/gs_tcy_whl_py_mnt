"""In-app NoSQL sink collector.

Called by NoSQL-driver wrappers (e.g. PyMongo) just before a query executes; runs the
NoSQL injection detector over the request's user inputs with the serialized query as
sink context (Python equivalent of the .NET ``NoSqlInjectionInterceptor``).
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class NoSqlCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, query: str) -> BlockDecision | None:
        context = context_holder.get()
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.NO_SQL_INJECTION,
            query,
            context,
            self._engine.config,
            self._engine.protections,
        )

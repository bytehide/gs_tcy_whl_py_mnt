"""In-app outbound-HTTP sink collector.

Called by HTTP-client wrappers; runs the SSRF detector over the request's user inputs
with the target URL as sink context.
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class UrlCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, url: str, method: str | None = None) -> BlockDecision | None:
        context = context_holder.get()
        decision = self._engine.scanner.scan_sink(
            ProtectionModuleType.SERVER_SIDE_REQUEST_FORGERY,
            url,
            context,
            self._engine.config,
            self._engine.protections,
        )
        # The sink knows the outbound HTTP verb; complete SsrfMetadata with it (the detector
        # leaves Method empty since value-level validation has no request).
        if decision is not None and decision.result is not None and method:
            decision.result.metadata["Method"] = method
        return decision

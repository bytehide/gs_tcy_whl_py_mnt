"""In-app template-render sink collector (SSTI). Runs the template-injection detector with the rendered template
as sink context, correlated against the request inputs (like SQL/command)."""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class TemplateCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, template: str) -> BlockDecision | None:
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.TEMPLATE_INJECTION,
            template,
            context_holder.get(),
            self._engine.config,
            self._engine.protections,
        )

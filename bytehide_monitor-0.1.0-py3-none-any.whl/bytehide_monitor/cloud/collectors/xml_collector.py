"""In-app XML sink collector.

Called by XML-parser wrappers just before parsing; runs the XXE detector over the XML
payload itself (Python equivalent of the .NET ``XxeInterceptor``). XXE detection
inspects the full document, so the payload is scanned directly rather than per request
input.
"""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class XmlCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, xml: str) -> BlockDecision | None:
        context = context_holder.get()
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.XML_EXTERNAL_ENTITY,
            xml,
            context,
            self._engine.config,
            self._engine.protections,
            scan_value_directly=True,
        )

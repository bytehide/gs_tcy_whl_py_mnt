"""Inbound and sink collectors (per-request pipeline)."""

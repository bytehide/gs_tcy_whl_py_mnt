"""In-app process sink collector.

Called by subprocess/os wrappers; runs the command-injection detector over the
request's user inputs with the full command as sink context.
"""

from __future__ import annotations

from typing import Any

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class CommandCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(
        self, command: str, extra_metadata: dict[str, Any] | None = None
    ) -> BlockDecision | None:
        context = context_holder.get()
        decision = self._engine.scanner.scan_sink(
            ProtectionModuleType.COMMAND_INJECTION,
            command,
            context,
            self._engine.config,
            self._engine.protections,
        )
        # The sink knows the subprocess.Popen call details (FileName/Arguments/cwd/shell);
        # merge them into the detector's metadata to complete CommandInjectionMetadata.
        if decision is not None and decision.result is not None and extra_metadata:
            decision.result.metadata.update(extra_metadata)
        return decision

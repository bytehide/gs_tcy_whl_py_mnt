"""In-app SQL sink collector.

Called by DB-driver wrappers just before a query executes; runs the SQL-injection
detector over the request's user inputs with the full query as sink context.
"""

from __future__ import annotations

from typing import Any

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class SqlCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(
        self,
        sql: str,
        dialect: str | None = None,
        operation: str | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> BlockDecision | None:
        context = context_holder.get()
        extra = (dialect,) if dialect is not None else ()
        decision = self._engine.scanner.scan_sink(
            ProtectionModuleType.SQL_INJECTION,
            sql,
            context,
            self._engine.config,
            self._engine.protections,
            *extra,
        )
        # The sink knows the bound DB-API parameters; merge them into the detector's
        # metadata to complete SqlInjectionMetadata (Parameters / ParameterCount).
        if decision is not None and decision.result is not None and extra_metadata:
            decision.result.metadata.update(extra_metadata)
        return decision

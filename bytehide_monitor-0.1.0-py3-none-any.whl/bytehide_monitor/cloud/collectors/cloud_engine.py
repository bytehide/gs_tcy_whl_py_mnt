"""Composition root aggregating the cloud engine collaborators.

Holds configuration, the resolved protection map, scanner, session manager,
statistics, route store and attack-wave detector behind a single object so the
framework collectors stay thin. The engine holds no per-request state; per-request
data lives in the context and session context vars. Backend-driven state (block mode,
heartbeat interval, firewall rules) is mutable so it can be refreshed at runtime.
"""

from __future__ import annotations

import dataclasses
import threading
from collections.abc import Callable

from bytehide_monitor.cloud.collectors.firewall_rules import EMPTY as EMPTY_RULES
from bytehide_monitor.cloud.collectors.firewall_rules import FirewallRules
from bytehide_monitor.cloud.config import cloud_config_loader
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.cloud.scanner.detector_registry import DetectorRegistry
from bytehide_monitor.cloud.scanner.scanner import Scanner
from bytehide_monitor.cloud.session.cloud_session_manager import CloudSessionManager
from bytehide_monitor.cloud.statistics.attack_wave_detector import AttackWaveDetector
from bytehide_monitor.cloud.statistics.route_store import RouteStore
from bytehide_monitor.cloud.statistics.statistics_store import StatisticsStore
from bytehide_monitor.core.threat_intel.threat_intel_store import ThreatIntelStore


class CloudEngine:
    def __init__(
        self,
        config: CloudMonitorConfig,
        scanner: Scanner,
        session_manager: CloudSessionManager,
        statistics: StatisticsStore,
        route_store: RouteStore,
        attack_wave_detector: AttackWaveDetector,
    ) -> None:
        self.config = config
        self.protections: dict[str, ProtectionConfig] = cloud_config_loader.resolve_protections(config)
        # Frozen copy of the preset/file baseline: a module dropped from the backend's
        # rule list reverts to this default (decoupled from runtime mutations of the
        # live ``protections`` map, e.g. a programmatic action override).
        self._baseline_protections: dict[str, ProtectionConfig] = {
            key: dataclasses.replace(value) for key, value in self.protections.items()
        }
        # Module keys last set by a backend rule, so a removed rule can be reverted.
        self.backend_module_keys: set[str] = set()
        self.scanner = scanner
        self.session_manager = session_manager
        self.statistics = statistics
        self.route_store = route_store
        self.attack_wave_detector = attack_wave_detector
        self.threat_intel_store = ThreatIntelStore()

        self._lock = threading.Lock()
        self._block_mode = False
        self._heartbeat_interval_ms = 60000
        self._firewall_sink: Callable[[FirewallRules], None] | None = None
        # Session ids currently blocked by the backend firewall config; tracked so a
        # session removed from the dashboard blocklist is unblocked on the next apply.
        self.backend_blocked_sessions: set[str] = set()

    def baseline_protection(self, module_value: str) -> ProtectionConfig | None:
        """Return the preset/file default for a module (used to revert removed rules)."""
        baseline = self._baseline_protections.get(module_value)
        return dataclasses.replace(baseline) if baseline is not None else None

    @staticmethod
    def create(config: CloudMonitorConfig) -> CloudEngine:
        statistics = StatisticsStore()
        scanner = Scanner(DetectorRegistry(), statistics)
        session_manager = CloudSessionManager()
        route_store = RouteStore()
        attack_wave_detector = AttackWaveDetector()
        return CloudEngine(config, scanner, session_manager, statistics, route_store, attack_wave_detector)

    def register_firewall_sink(self, sink: Callable[[FirewallRules], None]) -> None:
        self._firewall_sink = sink

    def apply_backend_config(
        self, block_mode: bool | None, heartbeat_interval_ms: int | None
    ) -> None:
        with self._lock:
            if block_mode is not None:
                self._block_mode = block_mode
            if heartbeat_interval_ms is not None and heartbeat_interval_ms > 0:
                self._heartbeat_interval_ms = heartbeat_interval_ms

    def apply_firewall_rules(self, rules: FirewallRules | None) -> None:
        sink = self._firewall_sink
        if sink is not None:
            sink(rules if rules is not None else EMPTY_RULES)

    @property
    def is_block_mode(self) -> bool:
        with self._lock:
            return self._block_mode

    @property
    def heartbeat_interval_ms(self) -> int:
        with self._lock:
            return self._heartbeat_interval_ms

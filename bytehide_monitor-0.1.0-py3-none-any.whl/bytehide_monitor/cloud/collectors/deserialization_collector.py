"""In-app deserialization sink collector (pickle/yaml). Scans the payload directly for RCE gadgets (value-direct,
like XXE) - the dangerous payload itself is the signal, no request-input correlation needed."""

from __future__ import annotations

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context import context as context_holder
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class DeserializationCollector:
    def __init__(self, engine: CloudEngine) -> None:
        if engine is None:
            raise ValueError("engine must not be None")
        self._engine = engine

    def report(self, payload: str) -> BlockDecision | None:
        return self._engine.scanner.scan_sink(
            ProtectionModuleType.UNSAFE_DESERIALIZATION,
            payload,
            context_holder.get(),
            self._engine.config,
            self._engine.protections,
            scan_value_directly=True,
        )

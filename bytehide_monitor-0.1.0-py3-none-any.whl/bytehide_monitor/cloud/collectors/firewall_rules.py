"""Backend-driven firewall rules evaluated per request.

Allowed/blocked IP CIDRs, blocked user-agent literals and regexes, and blocked
users. Immutable once built. Evaluation order mirrors .NET: an allowed-IP match
short-circuits to "not blocked", then blocked IPs, blocked user agents, blocked
users.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from re import Pattern

from bytehide_monitor.cloud.helpers.net import cidr_matcher


class FirewallRules:
    def __init__(
        self,
        allowed_ips: Sequence[str] | None = None,
        blocked_ips: Sequence[str] | None = None,
        blocked_user_agents: Sequence[str] | None = None,
        blocked_users: Sequence[str] | None = None,
    ) -> None:
        self._allowed_ips: list[str] = list(allowed_ips or [])
        self._blocked_ips: list[str] = list(blocked_ips or [])
        self._blocked_ua_literals: set[str] = {ua for ua in (blocked_user_agents or []) if ua}
        self._blocked_ua_patterns: list[Pattern[str]] = _compile_patterns(blocked_user_agents)
        self._blocked_users: set[str] = {u for u in (blocked_users or []) if u}

    def evaluate(
        self, ip: str | None, user_agent: str | None, user_id: str | None
    ) -> str | None:
        if cidr_matcher.matches_any(ip, self._allowed_ips):
            return None
        if cidr_matcher.matches_any(ip, self._blocked_ips):
            return "ip_blocked"
        if user_agent:
            if user_agent in self._blocked_ua_literals:
                return "user_agent_blocked"
            for pattern in self._blocked_ua_patterns:
                if pattern.search(user_agent):
                    return "user_agent_blocked"
        if user_id and user_id in self._blocked_users:
            return "user_blocked"
        return None


def _compile_patterns(patterns: Sequence[str] | None) -> list[Pattern[str]]:
    compiled: list[Pattern[str]] = []
    for pattern in patterns or []:
        if not pattern:
            continue
        try:
            compiled.append(re.compile(pattern, re.IGNORECASE))
        except re.error:
            # Not a valid regex: literal matching already covers it.
            continue
    return compiled


EMPTY = FirewallRules()

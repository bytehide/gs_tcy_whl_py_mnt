"""Rate-limiting configuration (defaults: disabled, 100 req / 60s window)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RateLimitConfig:
    enabled: bool = False
    max_requests: int = 100
    window_size_in_ms: int = 60000

    @classmethod
    def from_dict(cls, data: dict) -> RateLimitConfig:
        return cls(
            enabled=bool(data.get("enabled", False)),
            max_requests=int(data.get("maxRequests", 100)),
            window_size_in_ms=int(data.get("windowSizeInMS", 60000)),
        )

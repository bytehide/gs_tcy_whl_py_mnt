"""Cloud configuration model and loader."""

"""Anomaly-detection configuration (disabled by default; IP/UA checks on when enabled)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AnomalyDetectionConfig:
    enabled: bool = False
    detect_ip_changes: bool = True
    detect_user_agent_changes: bool = True
    detect_suspicious_patterns: bool = True

    @classmethod
    def from_dict(cls, data: dict) -> AnomalyDetectionConfig:
        return cls(
            enabled=bool(data.get("enabled", False)),
            detect_ip_changes=bool(data.get("detectIpChanges", True)),
            detect_user_agent_changes=bool(data.get("detectUserAgentChanges", True)),
            detect_suspicious_patterns=bool(data.get("detectSuspiciousPatterns", True)),
        )

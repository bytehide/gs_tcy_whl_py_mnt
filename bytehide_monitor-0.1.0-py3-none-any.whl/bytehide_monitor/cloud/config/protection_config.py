"""Configuration for a single protection module (action defaults to ``block``)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProtectionConfig:
    enabled: bool = True
    action: str = "block"
    custom_action_name: str | None = None
    interval_ms: int | None = None
    config: dict[str, Any] | None = field(default=None)

    @classmethod
    def from_dict(cls, data: dict) -> ProtectionConfig:
        return cls(
            enabled=bool(data.get("enabled", True)),
            action=str(data.get("action", "block")),
            custom_action_name=data.get("customActionName"),
            interval_ms=data.get("intervalMs"),
            config=data.get("config"),
        )

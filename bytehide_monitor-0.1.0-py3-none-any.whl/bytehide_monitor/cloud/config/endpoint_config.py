"""Per-endpoint protection override.

``force_protection_off`` disables all protections for the matched route (health
checks, webhooks). ``protections`` overrides only the named modules; ``rate_limit``
overrides the global rate limit for the route.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.cloud.config.rate_limit_config import RateLimitConfig


@dataclass
class EndpointConfig:
    method: str | None = None
    route: str | None = None
    force_protection_off: bool = False
    protections: dict[str, ProtectionConfig] | None = None
    rate_limit: RateLimitConfig | None = field(default=None)

    @classmethod
    def from_dict(cls, data: dict) -> EndpointConfig:
        protections = None
        raw_protections = data.get("protections")
        if isinstance(raw_protections, dict):
            protections = {
                name: ProtectionConfig.from_dict(value)
                for name, value in raw_protections.items()
                if isinstance(value, dict)
            }
        rate_limit = None
        raw_rate_limit = data.get("rateLimit")
        if isinstance(raw_rate_limit, dict):
            rate_limit = RateLimitConfig.from_dict(raw_rate_limit)
        return cls(
            method=data.get("method"),
            route=data.get("route"),
            force_protection_off=bool(data.get("forceProtectionOff", False)),
            protections=protections,
            rate_limit=rate_limit,
        )

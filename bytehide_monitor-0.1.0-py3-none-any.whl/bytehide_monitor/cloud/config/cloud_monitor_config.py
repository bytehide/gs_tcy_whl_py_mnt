"""Top-level local configuration model (1:1 with .NET ``MonitorConfig``).

Config-file keys are camelCase (``projectToken``, ``debugResponses``, ...), distinct
from the snake_case backend wire format. Resolution order (programmatic > env > JSON >
preset default) is applied by ``CloudConfigLoader``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bytehide_monitor.cloud.config.cloud_config import CloudConfig
from bytehide_monitor.cloud.config.protection_config import ProtectionConfig


@dataclass
class CloudMonitorConfig:
    name: str | None = None
    enabled: bool = True
    project_token: str | None = None
    preset: str | None = None
    debug_responses: bool = False
    auto_integration: bool = True
    throw_on_connection_failure: bool = False
    logging: dict[str, Any] | None = None
    protections: dict[str, ProtectionConfig] | None = None
    cloud: CloudConfig | None = field(default=None)

    @classmethod
    def from_dict(cls, data: dict) -> CloudMonitorConfig:
        protections = None
        raw_protections = data.get("protections")
        if isinstance(raw_protections, dict):
            protections = {
                name: ProtectionConfig.from_dict(value)
                for name, value in raw_protections.items()
                if isinstance(value, dict)
            }
        cloud = CloudConfig.from_dict(data["cloud"]) if isinstance(data.get("cloud"), dict) else None
        return cls(
            name=data.get("name"),
            enabled=bool(data.get("enabled", True)),
            project_token=data.get("projectToken"),
            preset=data.get("preset"),
            debug_responses=bool(data.get("debugResponses", False)),
            auto_integration=bool(data.get("autoIntegration", True)),
            throw_on_connection_failure=bool(data.get("throwOnConnectionFailure", False)),
            logging=data.get("logging"),
            protections=protections,
            cloud=cloud,
        )

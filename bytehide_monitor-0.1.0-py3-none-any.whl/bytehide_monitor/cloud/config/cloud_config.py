"""Cloud-specific configuration: rate limiting, anomaly detection, endpoint overrides."""

from __future__ import annotations

from dataclasses import dataclass, field

from bytehide_monitor.cloud.config.anomaly_detection_config import AnomalyDetectionConfig
from bytehide_monitor.cloud.config.endpoint_config import EndpointConfig
from bytehide_monitor.cloud.config.rate_limit_config import RateLimitConfig


@dataclass
class CloudConfig:
    rate_limit: RateLimitConfig | None = None
    anomaly_detection: AnomalyDetectionConfig | None = None
    endpoints: list[EndpointConfig] | None = field(default=None)

    @classmethod
    def from_dict(cls, data: dict) -> CloudConfig:
        rate_limit = (
            RateLimitConfig.from_dict(data["rateLimit"])
            if isinstance(data.get("rateLimit"), dict)
            else None
        )
        anomaly = (
            AnomalyDetectionConfig.from_dict(data["anomalyDetection"])
            if isinstance(data.get("anomalyDetection"), dict)
            else None
        )
        endpoints = None
        raw_endpoints = data.get("endpoints")
        if isinstance(raw_endpoints, list):
            endpoints = [
                EndpointConfig.from_dict(item) for item in raw_endpoints if isinstance(item, dict)
            ]
        return cls(rate_limit=rate_limit, anomaly_detection=anomaly, endpoints=endpoints)

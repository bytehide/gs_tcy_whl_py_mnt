"""Preset protection defaults (cloud preset only).

The cloud preset mirrors the .NET cloud defaults: every OWASP web detector is enabled
with ``block``, except LLM prompt injection which defaults to ``log`` (higher
false-positive rate).
"""

from __future__ import annotations

from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

CLOUD = "cloud"


def get_preset(preset_name: str | None) -> dict[str, ProtectionConfig] | None:
    """Return preset defaults keyed by module value, or ``None`` for custom/unknown."""
    if not preset_name or not preset_name.strip():
        return None
    if preset_name.strip().lower() == CLOUD:
        return _cloud_preset()
    return None


def _cloud_preset() -> dict[str, ProtectionConfig]:
    block_modules = (
        ProtectionModuleType.SQL_INJECTION,
        ProtectionModuleType.CROSS_SITE_SCRIPTING,
        ProtectionModuleType.PATH_TRAVERSAL,
        ProtectionModuleType.COMMAND_INJECTION,
        ProtectionModuleType.SERVER_SIDE_REQUEST_FORGERY,
        ProtectionModuleType.LDAP_INJECTION,
        ProtectionModuleType.XML_EXTERNAL_ENTITY,
        ProtectionModuleType.NO_SQL_INJECTION,
        ProtectionModuleType.TEMPLATE_INJECTION,
        ProtectionModuleType.UNSAFE_DESERIALIZATION,
        ProtectionModuleType.OPEN_REDIRECT,
        ProtectionModuleType.HTTP_RESPONSE_SPLITTING,
    )
    preset: dict[str, ProtectionConfig] = {
        module.value: _action_config("block") for module in block_modules
    }
    preset[ProtectionModuleType.LLM_PROMPT_INJECTION.value] = _action_config("log")
    # Request/response-level OWASP-API detectors. Default ``block`` (parity with the injection
    # detectors): for an API gateway the safe default is to reject the attack, and the dashboard
    # can still relax any of them to ``log`` per project. (Absent from the heartbeat -> this preset
    # baseline applies; present -> the dashboard action wins.)
    preset[ProtectionModuleType.JWT_ATTACK.value] = _action_config("block")
    preset[ProtectionModuleType.UNAUTHENTICATED_ACCESS.value] = _action_config("block")
    preset[ProtectionModuleType.MASS_ASSIGNMENT.value] = _action_config("block")
    preset[ProtectionModuleType.BROKEN_AUTH.value] = _action_config("block")
    preset[ProtectionModuleType.DATA_EXPOSURE.value] = _action_config("block")
    preset[ProtectionModuleType.BOLA_ENUMERATION.value] = _action_config("block")
    return preset


def _action_config(action: str) -> ProtectionConfig:
    return ProtectionConfig(enabled=True, action=action)

"""Loads and finalizes the cloud configuration.

Reads a ``monitor-config.json``-style file (from ``BYTEHIDE_MONITOR_CONFIG`` or a
known name in the working/base directory), then applies environment overrides
following the resolution order (programmatic > env var > JSON file > preset default).
Loading never raises on malformed input: it logs and returns a default config so the
SDK degrades gracefully (offline-first).
"""

from __future__ import annotations

import json
import os
import sys

from bytehide_monitor.cloud.config import protection_presets
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.logging.logger import MonitorLogger

# Searched in order in the working directory and the application base directory.
CONFIG_FILE_NAMES = (
    "monitor.config.json",
    "bytehide.monitor.json",
    "bytehide.monitor.config.json",
    "monitor-config.json",
    "bytehide-monitor-config.json",
)


def load() -> CloudMonitorConfig:
    config = _read_from_sources()
    if config is None:
        config = CloudMonitorConfig()
    return apply_environment_overrides(config)


def apply_environment_overrides(config: CloudMonitorConfig) -> CloudMonitorConfig:
    token = env_vars.resolve_token()
    if token is not None:
        config.project_token = token
    if env_vars.get_bool(env_vars.DISABLE, False):
        config.enabled = False
    if env_vars.get_bool(env_vars.DEBUG, False):
        config.debug_responses = True
    MonitorLogger.debug("D001_TRACE", "Cloud configuration environment overrides applied")
    return config


def resolve_protections(config: CloudMonitorConfig | None) -> dict[str, ProtectionConfig]:
    """Merge preset defaults with explicit overrides (explicit entries win)."""
    merged: dict[str, ProtectionConfig] = {}
    if config is None:
        return merged
    preset_defaults = protection_presets.get_preset(config.preset)
    if preset_defaults is not None:
        merged.update(preset_defaults)
    if config.protections is not None:
        merged.update(config.protections)
    return merged


def _read_from_sources() -> CloudMonitorConfig | None:
    path = env_vars.get(env_vars.CONFIG)
    if path is not None:
        config = _read_from_file(path)
        if config is None:
            MonitorLogger.warning(
                "W001_CONFIG_NOT_FOUND",
                "Configured monitor config file was not found or could not be read",
            )
        return config

    for directory in _search_directories():
        for name in CONFIG_FILE_NAMES:
            candidate = os.path.join(directory, name)
            if os.path.isfile(candidate):
                return _read_from_file(candidate)
    MonitorLogger.debug("D001_TRACE", "No monitor config file found")
    return None


def _search_directories() -> list[str]:
    directories = [os.getcwd()]
    base = os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv and sys.argv[0] else None
    if base and base not in directories:
        directories.append(base)
    return directories


def _read_from_file(path: str) -> CloudMonitorConfig | None:
    if not os.path.isfile(path):
        return None
    try:
        # Monitor-internal read: suppress the fs sink so this open() is never inspected
        # (and never self-blocked) when sinks are already installed, e.g. on a re-init.
        # utf-8-sig transparently strips a leading BOM (Windows editors often add one) and
        # is byte-identical to utf-8 otherwise, so a BOM no longer breaks json.load.
        with reentry_guard.internal(), open(path, encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        MonitorLogger.error("E009_CONFIG_FORMAT", f"Failed to parse monitor config: {type(exc).__name__}")
        return None
    if not isinstance(data, dict):
        return None
    return CloudMonitorConfig.from_dict(data)

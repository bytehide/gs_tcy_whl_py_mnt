"""BOLA / IDOR enumeration detector (request-level + state).

Broken Object Level Authorization (OWASP API1) cannot be decided from a single request: a RASP has no
ownership model, so it cannot know that ``report_id=2`` does not belong to the caller. What it *can*
detect is the EXPLOITATION PATTERN - one client walking many distinct object IDs on an "?id=" style
endpoint in a short window (``1,2,3,4,5,...``). That enumeration is the signature of a BOLA/IDOR sweep
and is what the crAPI "access mechanic reports of other users" challenge actually does.

How it works: on every request that carries an object identifier (a query/path parameter whose name
looks like an id, or a numeric trailing path segment), it records ``(identity, route-template) -> set of
distinct IDs seen`` in a sliding window. When the number of DISTINCT IDs from one identity on one route
exceeds ``max_distinct_ids`` within ``window_seconds``, it flags the enumeration. A single object access
never trips it (that needs an ownership policy); the rapid sweep does.

Identity precedence: authenticated user id -> Authorization token (hashed) -> session cookie -> client IP.
Tying the window to the credential means one attacker token enumerating IDs is caught even behind a shared
proxy IP.

Config keys (all optional):
* ``id_params``: parameter-name patterns that denote an object id (default: ``*id`` / ``id`` family).
* ``max_distinct_ids``: distinct IDs allowed in the window before flagging (default 3 -> the 4th trips).
* ``window_seconds``: sliding-window length in seconds (default 30).
* ``routes``: optional glob/substring allowlist of routes to watch (default: any route carrying an id).

State is IN MEMORY and per-process (like the brute-force detector). Fail-open: any error -> no threat.
"""

from __future__ import annotations

import fnmatch
import hashlib
import re
import threading
import time
from collections.abc import Mapping, Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DEFAULT_ID_PARAMS = ("id", "*_id", "*id", "report_id", "order_id", "user_id", "vehicle_id", "pid", "uuid")
_DEFAULT_MAX_DISTINCT = 3
_DEFAULT_WINDOW_SECONDS = 30
# An id value worth tracking: a bare integer, or a uuid/hex-ish token. Free-text values are ignored
# (they are not object identifiers being enumerated).
_INT_RE = re.compile(r"^\d{1,18}$")
_UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$")
_DIGITS_RE = re.compile(r"\d+")

# Module-level shared state: { key -> { id_value -> last_seen_epoch_seconds } }. Guarded by a lock.
_STATE: dict[str, dict[str, float]] = {}
_LOCK = threading.Lock()


class BolaEnumerationDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.BOLA_ENUMERATION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        try:
            return self._evaluate(context)
        except Exception:  # noqa: BLE001 - fail-open
            return None

    def _evaluate(self, context: ContextObject) -> DetectionResult | None:
        if context is None:
            return None
        config = _config(context)

        route_key = _route_key(context)
        if route_key is None:
            return None

        watch_routes = _str_list(config.get("routes"))
        if watch_routes and not _matches_any(route_key, watch_routes):
            return None

        id_params = _str_list(config.get("id_params")) or list(_DEFAULT_ID_PARAMS)
        object_id = _extract_object_id(context, id_params)
        if object_id is None:
            return None

        max_distinct = max(1, _config_int(config, "max_distinct_ids", _DEFAULT_MAX_DISTINCT))
        window_seconds = max(1, _config_int(config, "window_seconds", _DEFAULT_WINDOW_SECONDS))

        # BOLA/IDOR is an AUTHORIZED-but-not-owner attack: the caller is logged in and walks other
        # users' object IDs. Track enumeration per caller CREDENTIAL by default; skip anonymous,
        # credential-less traffic (that is "unauthenticated access" territory and pooling it by a
        # shared/blank IP would false-positive across unrelated anonymous users). Opt out with
        # ``require_credential: false`` to also track by IP.
        require_credential = _config_bool(config, "require_credential", default=True)
        identity = _identity(context)
        if identity is None:
            if require_credential:
                return None
            identity = f"ip:{context.client_ip or 'unknown'}"
        key = f"{identity}|{route_key}"

        now = time.time()
        distinct = _record_and_count(key, object_id, now, window_seconds)
        if distinct <= max_distinct:
            return None

        metadata: dict[str, Any] = {
            "Route": route_key[:256],
            "DistinctIds": distinct,
            "MaxDistinctIds": max_distinct,
            "WindowSeconds": window_seconds,
            "LastObjectId": str(object_id)[:64],
        }
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        overshoot = distinct - max_distinct
        confidence = min(0.95, 0.6 + 0.07 * overshoot)
        return DetectionResult.threat(
            self.type().value,
            f"BOLA/IDOR enumeration on '{route_key[:128]}': {distinct} distinct object IDs from one "
            f"client in {window_seconds}s (max {max_distinct})",
            confidence,
            metadata,
        )


def _record_and_count(key: str, object_id: str, now: float, window_seconds: int) -> int:
    """Record this (key, id) sighting, trim the window, and return the distinct-id count in-window."""
    cutoff = now - window_seconds
    with _LOCK:
        bucket = _STATE.get(key)
        if bucket is None:
            bucket = {}
            _STATE[key] = bucket
        bucket[object_id] = now
        # Trim stale ids out of the window.
        stale = [oid for oid, ts in bucket.items() if ts < cutoff]
        for oid in stale:
            del bucket[oid]
        # Opportunistic cap so a long-lived process cannot grow the bucket unbounded.
        if len(bucket) > 4096:
            for oid in sorted(bucket, key=bucket.get)[:2048]:
                del bucket[oid]
        return len(bucket)


def _route_key(context: ContextObject) -> str | None:
    """Stable per-endpoint key. Prefer the framework route pattern (already id-free, e.g.
    ``shop/orders/<int:id>``); otherwise normalize digits in the URL path to ``#`` so siblings that
    differ only by the id share a bucket."""
    route = context.route
    if route and route.strip():
        return route.strip()
    url = context.url
    if not url:
        return None
    path = url
    scheme_idx = path.find("://")
    if scheme_idx >= 0:
        path = path[scheme_idx + 3 :]
        slash = path.find("/")
        path = path[slash:] if slash >= 0 else "/"
    cut = _index_of_any(path, "?", "#")
    if cut >= 0:
        path = path[:cut]
    return _DIGITS_RE.sub("#", path) or None


def _extract_object_id(context: ContextObject, id_params: Sequence[str]) -> str | None:
    """Pull an object identifier from path params, query params, or a numeric trailing path segment."""
    # 1) Path params (Django/Flask converters): an id-named or numeric value.
    candidate = _id_from_mapping(context.path_params, id_params, numeric_any_name=True)
    if candidate is not None:
        return candidate
    # 2) Query params: a value whose NAME matches an id pattern.
    candidate = _id_from_mapping(context.query, id_params, numeric_any_name=False)
    if candidate is not None:
        return candidate
    # 3) Numeric trailing path segment (``/mechanic/report/5``).
    route = context.route or ""
    url = context.url or ""
    src = url if url else route
    if src:
        path = src
        cut = _index_of_any(path, "?", "#")
        if cut >= 0:
            path = path[:cut]
        segments = [s for s in path.rstrip("/").split("/") if s]
        if segments and _INT_RE.match(segments[-1]):
            return segments[-1]
    return None


def _id_from_mapping(
    mapping: Mapping[str, str] | None, id_params: Sequence[str], numeric_any_name: bool
) -> str | None:
    if not mapping:
        return None
    for name, value in mapping.items():
        if value is None:
            continue
        sval = str(value).strip()
        if not _looks_like_id(sval):
            continue
        nm = str(name).lower()
        if _matches_any(nm, id_params):
            return sval
        if numeric_any_name and _INT_RE.match(sval):
            return sval
    return None


def _looks_like_id(value: str) -> bool:
    if not value:
        return False
    return bool(_INT_RE.match(value) or _UUID_RE.match(value))


def _identity(context: ContextObject) -> str | None:
    """Per-caller CREDENTIAL identity (user id -> Authorization token -> session cookie), or ``None``
    when the request carries no credential. IP is intentionally NOT a credential here (see caller)."""
    user = getattr(context, "user", None)
    uid = getattr(user, "id", None) if user is not None else None
    if uid:
        return f"u:{uid}"
    auth = context.get_header("Authorization")
    if auth and auth.strip():
        digest = hashlib.sha256(auth.strip().encode("utf-8", "replace")).hexdigest()[:16]
        return f"a:{digest}"
    cookies = context.cookies or {}
    for name in ("session", "sessionid", "sid", "jsessionid", "connect.sid", "token"):
        for key, value in cookies.items():
            if isinstance(key, str) and key.lower() == name and value:
                digest = hashlib.sha256(str(value).encode("utf-8", "replace")).hexdigest()[:16]
                return f"c:{digest}"
    return None


def _config(context: ContextObject) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None)
    return cfg if isinstance(cfg, dict) else {}


def _index_of_any(value: str, *chars: str) -> int:
    for i, ch in enumerate(value):
        if ch in chars:
            return i
    return -1


def _matches_any(value: str, patterns: Sequence[str]) -> bool:
    lowered = value.lower()
    for pattern in patterns:
        if not pattern:
            continue
        pat = pattern.lower()
        if "*" in pat or "?" in pat or "[" in pat:
            if fnmatch.fnmatch(lowered, pat):
                return True
        elif pat == lowered or pat in lowered:
            return True
    return False


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


def _config_bool(config: dict[str, Any], key: str, default: bool) -> bool:
    raw = config.get(key)
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        return raw.strip().lower() in {"1", "true", "yes", "on"}
    return default


def _config_int(config: dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key)
    try:
        if isinstance(raw, bool):
            return default
        if isinstance(raw, (int, float)):
            return int(raw)
        if isinstance(raw, str) and raw.strip().lstrip("-").isdigit():
            return int(raw.strip())
    except (ValueError, TypeError):
        return default
    return default


def _reset_state_for_tests() -> None:
    """Clear the shared enumeration state. Test-only helper (state is module-level, per-process)."""
    with _LOCK:
        _STATE.clear()

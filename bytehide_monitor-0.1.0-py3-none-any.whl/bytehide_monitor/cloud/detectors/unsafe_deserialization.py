"""Unsafe deserialization detector (pickle / PyYAML).

Scans the payload handed to ``pickle.loads`` / ``yaml.load`` directly (value-direct, like XXE): a malicious
pickle carries a GLOBAL opcode referencing a dangerous module plus a REDUCE opcode (RCE gadget), and an unsafe
YAML carries a ``!!python/...`` tag. Benign pickles/YAML of plain data have neither.
"""

from __future__ import annotations

from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

# YAML object-construction tags that execute code.
_YAML_TAGS = ("!!python/object", "!!python/object/apply", "!!python/object/new", "!!python/name", "!!python/module")
# Modules whose presence in a pickle GLOBAL opcode indicates an RCE gadget.
_PICKLE_MODULES = ("os", "posix", "nt", "subprocess", "builtins", "__builtin__", "commands", "pty", "socket",
                   "shutil", "importlib", "operator", "webbrowser", "ctypes")
# Callables commonly chained for RCE.
_PICKLE_FUNCS = ("system", "popen", "eval", "exec", "spawn", "getoutput", "check_output", "call", "__import__",
                 "compile", "open", "remove")
# High-confidence RCE tokens: once we know the payload is a pickle stream (a control-char opcode is present),
# any of these as a substring means an RCE gadget. They never occur in benign serialized data, so matching here
# does not need REDUCE adjacency (covers synthetic/proto 2-5 streams like b"\x80\x03cbuiltins.os.system...").
_PICKLE_RCE_TOKENS = (
    "system", "popen", "subprocess", "getoutput", "check_output", "builtins", "__builtin__", "posix",
    "__reduce__", "__import__", "commands", "pty", "importlib", "ctypes", "webbrowser", "os.system",
    "nt.system", "spawn", "exec", "eval",
)


class UnsafeDeserializationDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.UNSAFE_DESERIALIZATION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return user_input is None or len(user_input) < 2

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        text = user_input
        lower = text.lower()

        for tag in _YAML_TAGS:
            if tag in lower:
                return _threat("yaml", tag, text)

        # Pickle RCE — protocol-agnostic. The module/callable names are stored as readable substrings in every
        # protocol; what differs is the framing:
        #   - proto 0/1: GLOBAL 'c' + "module\nfunc\n"            (e.g. b"cos\nsystem\n")
        #   - proto 2-5: PROTO header '\x80', STACK_GLOBAL '\x93', SHORT_BINUNICODE '\x8c', FRAME '\x95'
        # A control-char opcode ('\x80'/'\x93'/'\x8c'/'\x95') never appears in benign HTTP text, so its presence
        # alone confirms a pickle stream; we also keep the strict proto-0 GLOBAL pattern. Inside such a stream the
        # RCE tokens below do not occur in benign serialized data, so matching one is a high-confidence detection.
        is_pickle_stream = any(op in text for op in ("\x80", "\x93", "\x8c", "\x95"))
        has_reduce = "R" in text or "\x93" in text  # REDUCE / STACK_GLOBAL

        if is_pickle_stream:
            for tok in _PICKLE_RCE_TOKENS:
                if tok in lower:  # case-insensitive: safe, no benign input is a pickle stream (control-char gated)
                    return _threat("pickle", tok, text)
            # A pickle stream that builds+reduces an arbitrary global (GLOBAL 'c'/STACK_GLOBAL '\x93' + REDUCE 'R')
            # over a sensitive module is unsafe deserialization regardless of the exact callable (covers
            # os.deletefile, sys.modules, pickle.loads, etc.). Still control-char gated -> no benign FP.
            if has_reduce and ("\x93" in text or "c" in text):
                for mod in (*_PICKLE_MODULES, "sys", "pickle", "marshal", "shelve", "code", "codecs", "base64"):
                    if mod in lower:
                        return _threat("pickle", mod, text)
        # Proto-0 GLOBAL: 'c<module>\n<func>\n' followed by a REDUCE — precise, no control chars.
        for mod in _PICKLE_MODULES:
            if (f"c{mod}\n" in text or f"\n{mod}\n" in text) and has_reduce:
                if any(f in text for f in _PICKLE_FUNCS) or has_reduce:
                    return _threat("pickle", mod, text)
        return DetectionResult.success()


def _threat(kind: str, evidence: str, payload: str) -> DetectionResult:
    snippet = payload if len(payload) <= 120 else payload[:120] + "..."
    result = DetectionResult.threat(
        ProtectionModuleType.UNSAFE_DESERIALIZATION.value,
        f"Unsafe {kind} deserialization detected: '{evidence}'",
        0.95,
    )
    result.with_metadata("Format", kind)
    result.with_metadata("MatchedPattern", evidence)
    result.with_metadata("Snippet", snippet)
    result.with_metadata("Operation", f"{kind}.load")
    return result

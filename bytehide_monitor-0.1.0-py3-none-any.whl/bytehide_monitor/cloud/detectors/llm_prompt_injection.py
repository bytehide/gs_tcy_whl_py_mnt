"""LLM prompt injection detector (OWASP LLM Top 10 - LLM01).

Pure, stateless port of the .NET ``PromptInjectionDetector``. Inspects a single user
message for system-prompt manipulation, instruction injection, jailbreak attempts,
data exfiltration, context escape, role-playing starters and encoding/obfuscation,
escalating confidence when several pattern categories match at once.

Not part of the inbound request scan (mirroring .NET, where the middleware entry is a
no-op and detection lives at the LLM call site - in this port, the AI sink validating
against the gateway). Reachable only through the standalone ``validate_input`` API.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors import prompt_injection_patterns as patterns
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_BASE64_LIKE = re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")
_HEX_ESCAPE = re.compile(r"(\\x[0-9a-fA-F]{2}){10,}")
_UNICODE_ESCAPE = re.compile(r"(\\u[0-9a-fA-F]{4}){10,}")
_SUBSTITUTION_HINT = re.compile(r"(rot|rot13|caesar|shift|decode|decrypt)\s*\(", re.IGNORECASE)
_OBFUSCATION_PATTERNS = (_BASE64_LIKE, _HEX_ESCAPE, _UNICODE_ESCAPE, _SUBSTITUTION_HINT)


class LlmPromptInjectionDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.LLM_PROMPT_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return user_input is None or not user_input.strip()

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if user_input is None or not user_input.strip():
            return DetectionResult.success()
        message = user_input.lower().strip()

        if _contains_obfuscation(message):
            return _threat(user_input, "obfuscated content detected", "Obfuscation", 0.65)

        spm = _first_contained(message, patterns.SYSTEM_PROMPT_MANIPULATION)
        if spm is not None:
            return _threat(user_input, spm, "System Prompt Manipulation", 0.95)

        ii = _first_contained(message, patterns.INSTRUCTION_INJECTION)
        if ii is not None:
            return _threat(user_input, ii, "Instruction Injection", 0.90)

        jb = _first_contained(message, patterns.JAILBREAK_ATTEMPTS)
        if jb is not None:
            return _threat(user_input, jb, "Jailbreak Attempt", 0.95)

        de = _first_contained(message, patterns.DATA_EXFILTRATION)
        if de is not None:
            return _threat(user_input, de, "Data Exfiltration", 0.90)

        ce = _first_contained(message, patterns.CONTEXT_ESCAPE)
        if ce is not None:
            return _threat(user_input, ce, "Context Escape", 0.85)

        rp = _first_role_playing(message)
        if rp is not None:
            return _threat(user_input, rp, "Role-Playing", 0.70)

        pattern_count = _count_pattern_matches(message)
        if pattern_count >= 2:
            confidence = min(0.98, 0.70 + pattern_count * 0.10)
            return _threat(user_input, "multiple injection patterns detected", "Multiple Patterns", confidence)

        return DetectionResult.success()


def _threat(payload: str, matched_pattern: str, category: str, confidence: float) -> DetectionResult:
    # Matches the backend LlmPromptInjectionMetadata contract. Model / Provider / Method
    # are unknown at the inbound layer (no LLM call here); the AI sink fills them.
    metadata = {
        "MatchedPattern": matched_pattern,
        "MessageLength": len(payload),
    }
    return DetectionResult.threat(
        ProtectionModuleType.LLM_PROMPT_INJECTION.value,
        f"LLM prompt injection detected: {matched_pattern}",
        confidence,
        metadata,
    )


def _first_contained(message: str, pattern_list: Sequence[str]) -> str | None:
    for pattern in pattern_list:
        if pattern in message:
            return pattern
    return None


def _first_role_playing(message: str) -> str | None:
    prefix = message[:100] if len(message) > 100 else message
    for pattern in patterns.ROLE_PLAYING_STARTERS:
        if prefix.startswith(pattern) or pattern in prefix:
            return pattern
    return None


def _count_pattern_matches(message: str) -> int:
    count = 0
    if _first_contained(message, patterns.SYSTEM_PROMPT_MANIPULATION) is not None:
        count += 1
    if _first_contained(message, patterns.INSTRUCTION_INJECTION) is not None:
        count += 1
    if _first_contained(message, patterns.JAILBREAK_ATTEMPTS) is not None:
        count += 1
    if _first_contained(message, patterns.DATA_EXFILTRATION) is not None:
        count += 1
    if _first_contained(message, patterns.CONTEXT_ESCAPE) is not None:
        count += 1
    if _first_role_playing(message) is not None:
        count += 1
    return count


def _contains_obfuscation(message: str) -> bool:
    return any(pattern.search(message) for pattern in _OBFUSCATION_PATTERNS)

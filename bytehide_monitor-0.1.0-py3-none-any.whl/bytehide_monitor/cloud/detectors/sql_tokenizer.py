"""SQL tokenizer for differential analysis (Aikido Zen approach).

Pure, deterministic 1:1 port of the .NET/Java ``SqlTokenizer``: lexical
tokenization of SQL plus differential and pattern-based detection of SQL injection
within a user-supplied input. Every method derives its result solely from its
arguments.
"""

from __future__ import annotations

import enum
import re
from collections import Counter
from typing import NamedTuple


class TokenType(enum.Enum):
    KEYWORD = "KEYWORD"
    IDENTIFIER = "IDENTIFIER"
    STRING = "STRING"
    NUMBER = "NUMBER"
    OPERATOR = "OPERATOR"
    COMMENT = "COMMENT"
    WHITESPACE = "WHITESPACE"
    PUNCTUATION = "PUNCTUATION"
    UNKNOWN = "UNKNOWN"


class Token(NamedTuple):
    type: TokenType
    value: str
    position: int


class DetectionOutcome(NamedTuple):
    injected: bool
    injected_content: str | None
    confidence: float

    @staticmethod
    def none() -> DetectionOutcome:
        return DetectionOutcome(False, None, 0.0)


# Common SQL strings that appear in most queries (compared lowercased).
_COMMON_SQL_STRINGS = {
    s.lower()
    for s in (
        "SELECT *", "SELECT COUNT(*)", "INSERT INTO", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN",
        "LEFT OUTER JOIN", "RIGHT OUTER JOIN", "DELETE FROM", "ORDER BY", "GROUP BY",
        "ON CONFLICT", "ON CONFLICT DO UPDATE", "ON CONFLICT DO NOTHING",
        "ON DUPLICATE KEY", "ON DUPLICATE KEY UPDATE", "DO UPDATE", "DO NOTHING",
        "COUNT(*)", "IS NULL", "IS NOT NULL", "NOT EXISTS", "DISTINCT ON", "[]",
    )
}

# SQL keywords that indicate potential injection (compared lowercased).
_SQL_KEYWORDS = {
    s.lower()
    for s in (
        "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER", "TRUNCATE",
        "FROM", "WHERE", "JOIN", "INNER", "LEFT", "RIGHT", "OUTER", "ON", "AND", "OR",
        "UNION", "ORDER", "BY", "GROUP", "HAVING", "LIMIT", "OFFSET",
        "EXEC", "EXECUTE", "DECLARE", "SET", "BEGIN", "END", "IF", "ELSE", "WHILE",
        "CAST", "CONVERT", "CHAR", "VARCHAR", "CONCAT", "SUBSTRING",
        "WAITFOR", "DELAY", "SLEEP", "BENCHMARK",
    )
}

# High-signal SQL keywords: rarely appear in benign data (unlike ORDER/AND/OR/BY/SET/IN/ON which are common
# English words or appear in IDs like ``order#9876``). Used to gate the comment-combo and differential checks.
_HIGH_SIGNAL_KEYWORDS = {
    s.lower()
    for s in (
        "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER", "TRUNCATE", "UNION",
        "EXEC", "EXECUTE", "DECLARE", "WAITFOR", "DELAY", "SLEEP", "BENCHMARK", "CAST", "CONVERT",
    )
}

# Dangerous SQL functions/commands (compared lowercased).
_DANGEROUS_FUNCTIONS = {
    s.lower()
    for s in (
        "xp_cmdshell", "sp_executesql", "OPENROWSET", "OPENQUERY", "OPENDATASOURCE",
        "sys.xp_cmdshell", "LOAD_FILE", "INTO OUTFILE", "INTO DUMPFILE",
    )
}

_DANGEROUS_INPUT_PATTERN = re.compile(
    r"('|\"|;)\s*(DROP|DELETE|UPDATE|INSERT|ALTER|CREATE|TRUNCATE|EXEC|EXECUTE|UNION|SELECT)\s+",
    re.IGNORECASE,
)
_SQL_COMMENT_PATTERN = re.compile(r"(--|#|/\*)")
_SHORT_TWO_WORDS = re.compile(r"^[a-z]+ [a-z]+$", re.IGNORECASE)
_LETTER_EQUALS = re.compile(r"^[a-z]=$", re.IGNORECASE)
_ORDER_BY_DIRECTION = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]* +(ASC|DESC)$", re.IGNORECASE)
_QUOTED_PREFIX = re.compile(r"^'[a-z0-9-]+$", re.IGNORECASE)
_QUOTED_SUFFIX = re.compile(r"^[a-z0-9-]+'$", re.IGNORECASE)
_DECIMAL_NUMBER = re.compile(r"^-?\d+\.\d+$")
_TABLE_COLUMN = re.compile(
    r"^(\.[a-zA-Z_][a-zA-Z0-9_]*|[a-zA-Z_][a-zA-Z0-9_]*\.|"
    r"[a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)$",
    re.IGNORECASE,
)
_INTEGER_NUMBER = re.compile(r"^-?[0-9]+$")

_OPERATOR_PUNCTUATION_CHARS = "=<>!+-*/%&|^~()[]{},.;:"
_PUNCTUATION_CHARS = "()[]{},.;:"


def _is_null_or_whitespace(value: str | None) -> bool:
    return not value or not value.strip()


class SqlTokenizer:
    def detect_injection(self, query: str | None, user_input: str | None) -> DetectionOutcome:
        query = query.lower() if query is not None else None
        user_input = user_input.lower() if user_input is not None else None

        if _is_null_or_whitespace(query) or _is_null_or_whitespace(user_input):
            return DetectionOutcome.none()
        assert query is not None and user_input is not None

        # 1. Query must contain the user input.
        if user_input not in query:
            return DetectionOutcome.none()

        # 2. Known-safe SQL string.
        if self.is_common_sql_string(user_input):
            return DetectionOutcome.none()

        # 3. Direct dangerous SQL pattern in the user input (e.g. "1' DROP TABLE users--").
        match = _DANGEROUS_INPUT_PATTERN.search(user_input)
        if match:
            return DetectionOutcome(True, f"Dangerous SQL pattern: {match.group().strip()}", 0.95)

        # 4. A REAL SQL comment (``--``/``/*`` or a ``#`` that starts a comment, not glued inside data like
        #    ``order#9876``) combined with a high-signal keyword TOKEN (not a substring like ``or`` in ``order``).
        if _has_real_comment(user_input):
            for token in self.tokenize(user_input):
                if token.type == TokenType.KEYWORD and token.value.lower() in _HIGH_SIGNAL_KEYWORDS:
                    return DetectionOutcome(True, f"SQL comment with keyword: {token.value}", 0.90)

        # 5. Tokenize original query.
        original_tokens = self.tokenize(query)
        if not original_tokens:
            return DetectionOutcome.none()

        # 6. Trim the user input.
        trimmed = user_input.strip()
        if len(trimmed) <= 1:
            return DetectionOutcome.none()

        # 7. Replace user input with a same-length safe string (Aikido's key step).
        safe_replacement = "a" * len(trimmed)
        query_without_input = query.replace(trimmed, safe_replacement)

        # 8. Tokenize query without the user input.
        tokens_without_input = self.tokenize(query_without_input)

        # 9. Drop whitespace tokens for comparison.
        orig_no_ws = _without_whitespace(original_tokens)
        safe_no_ws = _without_whitespace(tokens_without_input)

        # 10. Token count changed: main detection. BUT a stray quote in otherwise benign text (a legitimate name
        # like ``O'Brien`` embedded in ``WHERE name = '...'``) also changes the token count without injecting any
        # SQL. The discriminator is WHAT the input adds: compare the DANGEROUS tokens (keywords, comparison
        # operators, comments, ';', parens) of the real query vs the same query with the input neutralized. If the
        # input introduced no NEW dangerous token (only identifiers/strings/numbers, as a quoted name does), it is
        # benign data, not injection. A real tautology (`' OR '1'='1`) adds an OR keyword + '=' operator.
        if len(orig_no_ws) != len(safe_no_ws):
            if not _added_dangerous_tokens(orig_no_ws, safe_no_ws):
                return DetectionOutcome.none()
            delta = abs(len(orig_no_ws) - len(safe_no_ws))
            injected_content = _extract_injected_content(orig_no_ws, safe_no_ws)
            confidence = min(1.0, 0.7 + delta * 0.1)
            return DetectionOutcome(True, injected_content, confidence)

        # 11. Comment structure changed (a comment necessarily carries a SQL payload).
        if _have_comments_changed(original_tokens, tokens_without_input):
            return DetectionOutcome(True, "Comment structure altered", 0.8)

        return DetectionOutcome.none()

    def is_common_sql_string(self, user_input: str) -> bool:
        if user_input in _COMMON_SQL_STRINGS:
            return True
        if len(user_input) <= 5 and _SHORT_TWO_WORDS.match(user_input):
            return True
        if len(user_input) == 2 and user_input.endswith("=") and _LETTER_EQUALS.match(user_input):
            return True
        if "asc" in user_input or "desc" in user_input:
            if _ORDER_BY_DIRECTION.match(user_input):
                return True
        if user_input.startswith("'") and len(user_input) <= 200 and "--" not in user_input:
            if _QUOTED_PREFIX.match(user_input):
                return True
        if user_input.endswith("'") and len(user_input) <= 200 and "--" not in user_input:
            if _QUOTED_SUFFIX.match(user_input):
                return True
        if "." in user_input and _DECIMAL_NUMBER.match(user_input):
            return True
        if "." in user_input and _TABLE_COLUMN.match(user_input):
            return True
        if _INTEGER_NUMBER.match(user_input):
            return True
        return False

    def tokenize(self, sql: str | None) -> list[Token]:
        if _is_null_or_whitespace(sql):
            return []
        assert sql is not None
        tokens: list[Token] = []
        pos = 0
        length = len(sql)
        while pos < length:
            current = sql[pos]
            if current.isspace():
                start = pos
                while pos < length and sql[pos].isspace():
                    pos += 1
                tokens.append(Token(TokenType.WHITESPACE, sql[start:pos], start))
                continue
            if current in ("'", '"'):
                token, pos = _parse_string(sql, pos)
                tokens.append(token)
                continue
            if current == "-" and pos + 1 < length and sql[pos + 1] == "-":
                token, pos = _parse_until_newline(sql, pos, 2)
                tokens.append(token)
                continue
            if current == "/" and pos + 1 < length and sql[pos + 1] == "*":
                token, pos = _parse_block_comment(sql, pos)
                tokens.append(token)
                continue
            if current == "#":
                token, pos = _parse_until_newline(sql, pos, 1)
                tokens.append(token)
                continue
            if current.isdigit():
                token, pos = _parse_number(sql, pos)
                tokens.append(token)
                continue
            if current.isalpha() or current in ("_", "@"):
                token, pos = _parse_identifier_or_keyword(sql, pos)
                tokens.append(token)
                continue
            if current in _OPERATOR_PUNCTUATION_CHARS:
                token, pos = _parse_operator(sql, pos)
                tokens.append(token)
                continue
            tokens.append(Token(TokenType.UNKNOWN, current, pos))
            pos += 1
        return tokens


# ---------- token parsers (return (token, new_pos)) ----------


def _parse_string(sql: str, pos: int):
    quote = sql[pos]
    start = pos
    length = len(sql)
    pos += 1
    while pos < length:
        if sql[pos] == quote:
            if pos + 1 < length and sql[pos + 1] == quote:
                pos += 2
            else:
                pos += 1
                break
        elif sql[pos] == "\\" and pos + 1 < length:
            pos += 2
        else:
            pos += 1
    return Token(TokenType.STRING, sql[start:pos], start), pos


def _parse_until_newline(sql: str, pos: int, skip: int):
    start = pos
    length = len(sql)
    pos += skip
    while pos < length and sql[pos] not in ("\n", "\r"):
        pos += 1
    return Token(TokenType.COMMENT, sql[start:pos], start), pos


def _parse_block_comment(sql: str, pos: int):
    start = pos
    length = len(sql)
    pos += 2
    while pos < length - 1:
        if sql[pos] == "*" and sql[pos + 1] == "/":
            pos += 2
            break
        pos += 1
    return Token(TokenType.COMMENT, sql[start:pos], start), pos


def _parse_number(sql: str, pos: int):
    start = pos
    length = len(sql)
    while pos < length and (sql[pos].isdigit() or sql[pos] == "."):
        pos += 1
    return Token(TokenType.NUMBER, sql[start:pos], start), pos


def _parse_identifier_or_keyword(sql: str, pos: int):
    start = pos
    length = len(sql)
    while pos < length and (sql[pos].isalnum() or sql[pos] in ("_", "@")):
        pos += 1
    value = sql[start:pos]
    lowered = value.lower()
    token_type = (
        TokenType.KEYWORD
        if lowered in _SQL_KEYWORDS or lowered in _DANGEROUS_FUNCTIONS
        else TokenType.IDENTIFIER
    )
    return Token(token_type, value, start), pos


def _parse_operator(sql: str, pos: int):
    start = pos
    current = sql[pos]
    if pos + 1 < len(sql):
        two_char = sql[pos : pos + 2]
        if two_char in ("<=", ">=", "<>", "!=", "||"):
            return Token(TokenType.OPERATOR, two_char, start), pos + 2
    token_type = TokenType.PUNCTUATION if current in _PUNCTUATION_CHARS else TokenType.OPERATOR
    return Token(token_type, current, start), pos + 1


# ---------- comparison helpers ----------


_DANGEROUS_OPERATORS = {"=", "<", ">", "<>", "!=", "<=", ">=", "||"}
_DANGEROUS_PUNCTUATION = {";", "(", ")"}


def _danger_signature(tokens: list[Token]) -> "Counter[str]":
    """Multiset of injection-relevant tokens (keywords, comparison operators, comments, ';'/parens). Plain
    identifiers/strings/numbers are ignored - they are data, not SQL structure."""
    sig: Counter[str] = Counter()
    for t in tokens:
        if t.type == TokenType.COMMENT:
            sig["cmt"] += 1
        elif t.type == TokenType.KEYWORD and (t.value.lower() in _SQL_KEYWORDS or t.value.lower() in _DANGEROUS_FUNCTIONS):
            sig[f"kw:{t.value.lower()}"] += 1
        elif t.type == TokenType.OPERATOR and t.value in _DANGEROUS_OPERATORS:
            sig[f"op:{t.value}"] += 1
        elif t.type == TokenType.PUNCTUATION and t.value in _DANGEROUS_PUNCTUATION:
            sig[f"p:{t.value}"] += 1
    return sig


def _added_dangerous_tokens(original: list[Token], safe: list[Token]) -> bool:
    """True if the real query has injection-relevant tokens the neutralized query does NOT - i.e. the user input
    introduced SQL structure (keyword/operator/comment/';'), not just quoted data."""
    added = _danger_signature(original) - _danger_signature(safe)
    return bool(added)


def _has_real_comment(value: str) -> bool:
    """A SQL comment used as such: ``--`` or ``/*`` anywhere, or a ``#`` that begins a comment (at the start or
    right after whitespace/quote/';'). A ``#`` glued inside data (``order#9876``) is NOT a comment."""
    if "--" in value or "/*" in value:
        return True
    for i, ch in enumerate(value):
        if ch == "#" and (i == 0 or value[i - 1] in " \t'\";"):
            return True
    return False


def _without_whitespace(tokens: list[Token]) -> list[Token]:
    return [t for t in tokens if t.type != TokenType.WHITESPACE]


def _comments_of(tokens: list[Token]) -> list[Token]:
    return [t for t in tokens if t.type == TokenType.COMMENT]


def _have_comments_changed(tokens1: list[Token], tokens2: list[Token]) -> bool:
    comments1 = _comments_of(tokens1)
    comments2 = _comments_of(tokens2)
    if len(comments1) != len(comments2):
        return True
    for c1_token, c2_token in zip(comments1, comments2, strict=False):
        c1 = c1_token.value
        c2 = c2_token.value
        if len(c1) != len(c2):
            return True
        if c1.startswith("--") or c1.startswith("#"):
            prefix1 = "--" if c1.startswith("--") else "#"
            prefix2 = "--" if c2.startswith("--") else "#"
            if prefix1 != prefix2:
                return True
    return False


def _extract_injected_content(original: list[Token], safe: list[Token]) -> str:
    injected: list[str] = []
    for token in original:
        if token.type == TokenType.KEYWORD and token.value.lower() in _SQL_KEYWORDS:
            injected.append(token.value)
        elif token.type == TokenType.OPERATOR and token.value in (";", "--"):
            injected.append(token.value)
    return " ".join(injected) if injected else "Unknown SQL injection"

"""Command (shell) injection detector (differential analysis, Aikido Zen).

Inspects whether a user-supplied value, interpolated into a shell command
(``arguments[0]`` or the input itself), introduces shell syntax: metacharacters,
separated dangerous commands, or unsafe quote escapes. Never executes anything.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, has_sink
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_PATH_PREFIXES = (
    "/bin/", "/sbin/", "/usr/bin/", "/usr/sbin/", "/usr/local/bin/", "/usr/local/sbin/",
)
_SEPARATORS = frozenset((" ", "\t", "\n", ";", "&", "|", "(", ")", "<", ">"))
_DANGEROUS_CHARS = frozenset(
    (
        "#", "!", '"', "$", "&", "'", "(", ")", "*", ";", "<", "=", ">", "?", "[",
        "\\", "]", "^", "`", "{", "|", "}", " ", "\n", "\t", "~",
    )
)
_DANGEROUS_COMMANDS = (
    "sleep", "shutdown", "reboot", "poweroff", "halt", "ifconfig", "chmod", "chown",
    "ping", "ssh", "scp", "curl", "wget", "telnet", "kill", "killall", "rm", "mv",
    "cp", "touch", "echo", "cat", "head", "tail", "grep", "find", "awk", "sed",
    "sort", "uniq", "wc", "ls", "env", "ps", "who", "whoami", "id", "w", "df", "du",
    "pwd", "uname", "hostname", "netstat", "passwd", "arch", "printenv", "logname",
    "pstree", "hostnamectl", "set", "lsattr", "killall5", "dmesg", "history", "free",
    "uptime", "finger", "top", "shopt", ":",
)
_DANGEROUS_CHARS_INSIDE_DOUBLE_QUOTES = frozenset(("$", "`", "\\", "!"))


def _build_commands_regex() -> re.Pattern[str]:
    prefixes = "|".join(re.escape(p) for p in _PATH_PREFIXES)
    sorted_commands = sorted(_DANGEROUS_COMMANDS, key=len, reverse=True)
    commands = "|".join(re.escape(c) for c in sorted_commands)
    return re.compile(rf"([/.]*({prefixes})?({commands}))", re.IGNORECASE)


_COMMANDS_REGEX = _build_commands_regex()


class CommandInjectionDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.COMMAND_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if not user_input:
            return True
        if not has_sink(arguments):  # sink-only: needs the real command
            return True
        command = _resolve_command(user_input, arguments)
        if not command:
            return True
        if user_input == "~" and len(command) > 1 and "~" in command:
            return False
        if len(user_input) <= 1 or len(user_input) > len(command) or user_input not in command:
            return True
        return False

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        command = _resolve_command(user_input, arguments)
        if not _is_shell_injection(command, user_input):
            return DetectionResult.success()
        # Matches the backend CommandInjectionMetadata contract. FileName / Arguments /
        # WorkingDirectory / UseShellExecute are added by the command sink, which has the
        # subprocess.Popen call.
        result = DetectionResult.threat(
            ProtectionModuleType.COMMAND_INJECTION.value,
            f"Command injection detected: {_evidence(user_input)}",
            0.95,
        )
        result.with_metadata("UserInput", user_input)
        result.with_metadata("Command", command)
        return result


def _evidence(user_input: str) -> str:
    """Human-readable reason naming the offending input and the shell syntax it introduces."""
    snippet = user_input if len(user_input) <= 80 else user_input[:80] + "..."
    metachar = next((ch for ch in user_input if ch in _DANGEROUS_CHARS and not ch.isspace()), None)
    if metachar is not None:
        return f"user input '{snippet}' injects the shell metacharacter '{metachar}'"
    return f"user input '{snippet}' runs a separate shell command"


def _resolve_command(user_input: str, arguments: Sequence[str]) -> str:
    if arguments and len(arguments) > 0 and arguments[0]:
        return arguments[0]
    return user_input


def _is_shell_injection(command: str, user_input: str) -> bool:
    if not command or not user_input:
        return False
    if user_input == "~" and len(command) > 1 and "~" in command:
        return True
    if len(user_input) <= 1 or len(user_input) > len(command) or user_input not in command:
        return False
    if _is_safely_encapsulated(command, user_input):
        return False
    return _contains_shell_syntax(command, user_input)


def _contains_shell_syntax(command: str, user_input: str) -> bool:
    if not user_input or not user_input.strip():
        return False
    for ch in user_input:
        if ch in _DANGEROUS_CHARS:
            return True
    if command == user_input:
        match = _COMMANDS_REGEX.search(command)
        if match:
            return match.start() == 0 and (match.end() - match.start()) == len(command)
        return False
    for matcher in _COMMANDS_REGEX.finditer(command):
        if user_input != matcher.group():
            continue
        index = matcher.start()
        length = matcher.end() - matcher.start()
        char_before = command[index - 1] if index > 0 else "\0"
        char_after = command[index + length] if index + length < len(command) else "\0"
        if char_before in _SEPARATORS and char_after in _SEPARATORS:
            return True
        if char_before in _SEPARATORS and char_after == "\0":
            return True
        if char_before == "\0" and char_after in _SEPARATORS:
            return True
    return False


def _is_safely_encapsulated(command: str, user_input: str) -> bool:
    segments = command.split(user_input)
    for i in range(len(segments) - 1):
        current_segment = segments[i]
        next_segment = segments[i + 1]
        char_before = current_segment[-1] if current_segment else "\0"
        char_after = next_segment[0] if next_segment else "\0"
        is_quoted = char_before in ('"', "'")
        if not is_quoted:
            return False
        if char_before != char_after:
            return False
        if char_before in user_input:
            return False
        if char_before == '"' and any(c in _DANGEROUS_CHARS_INSIDE_DOUBLE_QUOTES for c in user_input):
            return False
    return True



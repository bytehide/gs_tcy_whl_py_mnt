"""Cloud detector base class.

Detectors are pure, stateless functions over a single user-supplied value plus
optional sink context in ``arguments`` (``arguments[0]`` is the full SQL query,
target URL, path or command when known). They perform no I/O and hold no request
state, so they are deterministic and unit-testable without any framework.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING

from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

if TYPE_CHECKING:
    from bytehide_monitor.cloud.context.context_object import ContextObject


class ResponseView:
    """Minimal, framework-agnostic view of the OUTGOING HTTP response.

    The response-level scan (mirror of the request-level scan) only needs three things to make a
    decision: the status code, the response headers, and the response body as text. Source adapters
    already capture exactly these to run the reflected-XSS analysis (see ``cloud/response/response_xss.py``
    and the ``sources/*`` adapters), so this is a thin wrapper over what they pass - it does NOT change
    the existing XSS path. ``get_header`` is case-insensitive like :class:`ContextObject.get_header`.
    """

    __slots__ = ("status_code", "headers", "body")

    def __init__(
        self,
        status_code: int = 200,
        headers: Mapping[str, str] | None = None,
        body: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.headers = headers
        self.body = body

    def get_header(self, name: str) -> str | None:
        if not self.headers or name is None:
            return None
        lowered = name.lower()
        for key, value in self.headers.items():
            if key is not None and key.lower() == lowered:
                return value
        return None


def is_null_or_whitespace(value: str | None) -> bool:
    return not value or not value.strip()


def has_sink(arguments: Sequence[str]) -> bool:
    """True when an explicit sink value (``arguments[0]``) is present.

    SQL, command, path-traversal, LDAP and NoSQL detection are only meaningful against
    a real operation (the query, command, path or filter the input is embedded in).
    Without a sink they return early, so they run at in-app sinks but not in the blanket
    inbound scan - matching the .NET interceptor model and avoiding false positives from
    benign inputs that legitimately contain shell/SQL/LDAP metacharacters (spaces, ``;``,
    ``,`` ...). XSS, XXE, LLM prompt injection and SSRF remain input-pattern detectors
    that run inbound.
    """
    return bool(arguments) and len(arguments) > 0 and bool(arguments[0])


class CloudDetector:
    """Base class for the nine cloud detectors."""

    def type(self) -> ProtectionModuleType:  # pragma: no cover - abstract
        raise NotImplementedError

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:  # pragma: no cover
        raise NotImplementedError

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:  # pragma: no cover
        raise NotImplementedError

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        """Request-level detection over the WHOLE request context, run once per request.

        Returns ``None`` by default, so existing per-input detectors are unaffected. Detectors
        that need fields excluded from the per-input scan (headers, cookies, method, route as a
        unit) override this; the scanner calls it once per request with the full
        :class:`ContextObject` AFTER the per-input inbound scan, and reports a returned
        ``DetectionResult`` with ``threat_detected`` through the same incident path. Must never
        raise - request-level detection is fail-open (any error is swallowed and treated as "no
        threat").
        """
        return None

    def run_response(
        self, context: ContextObject, response: ResponseView
    ) -> DetectionResult | None:
        """Response-level detection over the OUTGOING response, run once per request.

        Mirror of :meth:`run_request` for the response side. Returns ``None`` by default, so existing
        detectors are unaffected. Detectors that inspect what the application is about to send back
        (e.g. sensitive-data leakage in the body) override this; the scanner calls it once per request
        with the full :class:`ContextObject` and a :class:`ResponseView` (status, headers, body) at the
        point where the source adapter already has the response in hand (next to the reflected-XSS scan),
        and reports a returned ``DetectionResult`` with ``threat_detected`` through the same incident
        path. Must never raise - response-level detection is fail-open.
        """
        return None

    def describe_inbound(self, source: str) -> str | None:
        """Location-aware incident description for an inbound detection, or ``None``.

        ``source`` is the flattened input key the value came from (``query.<name>``,
        ``body.<path>`` or ``path.<name>``). Returning ``None`` keeps the detector's own
        description; detectors whose .NET counterpart reports the input location (e.g.
        XSS -> "XSS detected in query string") override this. Not used at in-app sinks.
        """
        return None

    def inbound_metadata(self, context: ContextObject) -> dict[str, str] | None:
        """Extra metadata for an inbound detection, drawn from the request context, or ``None``.

        Called by the scanner only on the inbound path (never at sinks). Detectors whose
        backend contract carries request context (e.g. XSS -> RequestMethod / RequestPath)
        override this; the returned keys are merged into the detection metadata.
        """
        return None

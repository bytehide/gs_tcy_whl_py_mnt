"""Cross-Site Scripting (XSS) detector.

Pure, stateless port of the .NET ``XssDetector``: dangerous HTML tags, event
handlers, script-bearing protocols (javascript:, data:text/html, vbscript:) and
basic encoded-XSS attempts, checked in the same order as the original.
"""

from __future__ import annotations

import html
import re
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DANGEROUS_HTML_TAGS = (
    "<script", "<iframe", "<object", "<embed", "<applet", "<meta", "<img", "<svg",
    "<video", "<audio", "<link", "<style", "<base", "<form", "<input", "<button", "<textarea",
)
_DANGEROUS_EVENT_HANDLERS = (
    "onerror=", "onload=", "onclick=", "onmouseover=", "onfocus=", "onblur=", "onchange=",
    "onsubmit=", "onkeydown=", "onkeyup=", "onkeypress=", "onmousedown=", "onmouseup=",
    "onmousemove=", "ondblclick=", "oncontextmenu=", "ondrag=", "ondrop=", "oninput=",
    "onpaste=", "onscroll=", "onwheel=", "ontouchstart=", "ontouchend=", "ontoggle=",
    "onanimationend=", "onanimationstart=", "ontransitionend=", "onpointerdown=",
    "onpointerup=", "onpointermove=", "onbeforeprint=", "onafterprint=",
)
# Any inline event handler INSIDE a tag (``<tag ... onXXXX=``). Generic so novel handlers (onpointerover,
# onfocusin, SMIL onbegin, ...) are caught without enumerating them; the ``<...`` tag context keeps false
# positives off benign inputs that merely contain an ``on...=`` token (e.g. ``online=yes``).
_EVENT_HANDLER_IN_TAG = re.compile(r"<[^>]*\son[a-z]+\s*=", re.IGNORECASE)
# CSS expression() (legacy IE script execution) and namespaced <ns:script> (e.g. <d3:script xmlns=...xhtml>).
_CSS_EXPRESSION = re.compile(r"expression\s*\(", re.IGNORECASE)
_NS_SCRIPT = re.compile(r"<\s*\w+:script\b", re.IGNORECASE)
_JAVASCRIPT_PROTOCOL = re.compile(r"javascript\s*:", re.IGNORECASE)
_DATA_PROTOCOL = re.compile(r"data\s*:\s*text/html", re.IGNORECASE)
_VBSCRIPT_PROTOCOL = re.compile(r"vbscript\s*:", re.IGNORECASE)

_NAMED_ENTITIES = {"lt": ord("<"), "gt": ord(">"), "amp": ord("&"), "quot": ord('"'), "apos": ord("'")}


class CrossSiteScriptingDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.CROSS_SITE_SCRIPTING

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return user_input is None or len(user_input) < 2

    def describe_inbound(self, source: str) -> str | None:
        # Match the .NET HTTP detector (SecurityDetectors.DetectXss): the incident
        # description names the input location, not the matched fragment.
        return _location_description(source)

    def inbound_metadata(self, context: Any) -> dict[str, str] | None:
        # Complete XssMetadata with request context. RequestMethod / RequestPath come from
        # the inbound request; ResponseContentType is intentionally NOT set here - XSS is
        # caught inbound, before any response exists, so the content type is unknown (it
        # would require a response-side sink, which is out of scope for inbound detection).
        meta: dict[str, str] = {}
        if context.method:
            meta["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            meta["RequestPath"] = str(path)
        return meta or None

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if user_input is None or len(user_input) < 2:
            return DetectionResult.success()
        lower = user_input.lower()

        for tag in _DANGEROUS_HTML_TAGS:
            if tag in lower:
                return _threat(user_input, tag, tag)
        for handler in _DANGEROUS_EVENT_HANDLERS:
            if handler in lower:
                return _threat(user_input, handler, handler)
        if _EVENT_HANDLER_IN_TAG.search(user_input):
            return _threat(user_input, "inline event handler", "on-handler")
        if _JAVASCRIPT_PROTOCOL.search(lower):
            return _threat(user_input, "javascript: protocol", "javascript:")
        if _DATA_PROTOCOL.search(lower):
            return _threat(user_input, "data:text/html protocol", "data:text/html")
        if _VBSCRIPT_PROTOCOL.search(lower):
            return _threat(user_input, "vbscript: protocol", "vbscript:")
        if _CSS_EXPRESSION.search(lower):
            return _threat(user_input, "CSS expression()", "expression(")
        if _NS_SCRIPT.search(user_input):
            return _threat(user_input, "namespaced script element", "<ns:script>")
        # HTML-entity-encoded script URIs decode in attribute context (e.g. <a href="&#106;avascript:...">). Only
        # flag when the DECODED form yields a script protocol - not a bare &lt;script&gt; (that renders inert).
        decoded = html.unescape(user_input)
        if decoded != user_input and (_JAVASCRIPT_PROTOCOL.search(decoded.lower()) or _VBSCRIPT_PROTOCOL.search(decoded.lower())):
            return _threat(user_input, "entity-encoded script URI", "encoded")
        if _contains_encoded_xss(user_input):
            return _threat(user_input, "encoded XSS attempt", "encoded")
        return DetectionResult.success()


def _threat(payload: str, injected_content: str, matched: str) -> DetectionResult:
    # Inbound, the scanner replaces this description with the .NET location string
    # ("XSS detected in query string") via describe_inbound(); the matched pattern stays
    # in metadata. The value-level description (used by the standalone validator, which
    # has no input location) is the injected pattern/label.
    # Metadata matches the backend XssMetadata contract. RequestPath / RequestMethod /
    # ResponseContentType are request/response context the middleware adds; the detector
    # supplies the injected content and the matched pattern list.
    return DetectionResult.threat(
        ProtectionModuleType.CROSS_SITE_SCRIPTING.value,
        injected_content,
        0.9,
        {"InjectedContent": injected_content, "DetectedPatterns": [matched]},
    )


def _location_description(source: str | None) -> str | None:
    if not source:
        return None
    if source == "query" or source.startswith("query."):
        location = "query string"
    elif source == "body":
        location = "request body"
    elif source.startswith("body."):
        location = f"form field '{source[len('body.'):]}'"
    elif source == "path" or source.startswith("path."):
        location = "URL path"
    else:
        location = source
    return f"XSS detected in {location}"


def _contains_encoded_xss(value: str) -> bool:
    if "&#" in value and ("script" in value or "60" in value or "62" in value):
        decoded = _html_decode(value).lower()
        if "<script" in decoded or "onerror" in decoded or "javascript:" in decoded:
            return True
    if "%" in value and ("3C" in value or "3c" in value or "3E" in value or "3e" in value):
        decoded = _url_decode(value).lower()
        if "<script" in decoded or "onerror" in decoded or "javascript:" in decoded:
            return True
    return False


def _html_decode(value: str) -> str:
    result: list[str] = []
    i = 0
    length = len(value)
    while i < length:
        current = value[i]
        if current == "&":
            semicolon = value.find(";", i + 1)
            if semicolon > i:
                entity = value[i + 1 : semicolon]
                code_point = _decode_entity(entity)
                if code_point >= 0:
                    result.append(chr(code_point))
                    i = semicolon + 1
                    continue
        result.append(current)
        i += 1
    return "".join(result)


def _decode_entity(entity: str) -> int:
    if not entity:
        return -1
    if entity[0] == "#":
        try:
            if len(entity) > 1 and entity[1] in ("x", "X"):
                return int(entity[2:], 16)
            return int(entity[1:])
        except ValueError:
            return -1
    return _NAMED_ENTITIES.get(entity, -1)


def _url_decode(value: str) -> str:
    result: list[str] = []
    i = 0
    length = len(value)
    while i < length:
        current = value[i]
        if current == "%" and i + 2 < length:
            high = _hex_digit(value[i + 1])
            low = _hex_digit(value[i + 2])
            if high >= 0 and low >= 0:
                result.append(chr((high << 4) + low))
                i += 3
                continue
        result.append(" " if current == "+" else current)
        i += 1
    return "".join(result)


def _hex_digit(ch: str) -> int:
    try:
        return int(ch, 16)
    except ValueError:
        return -1

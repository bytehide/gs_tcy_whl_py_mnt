"""LDAP injection detector.

Detects dangerous LDAP filter metacharacters and filter-structure manipulation in
user-supplied values (port of .NET ``LdapInjectionDetector``; OWASP LDAP Injection
Prevention Cheat Sheet, RFC 4515). ``arguments[0]`` carries the full LDAP filter;
when absent the user input itself is used as the filter.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, has_sink, is_null_or_whitespace
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DANGEROUS_LDAP_CHARS = frozenset(
    ("*", "(", ")", "\\", "|", "&", "!", "=", "<", ">", "/", ",", ";", '"', "'")
)
_DANGEROUS_OPERATORS = ("(&", "(|", "(!", "=*", ">=", "<=", "~=")
_FILTER_STRUCTURE_REGEX = re.compile(r"\([&|!].*?\)", re.IGNORECASE)


class LdapInjectionDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.LDAP_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if is_null_or_whitespace(user_input):
            return True
        if len(user_input) <= 1:
            return True
        if not has_sink(arguments):  # sink-only: needs the real LDAP filter
            return True
        filter_value = _resolve_filter(user_input, arguments)
        if is_null_or_whitespace(filter_value):
            return True
        return user_input not in filter_value

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        filter_value = _resolve_filter(user_input, arguments)

        dangerous_char = _find_dangerous_character(user_input)
        if dangerous_char is not None:
            return _threat(user_input, f"Dangerous LDAP character: {dangerous_char}", 0.85, filter_value)

        dangerous_op = _find_dangerous_operator(user_input)
        if dangerous_op is not None:
            return _threat(user_input, f"LDAP filter operator: {dangerous_op}", 0.90, filter_value)

        if _FILTER_STRUCTURE_REGEX.search(user_input):
            return _threat(user_input, "LDAP filter structure manipulation", 0.95, filter_value)

        if _is_wildcard_injection(filter_value, user_input):
            return _threat(user_input, "LDAP wildcard injection", 0.80, filter_value)

        return DetectionResult.success()


def _find_dangerous_character(user_input: str) -> str | None:
    for ch in user_input:
        if ch in _DANGEROUS_LDAP_CHARS:
            return ch
    return None


def _find_dangerous_operator(user_input: str) -> str | None:
    for op in _DANGEROUS_OPERATORS:
        if op in user_input:
            return op
    return None


def _is_wildcard_injection(filter_value: str, user_input: str) -> bool:
    if user_input.strip() == "*":
        return True
    if "*" in user_input:
        return ("=" + user_input) in filter_value
    return False


def _resolve_filter(user_input: str, arguments: Sequence[str]) -> str:
    if arguments and len(arguments) > 0 and not is_null_or_whitespace(arguments[0]):
        return arguments[0]
    return user_input


def _threat(
    payload: str, injected_content: str, confidence: float, filter_value: str
) -> DetectionResult:
    metadata = {
        "UserInput": payload,
        "InjectedContent": injected_content,
        "LdapFilter": filter_value or "",
        "Operation": "ldap.search",
    }
    return DetectionResult.threat(
        ProtectionModuleType.LDAP_INJECTION.value,
        f"LDAP injection detected: {injected_content}",
        confidence,
        metadata,
    )

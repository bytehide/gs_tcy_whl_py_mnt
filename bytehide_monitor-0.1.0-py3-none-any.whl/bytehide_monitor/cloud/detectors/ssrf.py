"""Server-Side Request Forgery (SSRF) detector.

Pure, stateless port of the .NET ``SsrfDetector``. Inspects the target URL/hostname
(``arguments[0]`` or the user input) and flags requests aimed at dangerous internal
resources: localhost variants, cloud metadata IMDS endpoints, well-known metadata
hostnames, and private/link-local IP ranges. No DNS resolution or network I/O.
"""

from __future__ import annotations

import fnmatch
import ipaddress
import os
import re
import socket
import urllib.parse
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core import taint
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_CONFIDENCE = 0.9
# Confidence for a strict-mode block (user-controlled outbound to a non-allowlisted external host).
# Lower than a dangerous-target hit: this is a policy decision, not a known-malicious target.
_STRICT_CONFIDENCE = 0.75

_IPV4_IN_HOST = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")

_DANGEROUS_HOSTS = frozenset(
    (
        "localhost",
        "127.0.0.1",
        "::1",
        "::",  # IPv6 unspecified address (equivalent to 0.0.0.0 - routes to local interfaces)
        "0.0.0.0",
        "169.254.169.254",  # AWS/Azure/GCP metadata IP
        "metadata.google.internal",
        "metadata.google",
        "metadata",
        "instance-data",
        "169.254.170.2",  # AWS ECS task metadata
    )
)

_PRIVATE_NETWORKS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
)

# Hosts that resolve to a cloud instance-metadata service (IMDS) - the highest-value SSRF target.
_METADATA_HOSTS = frozenset(
    ("169.254.169.254", "169.254.170.2", "metadata.google.internal", "metadata.google", "metadata", "instance-data")
)
_LINK_LOCAL = (ipaddress.ip_network("169.254.0.0/16"), ipaddress.ip_network("fe80::/10"))

# URL schemes that are SSRF/LFI vectors regardless of host (file:// has no host at all, so the host-based
# checks below never see it). http/https/ws/wss are the legitimate web schemes and are not flagged here.
_DANGEROUS_SCHEMES = frozenset(("file", "gopher", "dict", "php", "expect", "jar", "netdoc", "tftp", "ldap"))


class SsrfDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.SERVER_SIDE_REQUEST_FORGERY

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        target = _resolve_target(user_input, arguments)
        return target is None or not target.strip()

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        raw_target = _resolve_target(user_input, arguments)
        if raw_target is None or not raw_target.strip():
            return DetectionResult.success()

        # Taint signal: only the OUTBOUND TARGET matters. When the URL reaching the sink is a TaintedStr
        # it derives from the request -> evaluate (true user control). We must NOT also test user_input:
        # the per-input value the scanner iterates is ALWAYS a request value (read via the tainted
        # framework accessor), so it is always tainted and would make every outbound look user-controlled
        # - that is exactly what flagged the hard-coded crapi-identity call. For the inbound scan there
        # are no sink arguments, so raw_target IS the user input and this still covers it. When taint is
        # absent (not installed, or lost through an f-string) we fall back to host-level correlation.
        tainted = taint.is_tainted(raw_target)

        # Normalize WAF-bypass tricks: percent-decode (so %2f, %23, %00 reveal their meaning) and truncate at a
        # null byte / CR / LF - many HTTP stacks stop connecting at the first null, so the REAL target is the part
        # before it (classic ``http://127.0.0.1%00@evil.com`` bypass). Host analysis runs on this normalized form;
        # correlation back to user input uses the RAW target (the percent-encoded payload as the user sent it).
        target = _normalize_target(raw_target)

        # Dangerous scheme (file://, gopher://, dict://, ...): a vector on its own, often with no host to inspect.
        scheme = _scheme_of(target)
        if scheme in _DANGEROUS_SCHEMES and user_input and user_input.strip() and user_input.lower() in raw_target.lower():
            result = DetectionResult.threat(
                self.type().value,
                f"Server-side request forgery detected: dangerous URL scheme '{scheme}'",
                _CONFIDENCE,
            )
            result.with_metadata("Uri", target)
            result.with_metadata("Hostname", _extract_host(target) or "")
            result.with_metadata("Method", "")
            result.with_metadata("UserInput", user_input)
            return result

        hostname = _extract_host(target)
        if not hostname:
            return DetectionResult.success()

        # Normalize obfuscated host forms (decimal/hex/octal/short IPv4: 2130706433, 0x7f000001, 0177.0.0.1,
        # 127.1) to canonical dotted-quad so the dangerous/private checks see through the disguise.
        canon = _canonical_ip(hostname)

        evidence: str | None = None
        if _contains_ignore_case(_DANGEROUS_HOSTS, hostname) or _contains_ignore_case(_DANGEROUS_HOSTS, canon):
            evidence = hostname
        if evidence is None and (_is_private_ip(hostname) or _is_private_ip(canon)):
            evidence = canon if canon != hostname else hostname
        # Embedded-IP hostnames: wildcard-DNS rebinding services (nip.io/sslip.io/xip.io) and dotted hostnames
        # that carry an internal IP as a label (``127.0.0.1.nip.io`` -> resolves to 127.0.0.1).
        if evidence is None:
            embedded = _embedded_dangerous_ip(hostname)
            if embedded is not None:
                evidence = embedded
        if evidence is None:
            # Host is not a dangerous internal/metadata target. By default that is allowed (a
            # legitimate external fetch). In STRICT mode the policy is "block any server-side fetch
            # whose URL is user-controlled, unless the host is on the allowlist" - this catches the
            # crAPI-style SSRF where the app fetches an arbitrary attacker-supplied URL, even when
            # the target itself (e.g. www.google.com) is benign. Opt-in via config/env to avoid
            # breaking legitimate outbound calls in apps that don't want it.
            return self._strict_external(user_input, raw_target, hostname, scheme, tainted)

        # The dangerous host must trace back to the user: tainted (authoritative) OR host-correlated.
        if not (tainted or _correlates(user_input, hostname)):
            return DetectionResult.success()

        result = DetectionResult.threat(
            self.type().value,
            f"Server-side request forgery detected: request targets {_classify(hostname)} '{evidence}'",
            _CONFIDENCE,
        )
        # Matches the backend SsrfMetadata contract. Method is filled by the HTTP sink
        # (it knows the outbound request method); empty for value-level validation.
        result.with_metadata("Uri", target)
        result.with_metadata("Hostname", hostname)
        result.with_metadata("Method", "")
        result.with_metadata("UserInput", user_input)
        return result

    def _strict_external(
        self, user_input: str, raw_target: str, hostname: str, scheme: str, tainted: bool = False
    ) -> DetectionResult:
        """Strict-mode SSRF: block a user-controlled outbound fetch to a non-allowlisted external host.

        Only fires when (a) strict mode is enabled, (b) the host is not on the allowlist, and (c) the
        target traces back to the request's user input (so it is genuinely attacker-controllable, not a
        hard-coded URL the app calls itself). Default off; disabled mode returns ``success()``.
        """
        config = _ssrf_config()
        if not _strict_enabled(config):
            return DetectionResult.success()
        if not hostname:
            return DetectionResult.success()
        # Strict mode only applies to an ACTUAL outbound web URL: an http(s)/ws(s) scheme is REQUIRED.
        # A schemeless value is not a server-side fetch and must never be strict-blocked - e.g. a bare
        # "30" from ?limit=30, an id, an email, or any plain word. (Schemeless dangerous targets like a
        # raw private IP / "localhost" / cloud-metadata are still caught earlier by the dangerous-host
        # path, which does not require a scheme; strict only adds the "benign external URL, but user-
        # controlled" case, and a real outbound fetch there always carries an http(s)/ws(s) scheme.)
        if scheme not in ("http", "https", "ws", "wss"):
            return DetectionResult.success()
        if _host_allowlisted(hostname, config):
            return DetectionResult.success()
        # User control required: tainted (authoritative - the URL derives from the request) OR a
        # host-level correlation (fallback when taint is unavailable/lost). A "0" from ?offset=0 sitting
        # inside the ":8080" of a hard-coded internal call is neither -> not flagged.
        if not (tainted or _correlates(user_input, hostname)):
            return DetectionResult.success()

        result = DetectionResult.threat(
            self.type().value,
            f"Server-side request forgery detected: user-controlled outbound request to "
            f"non-allowlisted host '{hostname}' (strict mode)",
            _STRICT_CONFIDENCE,
        )
        result.with_metadata("Uri", raw_target)
        result.with_metadata("Hostname", hostname)
        result.with_metadata("Method", "")
        result.with_metadata("UserInput", user_input)
        result.with_metadata("Mode", "strict")
        return result


def _correlates(user_input: str | None, hostname: str) -> bool:
    """Whether the user genuinely supplied the request's DESTINATION host (real attacker control), not a
    coincidental substring of the URL. SSRF is controlled by supplying the URL/host, so correlate at the
    HOST level: the user's value contains the host (they sent a URL/host), or their value IS the host.

    Correlating against the whole URL string caused false positives - e.g. a ``"0"`` from ``?offset=0`` is
    a substring of the ``":8080"`` port of a HARD-CODED internal call (``http://crapi-identity:8080/...``),
    which is not user control at all. Short tokens (1-3 chars) never count: too coincidental.
    """
    if not user_input or not user_input.strip() or not hostname:
        return False
    ui = user_input.strip().lower()
    host = hostname.lower()
    if host in ui:
        return True  # the user supplied a URL/value that carries the destination host
    return len(ui) >= 4 and ui in host  # the user supplied (at least) the host itself


def _ssrf_config() -> dict[str, Any]:
    """SSRF module config bound to the current request (set by the scanner), or ``{}``."""
    try:
        from bytehide_monitor.cloud.context import context as context_holder

        ctx = context_holder.get()
        cfg = getattr(ctx, "_request_detector_config", None)
        return cfg if isinstance(cfg, dict) else {}
    except Exception:  # noqa: BLE001 - config read is best-effort / fail-open
        return {}


def _strict_enabled(config: dict[str, Any]) -> bool:
    """Strict mode on when the module config sets it, or via the BYTEHIDE_SSRF_STRICT env fallback."""
    for key in ("block_external_unless_allowlisted", "strict", "strict_external"):
        raw = config.get(key)
        if isinstance(raw, bool):
            if raw:
                return True
        elif isinstance(raw, str) and raw.strip().lower() in {"1", "true", "yes", "on"}:
            return True
    env = os.environ.get("BYTEHIDE_SSRF_STRICT", "")
    return env.strip().lower() in {"1", "true", "yes", "on"}


def _allowlist(config: dict[str, Any]) -> list[str]:
    """Allowed host patterns from config (allowlist/allowed_hosts) plus the BYTEHIDE_SSRF_ALLOWLIST env."""
    patterns: list[str] = []
    for key in ("allowlist", "allowed_hosts", "allow_hosts"):
        patterns.extend(_str_list(config.get(key)) or [])
    env = os.environ.get("BYTEHIDE_SSRF_ALLOWLIST", "")
    if env.strip():
        patterns.extend(part.strip() for part in env.split(",") if part.strip())
    return patterns


def _host_allowlisted(hostname: str, config: dict[str, Any]) -> bool:
    lowered = hostname.lower()
    for pattern in _allowlist(config):
        pat = pattern.lower().strip()
        if not pat:
            continue
        if "*" in pat or "?" in pat or "[" in pat:
            if fnmatch.fnmatch(lowered, pat):
                return True
        elif lowered == pat or lowered.endswith("." + pat):
            return True
    return False


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


def _classify(hostname: str) -> str:
    """Categorize the internal target so the incident description explains why it is dangerous."""
    if hostname in _METADATA_HOSTS:
        return "cloud metadata endpoint"
    if hostname in ("localhost", "0.0.0.0"):  # noqa: S104 - matching, not binding
        return "loopback address"
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        return "internal resource"
    mapped = getattr(address, "ipv4_mapped", None)
    if mapped is not None:
        address = mapped
    if address.is_loopback:
        return "loopback address"
    if any(address in network for network in _LINK_LOCAL):
        return "link-local address"
    if any(address in network for network in _PRIVATE_NETWORKS):
        return "private network address"
    return "internal resource"


def _canonical_ip(host: str) -> str:
    """Resolve an obfuscated IPv4 host to canonical dotted-quad (decimal/hex/octal/short forms). Returns the
    original host unchanged when it is not a numeric IPv4 representation (e.g. a normal domain name)."""
    h = host.strip().lower()
    if not h:
        return host
    try:
        return str(ipaddress.ip_address(h))  # already a valid dotted IP (v4/v6)
    except ValueError:
        pass
    # Pure integer / 0x.. / 0o.. encodings of the WHOLE address (e.g. 2130706433, 0x7f000001). Only when
    # the value encodes a REAL address (>= 1.0.0.0): smaller integers fall in 0.0.0.0/8 ("this network"),
    # which is NOT a reachable SSRF target - treating a benign ?limit=30 / ?offset=0 / numeric id as
    # 0.0.0.x was a false positive. The decimal-IP bypass we DO want (127.0.0.1 = 2130706433, 10.0.0.1 =
    # 167772161, ...) is always well above this threshold, so detection is unchanged.
    try:
        if h.startswith(("0x", "0o")):
            n = int(h, 0)
        elif h.isdigit():
            n = int(h)
        else:
            n = None
        if n is not None and 0x01000000 <= n <= 0xFFFFFFFF:
            return str(ipaddress.ip_address(n))
    except ValueError:
        pass
    # Short / octal / hex per-octet forms (127.1, 0177.0.0.1, 0x7f.0.0.1) - inet_aton understands them.
    # Require a dot so a BARE integer never reaches inet_aton (which would turn "0"/"30" into 0.0.0.x).
    if "." in h:
        try:
            return socket.inet_ntoa(socket.inet_aton(h))
        except OSError:
            return host
    return host


def _normalize_target(target: str) -> str:
    """Reveal WAF-bypass encodings: percent-decode once, then truncate at the first null/CR/LF (the real
    connection target precedes a ``%00``/null-byte truncation in most HTTP stacks)."""
    t = target.strip()
    try:
        decoded = urllib.parse.unquote(t)
    except Exception:  # noqa: BLE001
        decoded = t
    for terminator in ("\x00", "\r", "\n"):
        idx = decoded.find(terminator)
        if idx >= 0:
            decoded = decoded[:idx]
    return decoded or t


def _embedded_dangerous_ip(host: str) -> str | None:
    """Find a loopback/private IPv4 embedded as a label in a hostname (wildcard DNS like ``127.0.0.1.nip.io``)."""
    for candidate in _IPV4_IN_HOST.findall(host):
        if _contains_ignore_case(_DANGEROUS_HOSTS, candidate) or _is_private_ip(candidate):
            return candidate
    return None


def _scheme_of(target: str) -> str:
    # The scheme is the token before the FIRST colon (handles ``file:///``, ``jar:http://...``, ``gopher://``).
    colon = target.find(":")
    return target[:colon].strip().lower() if 0 < colon < 12 else ""


def _resolve_target(user_input: str, arguments: Sequence[str]) -> str | None:
    if arguments and len(arguments) > 0 and arguments[0] and arguments[0].strip():
        return arguments[0]
    return user_input


def _extract_host(target: str) -> str | None:
    value = target.strip()
    scheme_idx = value.find("://")
    if scheme_idx >= 0:
        value = value[scheme_idx + 3 :]
    cut = _index_of_any(value, "/", "?", "#")
    if cut >= 0:
        value = value[:cut]
    at = value.rfind("@")
    if at >= 0:
        value = value[at + 1 :]
    if not value:
        return None
    if value[0] == "[":
        close = value.find("]")
        if close > 0:
            return value[1:close].lower()
        return value[1:].lower()
    first_colon = value.find(":")
    if first_colon >= 0 and value.find(":", first_colon + 1) < 0:
        value = value[:first_colon]
    # Trailing dots are ignored by DNS (``127.0.0.1..`` == ``127.0.0.1``) - strip them so canonicalization works.
    return value.strip(".").lower()


def _index_of_any(value: str, *chars: str) -> int:
    for i, ch in enumerate(value):
        if ch in chars:
            return i
    return -1


def _contains_ignore_case(host_set: frozenset, value: str) -> bool:
    lowered = value.lower()
    return any(entry.lower() == lowered for entry in host_set)


def _is_private_ip(hostname: str) -> bool:
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        return False
    # An IPv4-mapped IPv6 address (e.g. ::ffff:127.0.0.1) carries the real IPv4 target.
    mapped = getattr(address, "ipv4_mapped", None)
    if mapped is not None:
        address = mapped
    # is_loopback covers the whole 127.0.0.0/8 range and ::1, not just 127.0.0.1.
    if address.is_loopback:
        return True
    return any(address in network for network in _PRIVATE_NETWORKS)

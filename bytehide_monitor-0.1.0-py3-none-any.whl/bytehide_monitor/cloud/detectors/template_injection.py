"""Server-Side Template Injection (SSTI) detector.

Flags user input that introduces template-engine syntax into a rendered template (Jinja2/Flask ``{{...}}`` /
``{%...%}``, Mako/ERB ``<%...%>``, ``${...}``, ``#{...}``) or classic SSTI sandbox-escape gadgets
(``__class__``/``__mro__``/``__globals__``/``__subclasses__``/``config``/``self.``). Correlated against the
rendered template (``arguments[0]``) like the SQL/command detectors, so it fires at the template-render sink, not
on benign text that merely contains a brace.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, has_sink, is_null_or_whitespace
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_TEMPLATE_SYNTAX = re.compile(r"\{\{.*?\}\}|\{%.*?%\}|\$\{.*?\}|#\{.*?\}|<%.*?%>", re.DOTALL)
# Only unambiguous SSTI escape gadgets (dunder chains). Bare words like ``config``/``self``/``cycler`` are common
# in normal text, so they are NOT flagged on their own - in a real attack they appear inside ``{{...}}`` and are
# caught by the template-syntax pattern above.
_GADGETS = re.compile(
    r"__class__|__mro__|__base__|__bases__|__subclasses__|__globals__|__builtins__|__import__|__reduce__|__init__",
    re.IGNORECASE,
)


class TemplateInjectionDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.TEMPLATE_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if is_null_or_whitespace(user_input) or len(user_input) <= 1:
            return True
        if not has_sink(arguments):  # sink-only: needs the real template the input is rendered into
            return True
        template = arguments[0]
        if is_null_or_whitespace(template) or user_input not in template:
            return True
        return False

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        match = _TEMPLATE_SYNTAX.search(user_input)
        evidence = None
        if match:
            evidence = match.group(0)
        elif _GADGETS.search(user_input):
            evidence = _GADGETS.search(user_input).group(0)
        if evidence is None:
            return DetectionResult.success()
        snippet = evidence if len(evidence) <= 80 else evidence[:80] + "..."
        result = DetectionResult.threat(
            self.type().value,
            f"Server-side template injection detected: '{snippet}'",
            0.9,
        )
        result.with_metadata("UserInput", user_input)
        result.with_metadata("InjectedContent", evidence)
        result.with_metadata("Operation", "template.render")
        return result

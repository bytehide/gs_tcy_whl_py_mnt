"""NoSQL injection detector (MongoDB and Cosmos DB).

Pure, stateless port of the .NET ``NoSqlInjectionDetector``. Inspects a single user
value against the query sink (``arguments[0]`` or the input itself). Detection order
mirrors .NET: MongoDB operator injection, JavaScript code injection in
$where/$function, JSON structure manipulation, $in/$nin array injection, then Cosmos
DB SQL-like patterns.
"""

from __future__ import annotations

import re
import urllib.parse
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, has_sink
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DANGEROUS_MONGO_OPERATORS = (
    "$where", "$regex", "$expr", "$function", "$ne", "$gt", "$lt", "$gte", "$lte",
    "$in", "$nin", "$and", "$or", "$not", "$nor", "$exists", "$type", "$jsonSchema",
    "$mod", "$text", "$all", "$elemMatch", "$size",
)
_JAVASCRIPT_KEYWORDS = (
    "function", "return", "this.", "obj.", "sleep(", "while(", "for(", "eval(",
    "Function(", "constructor",
)
# Any ``$operator:`` in user input is a MongoDB operator/aggregation-stage injection: legitimate document fields
# can never start with ``$`` (reserved), so a user value that supplies one is manipulating the query. This generic
# form covers every query operator AND aggregation stage ($eq, $comment, $natural, $bitsAllSet, $nearSphere,
# $match, $project, $group, $lookup, $addFields, $facet, ...) without enumerating them. The group is the operator.
_MONGO_OPERATOR_PATTERN = re.compile(r"""['"]?(\$[a-zA-Z][a-zA-Z0-9]*)['"]?\s*:""")
# Query-string / form array form of the same injection: ``param[$ne]=null``, ``filter[$gt]=`` (no JSON colon).
_MONGO_BRACKET_PATTERN = re.compile(r"""\[\s*['"]?(\$[a-zA-Z][a-zA-Z0-9]*)['"]?\s*\]""")
# JavaScript boolean tautology injected into a string-built query ($where / concatenated filter): `'' || true`.
_JS_BOOLEAN_PATTERN = re.compile(r"(\|\||&&)\s*(true|\d+\s*==?\s*\d+|'1'\s*==?\s*'1')", re.IGNORECASE)
_UNICODE_ESCAPE = re.compile(r"\\u([0-9a-fA-F]{4})")
_JAVASCRIPT_PATTERN = re.compile(r"\b(function|return|eval|constructor|while|for)\s*[\(\{]", re.IGNORECASE)
_OBJECT_INJECTION_PATTERN = re.compile(r"\}\s*,\s*\{")
_QUOTE_ESCAPE_PATTERN = re.compile(r"""\\["']|["']\\""")
_SQL_KEYWORDS = ("select", "from", "where", "join", "delete", "drop", "alter", "exec", "execute")

_COSMOS_PATTERNS = (
    ("--", "SQL comment injection"),
    ("/*", "Multi-line comment injection"),
    ("' or '1'='1", "Boolean-based injection"),
    ("' or 1=1", "Boolean-based injection"),
    ('" or "1"="1', "Boolean-based injection"),
    (" union ", "UNION injection"),
    (";", "Stacked query injection"),
    (" or 1=1", "Always-true condition"),
    (" or true", "Always-true condition"),
    ("'", "String escape attempt"),
)


class NoSqlInjectionDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.NO_SQL_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if not has_sink(arguments):  # sink-only: needs the real query/filter
            return True
        query = _resolve_query(user_input, arguments)
        if _is_blank(query) or _is_blank(user_input):
            return True
        # Whitespace-insensitive correlation: the app often json.loads the input then re-serializes the filter
        # (json.dumps adds spaces after ':'/','), so the raw input (e.g. {"$ne":null}) is not a literal substring
        # of the query ({"$ne": null}). Compare with whitespace stripped so reformatting does not evade detection.
        if not _contains_ignore_case(query, user_input) and not _contains_ignore_case(_strip_ws(query), _strip_ws(user_input)):
            return True
        if len(user_input) <= 1:
            return True
        return False

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        query = _resolve_query(user_input, arguments)
        mongo = _detect_mongodb(query, user_input)
        if mongo is not None:
            return mongo
        return _detect_cosmosdb(query, user_input)


def _detect_mongodb(query_json: str, user_input: str) -> DetectionResult | None:
    # Match a ``$operator:`` in the raw input or its decoded forms (WAF bypass: ``%24ne`` -> ``$ne`` via percent
    # decode, ``$ne`` -> ``$ne`` via JSON unicode unescape). Any $-prefixed key supplied by the user is an
    # injected operator/pipeline stage; the bracket form ``param[$ne]`` is the query-string variant.
    decoded = _percent_decode(user_input)
    unescaped = _unicode_unescape(user_input)
    for candidate in (user_input, decoded, unescaped, _unicode_unescape(decoded)):
        match = _MONGO_OPERATOR_PATTERN.search(candidate) or _MONGO_BRACKET_PATTERN.search(candidate)
        if match:
            op = match.group(1)
            return _threat(user_input, op, _injected_fragment(candidate, op), 0.95, query_json, "MongoDB")
        if _JS_BOOLEAN_PATTERN.search(candidate):
            return _threat(user_input, None, "JavaScript boolean tautology", 0.90, query_json, "MongoDB")

    if _contains_ignore_case(query_json, "$where") or _contains_ignore_case(query_json, "$function"):
        for keyword in _JAVASCRIPT_KEYWORDS:
            if _contains_ignore_case(user_input, keyword) and _JAVASCRIPT_PATTERN.search(user_input):
                content = _injected_fragment(user_input, keyword)
                return _threat(user_input, "$where", content, 0.90, query_json, "MongoDB")

    manipulation = _detect_json_structure_manipulation(user_input)
    if manipulation is not None:
        content = f"JSON structure manipulation ({manipulation})"
        return _threat(user_input, None, content, 0.85, query_json, "MongoDB")

    if _contains_ignore_case(query_json, "$in") or _contains_ignore_case(query_json, "$nin"):
        if "[" in user_input and "]" in user_input:
            return _threat(user_input, "$in/$nin", _injected_fragment(user_input, "["), 0.80, query_json, "MongoDB")

    return None


def _detect_cosmosdb(query_text: str, user_input: str) -> DetectionResult:
    lower_input = user_input.lower()
    for pattern, description in _COSMOS_PATTERNS:
        if pattern in lower_input and _validate_cosmos_context(query_text, user_input, pattern):
            confidence = 0.95 if pattern == "' or '1'='1" else 0.85
            return _threat(user_input, None, description, confidence, query_text, "CosmosDB")

    for keyword in _SQL_KEYWORDS:
        if f" {keyword} " in lower_input or lower_input.startswith(f"{keyword} "):
            return _threat(user_input, None, f"SQL keyword: {keyword}", 0.80, query_text, "CosmosDB")

    return DetectionResult.success()


def _detect_json_structure_manipulation(user_input: str) -> str | None:
    open_braces = user_input.count("{")
    close_braces = user_input.count("}")
    open_brackets = user_input.count("[")
    close_brackets = user_input.count("]")
    if _OBJECT_INJECTION_PATTERN.search(user_input):
        return "Object injection"
    if close_braces > open_braces or close_brackets > open_brackets:
        return "Context escape"
    if _QUOTE_ESCAPE_PATTERN.search(user_input):
        return "Quote escape"
    return None


_COSMOS_SQL_CONTEXT = re.compile(
    r"(--|/\*|\bor\b|\band\b|\bunion\b|\bselect\b|=|;|\|\|)", re.IGNORECASE
)


def _validate_cosmos_context(query_text: str, user_input: str, pattern: str) -> bool:
    if _index_of_ignore_case(query_text, user_input) == -1:
        return False
    if pattern == "'":
        # An odd number of quotes alone is NOT enough: a legitimate name (``kate-o'brien``) carries one quote but
        # no injection. Require the quote to come with actual SQL-ish syntax (boolean op, comment, '=', ';', ...).
        quote_count = user_input.count("'")
        if quote_count == 0 or quote_count % 2 == 0:
            return False
        return _COSMOS_SQL_CONTEXT.search(user_input) is not None
    return True


def _threat(
    payload: str,
    operator: str | None,
    injected_content: str,
    confidence: float,
    query: str,
    database_type: str,
) -> DetectionResult:
    # InjectedOperator is the bare MongoDB operator that triggered ($ne, $where, ...) and is
    # only present for operator-based detections; InjectedContent is the offending fragment of
    # the user input (operator-in-context) or, for structural / Cosmos SQL-like hits, a label
    # describing what was injected. UserInput keeps the full value.
    metadata: dict[str, str] = {"UserInput": payload}
    if operator:
        metadata["InjectedOperator"] = operator
    metadata.update(
        {
            "InjectedContent": injected_content,
            "Query": query or "",
            "Operation": "nosql.query",
            "DatabaseType": database_type,
        }
    )
    return DetectionResult.threat(
        ProtectionModuleType.NO_SQL_INJECTION.value,
        f"NoSQL injection detected: {operator or injected_content}",
        confidence,
        metadata,
    )


def _injected_fragment(user_input: str, marker: str) -> str:
    """The offending snippet of the user input around ``marker`` (operator in context)."""
    idx = user_input.lower().find(marker.lower())
    if idx == -1:
        return user_input.strip()
    return user_input[idx : idx + 60].strip()


def _resolve_query(user_input: str, arguments: Sequence[str]) -> str:
    if arguments and len(arguments) > 0 and arguments[0] is not None:
        return arguments[0]
    return user_input


def _is_blank(value: str | None) -> bool:
    return not value or not value.strip()


def _strip_ws(value: str) -> str:
    return re.sub(r"\s+", "", value) if value else value


def _percent_decode(value: str) -> str:
    try:
        return urllib.parse.unquote(value)
    except Exception:  # noqa: BLE001
        return value


def _unicode_unescape(value: str) -> str:
    """Decode JSON ``\\uXXXX`` escapes (``\\u0024`` -> ``$``) so unicode-escaped operators are revealed."""
    if "\\u" not in value:
        return value
    try:
        return _UNICODE_ESCAPE.sub(lambda m: chr(int(m.group(1), 16)), value)
    except Exception:  # noqa: BLE001
        return value


def _contains_ignore_case(haystack: str, needle: str) -> bool:
    return _index_of_ignore_case(haystack, needle) != -1


def _index_of_ignore_case(haystack: str, needle: str) -> int:
    if not needle:
        return 0
    return haystack.lower().find(needle.lower())

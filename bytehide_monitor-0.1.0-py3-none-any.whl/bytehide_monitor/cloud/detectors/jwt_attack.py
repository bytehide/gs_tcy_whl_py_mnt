"""JWT-attack detector (request-level).

Inspects the request's ``Authorization`` credential (``Bearer <jwt>`` or ``ApiKey <jwt>``) and
decodes the JWT header/payload WITHOUT any external library (manual base64url, all in try/except),
flagging the common JWT abuse patterns:

* ``alg`` is ``none`` (case-insensitive), or the token is unsigned (only 2 segments / empty
  signature) - classic algorithm-stripping forgery.
* ``alg`` is HMAC (``HS*``) when an asymmetric algorithm is expected. Two heuristics, documented
  inline: (a) ``config["expected_alg"]`` is set and the token's ``alg`` does not match it; (b) no
  expected alg is configured but the token is HS* AND carries an admin role claim - the signature
  of an RS/ES->HS confusion or forge attempt trying to escalate.
* ``kid`` contains path/injection characters (``/dev/null``, ``../``, ``/``, ``\\``) - kid path
  traversal / SQLi-via-kid.
* a ``jku`` or ``x5u`` header pointing at a host - attacker-controlled key URL (key injection /
  SSRF in the validator).
* ``exp`` already in the past - an expired token being replayed (low confidence on its own).
* an admin role claim (``role``/``roles``/``isAdmin``) - recorded in metadata; on its own it does
  not block, only in combination with a suspicious signature (handled by raising confidence).

Nothing here performs I/O and every decode path is guarded, so the detector is deterministic and
fail-open: any unexpected shape yields "no threat" rather than raising.

Operates at request level only: :meth:`run` (per-input) always returns success; detection happens
in :meth:`run_request` over the full :class:`ContextObject`.
"""

from __future__ import annotations

import base64
import binascii
import json
import time
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DEFAULT_ADMIN_CLAIM_NAMES = ("role", "roles", "isadmin", "is_admin", "admin", "is_staff")
_DEFAULT_ADMIN_VALUES = ("admin", "administrator", "superuser", "root", "superadmin")
_SUSPICIOUS_KID_TOKENS = ("/dev/null", "../", "..\\")
_TOKEN_PREVIEW = 16  # chars of the raw token kept in metadata (never the whole token)


class JwtAttackDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.JWT_ATTACK

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        # Per-input path is a no-op: this detector only runs at request level.
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        try:
            return self._evaluate(context)
        except Exception:  # noqa: BLE001 - request-level detection is fail-open
            return None

    def _evaluate(self, context: ContextObject) -> DetectionResult | None:
        if context is None:
            return None
        config = _config(context)
        token = _extract_token(context.get_header("Authorization"))
        if not token:
            return None

        parts = token.split(".")
        if len(parts) < 2:
            return None  # not a JWT shape; leave it alone (fail-open)

        header = _decode_segment(parts[0])
        payload = _decode_segment(parts[1]) if len(parts) >= 2 else None
        if header is None:
            return None  # cannot parse -> do not block

        alg = str(header.get("alg", "")).strip()
        kid = header.get("kid")
        jku = header.get("jku")
        x5u = header.get("x5u")
        signature = parts[2] if len(parts) >= 3 else ""

        reasons: list[str] = []
        confidence = 0.0
        admin_claim = _admin_claim(payload, config)

        # 1. Unsigned / alg=none -> highest severity (token forgery).
        if alg.lower() == "none":
            reasons.append("alg=none (unsigned token)")
            confidence = max(confidence, 0.95)
        if len(parts) == 2 or not signature.strip():
            reasons.append("token has no signature")
            confidence = max(confidence, 0.9)

        # 2. Algorithm confusion / unexpected HMAC.
        expected_alg = config.get("expected_alg")
        if expected_alg and isinstance(expected_alg, str) and alg and alg.lower() != expected_alg.strip().lower():
            reasons.append(f"alg '{alg}' does not match expected '{expected_alg}'")
            # HS* where asymmetric expected is the textbook key-confusion forge.
            confidence = max(confidence, 0.9 if alg.lower().startswith("hs") else 0.7)
        elif not expected_alg and alg.lower().startswith("hs") and admin_claim is not None:
            # No expected alg configured: an HMAC token that ALSO claims admin is the
            # signature of an RS/ES->HS confusion attempt escalating privilege.
            reasons.append(f"HMAC alg '{alg}' with admin role claim (possible key confusion/forge)")
            confidence = max(confidence, 0.85)

        # 3. kid path traversal / injection.
        if isinstance(kid, str) and _suspicious_kid(kid):
            reasons.append(f"suspicious kid '{kid[:64]}'")
            confidence = max(confidence, 0.85)

        # 4. Attacker-controlled key URL (jku/x5u) -> key injection / SSRF in validation.
        for name, value in (("jku", jku), ("x5u", x5u)):
            if isinstance(value, str) and value.strip():
                reasons.append(f"{name} header present ('{value[:64]}')")
                confidence = max(confidence, 0.8)

        # 4b. Signature-length sanity (catches a forged/garbage signature WITHOUT the key): a signed
        # token's signature length is fixed by the alg family - HS*=32/48/64, ES*>=64, RSA/PS*>=128
        # bytes. A signed alg carrying a far-too-short signature is forged (e.g. RS256 with a 20-byte
        # signature). Legitimate tokens always have the correct length, so no false positives.
        if signature.strip():
            min_sig = _min_signature_bytes(alg)
            sig_bytes = _decoded_len(signature)
            if min_sig > 0 and sig_bytes >= 0 and sig_bytes < min_sig:
                reasons.append(f"signature too short for alg '{alg}' ({sig_bytes} bytes; forged/invalid)")
                confidence = max(confidence, 0.85)

        # 5. Expired token (replay) - low confidence on its own.
        exp = _claim_int(payload, "exp")
        if exp is not None and exp < int(time.time()):
            reasons.append("token expired (exp in the past)")
            confidence = max(confidence, 0.4)

        if not reasons:
            return None

        metadata: dict[str, Any] = {
            "Alg": alg or None,
            "Reasons": reasons,
            "TokenPreview": token[:_TOKEN_PREVIEW] + ("..." if len(token) > _TOKEN_PREVIEW else ""),
        }
        if isinstance(kid, str):
            metadata["Kid"] = kid[:128]
        if isinstance(jku, str):
            metadata["Jku"] = jku[:256]
        if isinstance(x5u, str):
            metadata["X5u"] = x5u[:256]
        if admin_claim is not None:
            metadata["AdminClaim"] = admin_claim
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        return DetectionResult.threat(
            self.type().value,
            "JWT attack detected: " + "; ".join(reasons),
            confidence,
            metadata,
        )


def _config(context: ContextObject) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None)
    return cfg if isinstance(cfg, dict) else {}


def _extract_token(authorization: str | None) -> str | None:
    if not authorization or not isinstance(authorization, str):
        return None
    value = authorization.strip()
    lowered = value.lower()
    for scheme in ("bearer ", "apikey "):
        if lowered.startswith(scheme):
            return value[len(scheme):].strip() or None
    # Bare token (no scheme) that looks like a JWT (two dots) is still inspected.
    if value.count(".") >= 2:
        return value
    return None


def _decode_segment(segment: str) -> dict[str, Any] | None:
    if not segment:
        return None
    try:
        padding = "=" * (-len(segment) % 4)
        raw = base64.urlsafe_b64decode(segment + padding)
        parsed = json.loads(raw.decode("utf-8", errors="replace"))
        return parsed if isinstance(parsed, dict) else None
    except (binascii.Error, ValueError, UnicodeDecodeError, TypeError):
        return None
    except Exception:  # noqa: BLE001 - any decode failure is "not a JWT segment"
        return None


def _min_signature_bytes(alg: str) -> int:
    """Minimum valid signature length (bytes) for the algorithm family, or 0 for unknown/none."""
    a = (alg or "").upper()
    if a.startswith("HS"):
        return 32   # HS256=32, HS384=48, HS512=64
    if a.startswith("ES"):
        return 64   # ES256=64, ES384=96, ES512=132
    if a.startswith("RS") or a.startswith("PS"):
        return 128  # RSA signature = key size; 2048-bit=256, smallest sane is 1024-bit=128
    return 0


def _decoded_len(segment: str) -> int:
    try:
        padding = "=" * (-len(segment) % 4)
        return len(base64.urlsafe_b64decode(segment + padding))
    except Exception:  # noqa: BLE001
        return -1


def _suspicious_kid(kid: str) -> bool:
    lowered = kid.lower()
    if any(token in lowered for token in _SUSPICIOUS_KID_TOKENS):
        return True
    return "/" in kid or "\\" in kid


def _admin_claim(payload: dict[str, Any] | None, config: dict[str, Any]) -> str | None:
    if not isinstance(payload, dict):
        return None
    names = _str_list(config.get("admin_claim_names")) or list(_DEFAULT_ADMIN_CLAIM_NAMES)
    values = _str_list(config.get("admin_values")) or list(_DEFAULT_ADMIN_VALUES)
    names_lower = {n.lower() for n in names}
    values_lower = {v.lower() for v in values}
    for key, claim in payload.items():
        if not isinstance(key, str) or key.lower() not in names_lower:
            continue
        for candidate in _iter_strings(claim):
            cl = candidate.lower()
            # Substring match: Spring/crAPI use "ROLE_ADMIN"; an exact-equals check would miss it.
            if any(value in cl for value in values_lower):
                return f"{key}={candidate}"
        if isinstance(claim, bool) and claim and key.lower() in {"isadmin", "is_admin", "admin", "is_staff"}:
            return f"{key}=true"
    return None


def _iter_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return [item for item in value if isinstance(item, str)]
    return []


def _claim_int(payload: dict[str, Any] | None, name: str) -> int | None:
    if not isinstance(payload, dict):
        return None
    raw = payload.get(name)
    try:
        if isinstance(raw, bool):
            return None
        if isinstance(raw, (int, float)):
            return int(raw)
        if isinstance(raw, str) and raw.strip().isdigit():
            return int(raw.strip())
    except (ValueError, TypeError):
        return None
    return None


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None

"""XXE (XML External Entity) detector.

Pure, stateless port of the .NET ``XxeDetector``: case-insensitive substring and
regex matching for dangerous DTD declarations, external entity references and
protocols. Performs no XML parsing and no I/O.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_CONFIDENCE = 0.95
_DANGEROUS_PATTERNS = ("<!DOCTYPE", "<!ENTITY", "SYSTEM", "PUBLIC", "<!ELEMENT", "<!ATTLIST")
_DANGEROUS_PROTOCOLS = (
    "file://", "http://", "https://", "ftp://", "gopher://", "expect://", "php://",
)
_PARAMETER_ENTITY = re.compile(r"%\w+;")
_CUSTOM_ENTITY = re.compile(r"&(?!lt;|gt;|amp;|quot;|apos;|#)\w+;", re.IGNORECASE)
# XInclude: a DOCTYPE-less file/SSRF read vector (<xi:include href="file:///...">). Match the include element or
# the XInclude namespace so it is caught even though it has no DTD declaration or entity reference.
_XINCLUDE = re.compile(r"<\s*\w+:include\b|xmlns(?::\w+)?\s*=\s*['\"]https?://www\.w3\.org/2001/xinclude", re.IGNORECASE)


class XxeDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.XML_EXTERNAL_ENTITY

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if user_input is None or not user_input.strip():
            return True
        # Require real XML markup: a DTD declaration ("<!...") or an entity reference.
        # The bare "SYSTEM"/"PUBLIC" keywords only matter inside a DTD, so gating on the
        # declaration marker avoids flagging common words (e.g. "system", "public").
        if "<!" in user_input:
            return False
        if _XINCLUDE.search(user_input):
            return False
        if "&" in user_input and ";" in user_input and _CUSTOM_ENTITY.search(user_input):
            return False
        if "%" in user_input and ";" in user_input and _PARAMETER_ENTITY.search(user_input):
            return False
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        normalized = user_input.upper()

        if _XINCLUDE.search(user_input):
            return _threat(user_input, "XInclude external reference")

        for pattern in _DANGEROUS_PATTERNS:
            if pattern in normalized:
                return _threat(user_input, pattern)

        for protocol in _DANGEROUS_PROTOCOLS:
            if protocol.upper() in normalized:
                return _threat(user_input, protocol)

        if "%" in normalized and ";" in normalized and _PARAMETER_ENTITY.search(normalized):
            return _threat(user_input, "Parameter entity reference")

        if "&" in user_input and ";" in user_input and _CUSTOM_ENTITY.search(user_input):
            return _threat(user_input, "Custom entity reference")

        return DetectionResult.success()


def _threat(payload: str, evidence: str) -> DetectionResult:
    # Matches the backend XxeMetadata contract (session keys live in the incident's
    # session block, not here). The snippet is truncated like the .NET interceptor.
    snippet = payload if len(payload) <= 500 else payload[:500] + "..."
    metadata = {
        "Operation": "xml.parse",
        "MatchedPattern": evidence,
        "XmlContentSnippet": snippet,
    }
    return DetectionResult.threat(
        ProtectionModuleType.XML_EXTERNAL_ENTITY.value,
        f"XXE (XML External Entity) pattern detected: {evidence}",
        _CONFIDENCE,
        metadata,
    )

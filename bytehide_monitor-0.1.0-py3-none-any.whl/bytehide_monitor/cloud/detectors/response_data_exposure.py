"""Response data-exposure detector (response-level).

Flags an OUTGOING response whose body leaks credentials or sensitive PII back to the client - the
classic over-exposed-object / excessive-data-exposure API flaw (e.g. crAPI's
``GET /workshop/api/shop/orders/{id}`` returning the buyer's email, password and available credit).

Signals (all configurable):
* Sensitive JSON-style keys with a NON-EMPTY value: ``password``, ``passwd``, ``api_key``/``apiKey``,
  ``secret``, ``private_key``, ``available_credit``/``credit``/``balance`` and friends. A key alone is
  not enough - the value must be present, which keeps schema/echo responses from tripping.
* Free-text patterns: AWS access keys (``AKIA...``), PEM private-key headers (``BEGIN PRIVATE KEY``),
  and (optionally Luhn-validated) credit-card numbers.

To keep false positives low: only keys with a non-empty value count, and detection fires only when the
number of distinct findings reaches ``min_findings`` (default 1). Confidence scales with the number and
severity of findings. Metadata records the TYPES found and a count - never the leaked value in clear
(values are masked/omitted entirely).

Config keys (all optional):
* ``sensitive_keys``: JSON key names to flag (overrides the default set).
* ``patterns``: extra regex patterns (name -> pattern) appended to the built-in ones.
* ``min_findings``: minimum distinct findings before flagging (default 1).
* ``max_body_bytes``: do not scan bodies larger than this (default 1 MiB).
* ``luhn``: when true, credit-card matches must pass the Luhn checksum (default true).

Response-level only: :meth:`run`/:meth:`run_request` are no-ops; detection is in :meth:`run_response`.
Nothing here performs I/O and every path is guarded, so the detector is deterministic and fail-open.
"""

from __future__ import annotations

import base64
import binascii
import json
import os
import re
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector, ResponseView
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

# Keys that should NEVER appear in a response body: pure credentials/secrets that no app returns to
# anyone, not even the owner. Deliberately EXCLUDES fields a user legitimately sees in their OWN
# response - balances (``available_credit``/``credit``/``balance``) and payment fields
# (``card_number``/``cvv``) that the order/payment page returns by design. Flagging those 403s the
# app's own pages, not a leak. A REAL card-number leak (a valid PAN) is still caught by the Luhn
# free-text pattern below; OTHER users' PII is caught by the ownership-aware path. Apps that want to
# gate any of these can add them via the ``sensitive_keys`` policy override.
_DEFAULT_SENSITIVE_KEYS = (
    "password", "passwd", "pwd", "api_key", "apikey", "secret", "client_secret",
    "private_key", "privatekey", "access_token", "refresh_token", "ssn",
)
# Built-in free-text patterns. Names double as the "type found" reported in metadata.
_AWS_KEY = re.compile(r"\bAKIA[0-9A-Z]{16}\b")
_PEM_PRIVATE_KEY = re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----")
# 13-19 digit runs (optionally separated) - candidate card numbers, Luhn-filtered by default.
_CARD_CANDIDATE = re.compile(r"\b(?:\d[ -]?){13,19}\b")
# Response-DLP PII: email addresses and phone numbers. Opt-in (see ``detect_pii``); used to catch
# excessive-data-exposure responses that leak personal contact data (crAPI's mechanic reports and
# order details leak the owner's email + phone). Disabled by default to avoid flagging an endpoint
# legitimately returning a single user's own profile.
_EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
_PHONE_CANDIDATE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
# ISO-8601 dates / datetimes look phone-ish ("2024-01-15" -> 8 digits with dashes). Strip them before
# phone scanning so a response full of timestamps (e.g. a list of the user's own orders) is not
# mistaken for a list of phone numbers.
_DATETIME_RE = re.compile(r"\d{4}-\d{2}-\d{2}(?:[T ][\d:.]+(?:Z|[+-]\d{2}:?\d{2})?)?")
# JSON-ish "key": "value" with a non-empty value (string, number, or unquoted token).
_JSON_KEY_VALUE_TMPL = r'["\']?{key}["\']?\s*[:=]\s*(?P<v>"[^"]*"|\'[^\']*\'|[^\s,}}\]]+)'

_DEFAULT_MAX_BODY_BYTES = 1024 * 1024  # 1 MiB
_MAX_TYPES_REPORTED = 20


class ResponseDataExposureDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.DATA_EXPOSURE

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        # Per-input/request paths are no-ops: this detector only runs at response level.
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_response(self, context: ContextObject, response: ResponseView) -> DetectionResult | None:
        try:
            return self._evaluate(context, response)
        except Exception:  # noqa: BLE001 - response-level detection is fail-open
            return None

    def _evaluate(self, context: ContextObject, response: ResponseView) -> DetectionResult | None:
        if response is None:
            return None
        body = response.body
        if not body or not isinstance(body, str):
            return None

        config = _config(context)
        max_bytes = _config_int(config, "max_body_bytes", _DEFAULT_MAX_BODY_BYTES)
        # Do not scan oversized bodies (cost + FP risk on large HTML pages).
        if len(body.encode("utf-8", "replace")) > max_bytes:
            return None

        sensitive_keys = _str_list(config.get("sensitive_keys")) or list(_DEFAULT_SENSITIVE_KEYS)
        luhn_required = _config_bool(config, "luhn", default=True)

        found: list[str] = []

        # 1. Sensitive JSON keys carrying a non-empty value.
        for key in sensitive_keys:
            if not key:
                continue
            pattern = re.compile(_JSON_KEY_VALUE_TMPL.format(key=re.escape(key)), re.IGNORECASE)
            for match in pattern.finditer(body):
                if _nonempty_value(match.group("v")):
                    found.append(f"key:{key.lower()}")
                    break  # one finding per key type is enough

        # 2. Free-text credential patterns.
        if _AWS_KEY.search(body):
            found.append("aws_access_key")
        if _PEM_PRIVATE_KEY.search(body):
            found.append("private_key_block")
        if self._has_card(body, luhn_required):
            found.append("credit_card")

        # 2b. Response-DLP PII (opt-in): emails / phone numbers leaked in the body. A single user's own
        # profile (1 email, maybe 1 phone) is common and benign, so this only fires on a contact RECORD
        # (an email AND a phone together) or on BULK PII (>=2 distinct emails or phones) - the shape of an
        # over-exposed object / list of other users. Off by default; enable via config or env.
        if _pii_enabled(config):
            found.extend(_pii_findings(body, config, context))

        # 3. Extra user-supplied patterns (name -> regex).
        for name, pattern in _extra_patterns(config):
            try:
                if pattern.search(body):
                    found.append(f"pattern:{name}")
            except Exception:  # noqa: BLE001 - a bad custom pattern must not break the scan
                continue

        # De-duplicate, preserve order.
        seen: dict[str, None] = {}
        for item in found:
            seen.setdefault(item, None)
        types = list(seen.keys())
        if not types:
            return None

        min_findings = max(1, _config_int(config, "min_findings", 1))
        if len(types) < min_findings:
            return None

        confidence = _confidence(types)
        metadata: dict[str, Any] = {
            "TypesFound": types[:_MAX_TYPES_REPORTED],
            "Count": len(types),
            "StatusCode": response.status_code,
        }
        if context is not None:
            if context.method:
                metadata["RequestMethod"] = str(context.method)
            path = context.route or context.url
            if path:
                metadata["RequestPath"] = str(path)

        return DetectionResult.threat(
            self.type().value,
            f"Sensitive data exposed in response body: {', '.join(types[:_MAX_TYPES_REPORTED])}",
            confidence,
            metadata,
        )

    @staticmethod
    def _has_card(body: str, luhn_required: bool) -> bool:
        for match in _CARD_CANDIDATE.finditer(body):
            digits = re.sub(r"[ -]", "", match.group(0))
            if not (13 <= len(digits) <= 19) or not digits.isdigit():
                continue
            if not luhn_required or _luhn_ok(digits):
                return True
        return False


def _config(context: ContextObject | None) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None) if context is not None else None
    return cfg if isinstance(cfg, dict) else {}


def _nonempty_value(raw: str | None) -> bool:
    if raw is None:
        return False
    value = raw.strip().strip('"').strip("'").strip()
    if not value:
        return False
    # Treat JSON null / empty placeholders as "no value present".
    return value.lower() not in {"null", "none", '""', "''", "[]", "{}"}


def _luhn_ok(digits: str) -> bool:
    total = 0
    reverse = digits[::-1]
    for index, char in enumerate(reverse):
        d = ord(char) - 48
        if index % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _pii_enabled(config: dict[str, Any]) -> bool:
    """Response-DLP PII detection is opt-in: config ``detect_pii`` or the BYTEHIDE_DLP_PII env."""
    raw = config.get("detect_pii")
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str) and raw.strip().lower() in {"1", "true", "yes", "on"}:
        return True
    return os.environ.get("BYTEHIDE_DLP_PII", "").strip().lower() in {"1", "true", "yes", "on"}


def _pii_findings(body: str, config: dict[str, Any], context: ContextObject | None) -> list[str]:
    """Findings for leaked contact PII, ownership-aware.

    The authoritative signal is OWNERSHIP: if the response exposes a contact email that does NOT
    belong to the requester (identified from the request's bearer JWT ``sub`` claim), the endpoint is
    leaking ANOTHER user's PII - the excessive-data-exposure / BOLA flaw (crAPI Challenge 4:
    ``GET /shop/orders/{id}`` of another buyer). When the only contacts in the body are the
    requester's own (their profile, their order list ``/orders/all``), nothing is flagged - that is
    not a leak, and blocking it breaks ordinary self-service endpoints.

    When the requester cannot be identified (no/opaque token), fall back to BULK exposure: >=N DISTINCT
    emails or phones, the shape of a list of other people's data. A lone contact record is opt-in
    (``pii_flag_contact_record``). Dates/timestamps are stripped before phone scanning."""
    emails = {m.group(0).lower() for m in _EMAIL_RE.finditer(body)}
    phone_text = _DATETIME_RE.sub(" ", body)
    phones: set[str] = set()
    for m in _PHONE_CANDIDATE.finditer(phone_text):
        digits = re.sub(r"\D", "", m.group(0))
        # 10-15 digits: real phone numbers (with country/area code). Shorter runs are usually ids,
        # quantities, prices or date fragments - excluding them keeps benign responses quiet.
        if 10 <= len(digits) <= 15:
            phones.add(digits)

    # Ownership: subtract the requester's own contacts (from the JWT). A foreign email left over is a
    # leak of someone else's data regardless of count.
    owner_emails = _requester_emails(context)
    if owner_emails:
        foreign = {e for e in emails if e not in owner_emails}
        if foreign:
            out = ["pii:foreign_contact"]
            if phones:
                out.append("pii:phones")
            return out
        # Only the requester's own contacts are present -> benign, do not fall through to heuristics.
        return []

    # No identified requester: conservative heuristics only.
    bulk = max(2, _config_int(config, "pii_bulk_min", 2))
    out2: list[str] = []
    if len(emails) >= bulk:
        out2.append("pii:emails")
    if len(phones) >= bulk:
        out2.append("pii:phones")
    if not out2 and emails and phones and _flag_contact_record(config):
        out2.append("pii:contact_record")
    return out2


def _requester_emails(context: ContextObject | None) -> set[str]:
    """Emails identifying the requester, parsed from the bearer JWT's ``sub``/``email`` claims (crAPI
    uses the email as ``sub``). Signature is NOT verified - we only need the claimed identity to know
    whose data is whose. Returns an empty set when no JWT is present (then ownership is unknown)."""
    if context is None:
        return set()
    token = _bearer_token(context)
    if not token:
        return set()
    payload = _jwt_payload(token)
    if not payload:
        return set()
    out: set[str] = set()
    for key in ("sub", "email", "preferred_username", "username", "user_name"):
        val = payload.get(key)
        if isinstance(val, str) and "@" in val:
            out.add(val.strip().lower())
    return out


def _bearer_token(context: ContextObject) -> str | None:
    headers = getattr(context, "headers", None)
    if not isinstance(headers, dict):
        return None
    for key, value in headers.items():
        if isinstance(key, str) and key.lower() == "authorization" and isinstance(value, str):
            parts = value.split(None, 1)
            if len(parts) == 2 and parts[0].lower() in ("bearer", "apikey", "jwt"):
                return parts[1].strip()
    return None


def _jwt_payload(token: str) -> dict[str, Any] | None:
    try:
        segments = token.split(".")
        if len(segments) < 2:
            return None
        raw = segments[1]
        padded = raw + "=" * (-len(raw) % 4)
        decoded = base64.urlsafe_b64decode(padded)
        parsed = json.loads(decoded.decode("utf-8", "replace"))
        return parsed if isinstance(parsed, dict) else None
    except (ValueError, binascii.Error, json.JSONDecodeError, UnicodeDecodeError):
        return None


def _flag_contact_record(config: dict[str, Any]) -> bool:
    """A single email+phone pair is opt-in (config ``pii_flag_contact_record`` or env), since on most
    apps the only contact record in a response is the requester's own - a false positive if blocked."""
    raw = config.get("pii_flag_contact_record")
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str) and raw.strip().lower() in {"1", "true", "yes", "on"}:
        return True
    return os.environ.get("BYTEHIDE_DLP_PII_CONTACT", "").strip().lower() in {"1", "true", "yes", "on"}


def _extra_patterns(config: dict[str, Any]) -> list[tuple[str, re.Pattern[str]]]:
    raw = config.get("patterns")
    out: list[tuple[str, re.Pattern[str]]] = []
    if isinstance(raw, dict):
        items = raw.items()
    elif isinstance(raw, (list, tuple)):
        items = enumerate(raw)  # type: ignore[assignment]
    else:
        return out
    for name, pattern in items:
        if not isinstance(pattern, str) or not pattern:
            continue
        try:
            out.append((str(name), re.compile(pattern, re.IGNORECASE)))
        except re.error:
            continue
    return out


def _confidence(types: list[str]) -> float:
    # Credential leaks are higher-confidence than a lone PII-ish key; more findings -> higher.
    high = {"key:password", "key:passwd", "key:secret", "key:private_key", "aws_access_key",
            "private_key_block", "key:api_key", "key:apikey", "credit_card",
            "key:access_token", "key:refresh_token", "key:client_secret"}
    base = 0.85 if any(t in high for t in types) else 0.6
    return min(0.97, base + 0.05 * (len(types) - 1))


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


def _config_int(config: dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key)
    try:
        if isinstance(raw, bool):
            return default
        if isinstance(raw, (int, float)):
            return int(raw)
        if isinstance(raw, str) and raw.strip().lstrip("-").isdigit():
            return int(raw.strip())
    except (ValueError, TypeError):
        return default
    return default


def _config_bool(config: dict[str, Any], key: str, default: bool) -> bool:
    raw = config.get(key)
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        return raw.strip().lower() in {"1", "true", "yes", "on"}
    return default

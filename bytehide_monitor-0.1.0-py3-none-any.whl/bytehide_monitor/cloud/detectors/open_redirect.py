"""Open-redirect detector (response-side).

Fires when a redirect target (Location) is user-controlled AND points off-site: an absolute URL to another host,
a protocol-relative ``//host``, backslash tricks (``/\\``, ``\\/``), or a script URI (``javascript:``/``data:``).
Same-site relative paths (``/dashboard``) are allowed. Correlated against request inputs (arguments[0] = the
redirect URL the sink is about to issue)."""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, has_sink, is_null_or_whitespace
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_SCRIPT_URI = re.compile(r"^\s*(javascript|data|vbscript)\s*:", re.IGNORECASE)
_ABSOLUTE = re.compile(r"^\s*[a-z][a-z0-9+.\-]*://", re.IGNORECASE)


def _is_external(location: str) -> bool:
    loc = location.strip()
    if not loc:
        return False
    if _SCRIPT_URI.search(loc):
        return True
    # Protocol-relative or backslash-normalized to one (//host, /\host, \/host, \\host).
    head = loc[:2].replace("\\", "/")
    if head == "//":
        return True
    if _ABSOLUTE.search(loc):  # absolute URL with a scheme -> goes off the current origin
        return True
    return False


class OpenRedirectDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.OPEN_REDIRECT

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if is_null_or_whitespace(user_input) or len(user_input) <= 1:
            return True
        if not has_sink(arguments):
            return True
        location = arguments[0]
        if is_null_or_whitespace(location) or user_input not in location:
            return True
        return False

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        location = arguments[0]
        # Flag only when the USER INPUT itself is the off-site target (not when the app redirects off-site using
        # its own constant URL that merely contains the input).
        if not _is_external(user_input):
            return DetectionResult.success()
        result = DetectionResult.threat(
            self.type().value,
            f"Open redirect detected: user input redirects off-site to '{user_input[:80]}'",
            0.85,
        )
        result.with_metadata("UserInput", user_input)
        result.with_metadata("Location", location)
        result.with_metadata("Operation", "http.redirect")
        return result

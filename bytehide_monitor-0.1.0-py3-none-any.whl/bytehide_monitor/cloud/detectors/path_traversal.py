"""Path traversal detector (Aikido Zen algorithm).

Reports a threat only when both the user input and the full path/operation
(``arguments[0]``) carry the same traversal evidence, mirroring .NET to reduce
false positives. Double URL-decodes to catch ``%252e%252e%252f``. No filesystem
I/O.
"""

from __future__ import annotations

import re
import urllib.parse
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DANGEROUS_PATTERNS = ("../", "..\\")

_DANGEROUS_PATH_STARTS = (
    # Linux root folders
    "/bin/", "/boot/", "/dev/", "/etc/", "/home/", "/init/", "/lib/", "/media/",
    "/mnt/", "/opt/", "/proc/", "/root/", "/run/", "/sbin/", "/srv/", "/sys/",
    "/tmp/", "/usr/", "/var/",
    # Windows drives and system paths
    "c:/", "c:\\", "d:/", "d:\\", "e:/", "e:\\", "windows/", "windows\\",
    "%windir%", "%systemroot%", "program files", "program files (x86)",
    "documents and settings", "users/", "users\\", "%userprofile%", "%homepath%",
    "%homedrive%", "%programdata%", "%programfiles%", "%programfiles(x86)%",
    "%temp%", "%tmp%",
)


class PathTraversalDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.PATH_TRAVERSAL

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        path = _resolve_path(arguments)
        if not user_input or not path:
            return True
        # Case-insensitive, matching run()'s lowercased comparison: on a case-insensitive
        # filesystem (Windows) the input case may differ from the resolved path.
        if user_input.lower() not in path.lower():
            return True
        if len(user_input) > len(path):
            return True
        if len(user_input) <= 1:
            return True
        return False

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        path = _resolve_path(arguments)
        assert path is not None

        input_lower = _normalize(user_input)
        path_lower = _normalize(path)
        input_skel = _skeleton(input_lower)
        path_skel = _skeleton(path_lower)

        # Relative traversal (``../``): require evidence in BOTH the user input and the resolved path (dual-evidence,
        # low FP). Check the skeleton too, so junk bytes interposed between the dots cannot hide the sequence.
        if (_contains_unsafe_parts(input_lower) or _contains_unsafe_parts(input_skel)) and (
            _contains_unsafe_parts(path_lower) or _contains_unsafe_parts(path_skel)
        ):
            return _threat(user_input, path, "relative", None)

        # Canonical sensitive target reached through the user input (betrays traversal when the ``../`` is mangled).
        for target in _SENSITIVE_TARGETS:
            if (target in input_lower or target in input_skel) and (target in path_lower or target in path_skel):
                return _threat(user_input, path, "absolute", target)

        for start in _DANGEROUS_PATH_STARTS:
            if input_lower.startswith(start) and path_lower.startswith(start):
                return _threat(user_input, path, "absolute", start)

        return DetectionResult.success()


def _threat(payload: str, path: str, vector: str, matched_start: str | None) -> DetectionResult:
    # Matches the backend PathTraversalMetadata contract. UserInputSource / MethodName are
    # request/sink context; Operation defaults to the file-open sink (the common path).
    result = DetectionResult.threat(
        ProtectionModuleType.PATH_TRAVERSAL.value, _description(payload, vector, matched_start), 0.9
    )
    result.with_metadata("UserInput", payload)
    result.with_metadata("UserInputSource", "")
    result.with_metadata("Path", path)
    result.with_metadata("Operation", "file.open")
    result.with_metadata("MethodName", "open")
    return result


def _description(user_input: str, vector: str, matched_start: str | None) -> str:
    """Human-readable reason naming the offending input and how it escapes the intended path."""
    snippet = user_input if len(user_input) <= 80 else user_input[:80] + "..."
    if vector == "relative":
        return f"Path traversal detected: user input '{snippet}' uses '../' to escape the intended directory"
    target = f" toward '{matched_start}'" if matched_start else ""
    return f"Path traversal detected: user input '{snippet}' points to an absolute system path{target}"


def _resolve_path(arguments: Sequence[str]) -> str | None:
    if not arguments or len(arguments) == 0:
        return None
    return arguments[0]


def _contains_unsafe_parts(value: str) -> bool:
    return any(pattern in value for pattern in _DANGEROUS_PATTERNS)


def _url_decode_once(value: str) -> str:
    try:
        return urllib.parse.unquote_plus(value)
    except Exception:  # noqa: BLE001 - return original on malformed encoding
        return value


# Overlong-UTF8, fullwidth and %u-style percent-encodings of '.' '/' '\' (classic WAF-bypass for traversal).
_OVERLONG = {
    # 2-byte overlong UTF-8
    "%c0%ae": ".", "%c0%2e": ".", "%c0%ail": ".", "%c0%af": "/", "%c0%2f": "/", "%c1%9c": "\\", "%c0%5c": "\\",
    # 3-byte overlong UTF-8
    "%e0%80%ae": ".", "%e0%80%af": "/", "%e0%80%bc": "\\",
    # 4-byte overlong UTF-8
    "%f0%80%80%ae": ".", "%f0%80%80%af": "/", "%f0%80%ae": ".", "%f0%80%af": "/",
    # fullwidth (U+FF0E / U+FF0F) percent-encoded
    "%ef%bc%8e": ".", "%ef%bc%8f": "/",
    # IIS/.NET %uXXXX encodings
    "%u002e": ".", "%u002f": "/", "%u005c": "\\", "%uff0e": ".", "%uff0f": "/", "%u2024": ".", "%u2215": "/",
}
# Unicode homoglyphs of '.' and '/' that survive decoding.
_HOMOGLYPHS = {"．": ".", "／": "/", "․": ".", "∕": "/", "＼": "\\"}

# Canonical sensitive targets that betray traversal even when the ``../`` sequence is mangled by junk bytes.
_SENSITIVE_TARGETS = (
    "etc/passwd", "etc\\passwd", "etc/shadow", "etc/hosts", "proc/self/environ", "boot.ini",
    "win.ini", "windows/win.ini", "windows\\win.ini", "system32", "id_rsa", ".ssh/", ".aws/credentials",
)
# After decoding, strip everything that is not a path-meaningful char so junk bytes (stray %, %00, %ff, overlong
# leftovers, homoglyph remnants) interposed between the dots cannot hide a ``../`` sequence.
_SKELETON_STRIP = re.compile(r"[^a-z0-9./\\]+")


def _normalize(value: str) -> str:
    """Lower-case, strip overlong/fullwidth/%u dot-slash encodings, then URL-decode RECURSIVELY (catches double/
    triple encoding and ``%c0%ae``/``%uff0f`` style bypasses) before the ../ and absolute-path checks."""
    s = value.lower()
    for enc, ch in _OVERLONG.items():
        s = s.replace(enc, ch)
    prev = None
    for _ in range(8):  # decode until stable (handles %2525.. multi-encoding)
        if s == prev:
            break
        prev = s
        s = _url_decode_once(s)
        for enc, ch in _OVERLONG.items():
            s = s.replace(enc, ch)
    for glyph, ch in _HOMOGLYPHS.items():
        s = s.replace(glyph, ch)
    return s.replace("\x00", "")  # drop null bytes (``..%00/`` truncation trick)


def _skeleton(normalized: str) -> str:
    """Collapse a normalized value to only path-meaningful chars, exposing ``../`` hidden behind junk bytes."""
    return _SKELETON_STRIP.sub("", normalized)

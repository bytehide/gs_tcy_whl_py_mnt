"""SQL injection detector (differential tokenization, Aikido Zen approach).

``arguments[0]`` carries the full SQL query the input is embedded in;
``arguments[1]`` carries the SQL dialect when known. Both optional.
"""

from __future__ import annotations

from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, is_null_or_whitespace
from bytehide_monitor.cloud.detectors.sql_tokenizer import SqlTokenizer
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


class SqlInjectionDetector(CloudDetector):
    def __init__(self) -> None:
        self._tokenizer = SqlTokenizer()

    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.SQL_INJECTION

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        if is_null_or_whitespace(user_input):
            return True
        query = _query_from(arguments)
        if query is None or is_null_or_whitespace(query):
            return True
        normalized_query = query.lower()
        normalized_input = user_input.lower()
        if normalized_input not in normalized_query:
            return True
        if self._tokenizer.is_common_sql_string(normalized_input):
            return True
        return len(normalized_input.strip()) <= 1

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        query = _query_from(arguments)
        outcome = self._tokenizer.detect_injection(query, user_input)
        if not outcome.injected:
            return DetectionResult.success()
        injected = outcome.injected_content or ""
        description = f"SQL injection detected: {injected}" if injected else "SQL injection detected"
        # Metadata matches the backend's SqlInjectionMetadata contract (Parameters /
        # ParameterCount are added by the SQL sink, which has the bound DB-API params).
        result = DetectionResult.threat(self.type().value, description, outcome.confidence)
        result.with_metadata("UserInput", user_input)
        result.with_metadata("InjectedContent", injected)
        if query is not None and not is_null_or_whitespace(query):
            result.with_metadata("SqlQuery", query)
        return result


def _query_from(arguments: Sequence[str]) -> str | None:
    return arguments[0] if arguments and len(arguments) > 0 else None

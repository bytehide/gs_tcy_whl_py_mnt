"""Mass-assignment detector (request-level): VALUE-based business-logic abuse only.

Flagging mass assignment by field NAME at the request boundary is unreliable - the same key (``role``,
``status``, ``credit``) is legitimate on one endpoint and an exploit on another, and a RASP at the HTTP
edge cannot see whether the app binds it unsafely. That field-name + actual-ORM-bind detection now
lives in the ORM sink (``sinks/orm.py``), which only fires when a request value is bound to a model
attribute outside the endpoint's validated allowlist - no false positives on legitimate ``role`` fields
or on LLM message ``role`` keys.

What stays here is the VALUE-based signal, which is precise on its own: a NEGATIVE quantity/amount/etc.
on a write flips the sign of a server-side computation (crAPI Challenge 8/9:
``POST /shop/orders {"quantity": -1000}`` makes ``available_credit -= price * quantity`` ADD money).
A normal write carries a positive value, so this never fires on ``quantity: 1``.

Config keys (all optional): ``negative_value_fields`` overrides the default numeric-field set.
Request-level only: :meth:`run` is a no-op. Fail-open.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_WRITE_METHODS = {"POST", "PUT", "PATCH"}
# Numeric fields whose NEGATIVE value is a business-logic abuse, regardless of the field name. A normal
# write carries these with a sane positive value (``quantity: 1``); a negative value flips the sign of
# a server-side computation - e.g. crAPI Challenge 8/9: ``POST /shop/orders {"quantity": -1000}`` makes
# ``available_credit -= price * quantity`` ADD money (free item / inflated balance). Detected by VALUE,
# so legitimate ``quantity: 1`` is never flagged.
_NEGATIVE_VALUE_FIELDS = (
    "quantity", "qty", "amount", "count", "credit", "balance", "price",
    "total", "points", "cost", "sum", "value",
)
_MAX_DEPTH = 4
_MAX_FINDINGS = 20


class MassAssignmentDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.MASS_ASSIGNMENT

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        try:
            return self._evaluate(context)
        except Exception:  # noqa: BLE001 - fail-open
            return None

    def _evaluate(self, context: ContextObject) -> DetectionResult | None:
        if context is None or not context.method:
            return None
        if context.method.strip().upper() not in _WRITE_METHODS:
            return None
        body = context.body
        if not isinstance(body, (dict, list)):
            return None

        config = _config(context)
        neg_field_names = {
            f.lower() for f in (_str_list(config.get("negative_value_fields")) or list(_NEGATIVE_VALUE_FIELDS))
        }

        # Value-based signal only: a negative quantity/amount/etc. abuses a server-side computation.
        negative: list[str] = []
        _walk_negative(body, neg_field_names, negative, depth=0)
        if not negative:
            return None

        neg_fields = list(dict.fromkeys(negative))[:_MAX_FINDINGS]
        metadata: dict[str, Any] = {"NegativeFields": neg_fields}
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        return DetectionResult.threat(
            self.type().value,
            f"Mass assignment: invalid negative value in field(s): {', '.join(neg_fields)}",
            0.8,
            metadata,
        )


def _config(context: ContextObject) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None)
    return cfg if isinstance(cfg, dict) else {}


def _walk_negative(node: Any, field_names: set[str], found: list[str], depth: int) -> None:
    """Collect quantity/amount-style fields carrying a NEGATIVE numeric value (value-based abuse)."""
    if depth > _MAX_DEPTH or len(found) >= _MAX_FINDINGS:
        return
    if isinstance(node, dict):
        for key, value in node.items():
            if isinstance(key, str) and key.lower() in field_names and _is_negative(value):
                found.append(key)
            _walk_negative(value, field_names, found, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _walk_negative(item, field_names, found, depth + 1)


def _is_negative(value: Any) -> bool:
    """True if ``value`` is (or parses to) a number < 0. Booleans are not numbers here."""
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return value < 0
    if isinstance(value, str):
        s = value.strip()
        try:
            return float(s) < 0
        except (ValueError, TypeError):
            return False
    return False


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None

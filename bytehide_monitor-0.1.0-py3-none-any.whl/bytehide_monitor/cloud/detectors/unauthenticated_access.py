"""Unauthenticated-access detector (request-level).

Flags a request to a SENSITIVE route that arrives without credentials. A route is sensitive when
it matches one of the configured ``sensitive_routes`` glob/substring patterns (checked against both
``context.route`` and ``context.url``) and is not in the ``public_routes`` allowlist (login/signup/
health and friends), which prevents false positives on intentionally anonymous endpoints.

"Without credentials" means no ``Authorization`` header and (when ``require_session_cookie`` is set
in config) no session cookie either.

Config keys (all optional, sensible defaults):
* ``sensitive_routes``: list of patterns (glob ``*`` or plain substring) - overrides the default.
* ``public_routes``: allowlist patterns appended to the defaults.
* ``session_cookie_names``: cookie names that count as a session.
* ``require_session_cookie``: when true, a session cookie satisfies the auth check on its own.

Request-level only: :meth:`run` is a no-op; detection is in :meth:`run_request`. Fail-open.
"""

from __future__ import annotations

import fnmatch
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DEFAULT_SENSITIVE_ROUTES = (
    "*/orders/*", "*/orders", "*/admin/*", "*/admin", "*/mechanic/*", "*/mechanic",
    "*/dashboard", "*/dashboard/*", "*/account/*", "*/account", "*/profile",
    "*/users/*", "*/wallet/*", "*/vehicle/*",
)
_DEFAULT_PUBLIC_ROUTES = (
    "*/login", "*/login/*", "*/signup", "*/signup/*", "*/register", "*/register/*",
    "*/health", "*/healthz", "*/health/*", "*/ping", "*/metrics", "*/forgot-password",
    "*/reset-password", "*/verify*", "*/public/*", "*/docs", "*/docs/*", "*/openapi*",
    "*/.well-known/*",
)
_DEFAULT_SESSION_COOKIE_NAMES = ("session", "sessionid", "sid", "jsessionid", "connect.sid", "auth", "token")


class UnauthenticatedAccessDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.UNAUTHENTICATED_ACCESS

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        try:
            return self._evaluate(context)
        except Exception:  # noqa: BLE001 - fail-open
            return None

    def _evaluate(self, context: ContextObject) -> DetectionResult | None:
        if context is None:
            return None
        config = _config(context)
        candidates = [c for c in (context.route, context.url) if c]
        if not candidates:
            return None

        public_routes = list(_DEFAULT_PUBLIC_ROUTES) + (_str_list(config.get("public_routes")) or [])
        if any(_matches_any(c, public_routes) for c in candidates):
            return None

        sensitive_routes = _str_list(config.get("sensitive_routes")) or list(_DEFAULT_SENSITIVE_ROUTES)
        matched = next((c for c in candidates if _matches_any(c, sensitive_routes)), None)
        if matched is None:
            return None

        if _has_authorization(context):
            return None
        if _config_bool(config, "require_session_cookie", default=False) and _has_session_cookie(context, config):
            return None

        metadata: dict[str, Any] = {"Route": matched[:256]}
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        return DetectionResult.threat(
            self.type().value,
            f"Unauthenticated access to sensitive route '{matched[:128]}' (no Authorization)",
            0.7,
            metadata,
        )


def _config(context: ContextObject) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None)
    return cfg if isinstance(cfg, dict) else {}


def _has_authorization(context: ContextObject) -> bool:
    value = context.get_header("Authorization")
    return bool(value and value.strip())


def _has_session_cookie(context: ContextObject, config: dict[str, Any]) -> bool:
    cookies = context.cookies
    if not cookies:
        return False
    names = _str_list(config.get("session_cookie_names")) or list(_DEFAULT_SESSION_COOKIE_NAMES)
    names_lower = {n.lower() for n in names}
    for key, value in cookies.items():
        if isinstance(key, str) and key.lower() in names_lower and value:
            return True
    return False


def _matches_any(value: str, patterns: Sequence[str]) -> bool:
    lowered = value.lower()
    for pattern in patterns:
        if not pattern:
            continue
        pat = pattern.lower()
        if "*" in pat or "?" in pat or "[" in pat:
            if fnmatch.fnmatch(lowered, pat):
                return True
        elif pat in lowered:
            return True
    return False


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


def _config_bool(config: dict[str, Any], key: str, default: bool) -> bool:
    raw = config.get(key)
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        return raw.strip().lower() in {"1", "true", "yes", "on"}
    return default

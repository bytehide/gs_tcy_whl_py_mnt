"""The nine OWASP cloud detectors."""

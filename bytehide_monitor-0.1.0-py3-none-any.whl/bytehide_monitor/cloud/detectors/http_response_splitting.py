"""HTTP response splitting / CRLF-injection detector (response-side).

Fires when a value about to be written into a response header / cookie contains a CR or LF (raw, or
percent/unicode-encoded), which lets an attacker inject headers or split the response. Value-direct: a newline in
a header value is always illegitimate."""

from __future__ import annotations

import re
from collections.abc import Sequence

from bytehide_monitor.cloud.detectors.detector import CloudDetector, is_null_or_whitespace
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

# Raw CR/LF, percent-encoded (%0d/%0a, double-encoded %250d/%250a), escaped (\r/\n), and unicode line separators.
_CRLF = re.compile("[\r\n  ]|%0d|%0a|%250d|%250a|\\\\r|\\\\n", re.IGNORECASE)


class HttpResponseSplittingDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.HTTP_RESPONSE_SPLITTING

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return is_null_or_whitespace(user_input)

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        if self.return_early(user_input, arguments):
            return DetectionResult.success()
        match = _CRLF.search(user_input)
        if match is None:
            return DetectionResult.success()
        result = DetectionResult.threat(
            self.type().value,
            "HTTP response splitting / CRLF injection detected: newline in a header value",
            0.9,
        )
        result.with_metadata("UserInput", user_input[:120])
        result.with_metadata("MatchedPattern", match.group(0))
        result.with_metadata("Operation", "http.set_header")
        return result

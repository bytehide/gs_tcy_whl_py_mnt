"""Broken-authentication brute-force detector (request-level + state).

Flags brute-force / credential-stuffing / OTP-abuse against authentication and other sensitive
endpoints. On every request whose route matches a configurable ``auth_routes`` list (login, OTP,
check-otp, forget/reset-password, contact_mechanic ...), it increments a counter in a sliding window
keyed by ``(client_ip, route)`` and flags a threat once the count exceeds ``max_attempts`` within
``window_seconds``.

State and reuse:
* Counting reuses the SDK's existing :class:`SlidingWindowRateLimiter` (the same sliding-window util
  the request collector uses for IP/session rate limiting) via a module-level instance, rather than
  reimplementing the window. State is therefore IN MEMORY and per-process: like the existing
  rate-limiter, counts are NOT shared across replicas, so a distributed deployment sees the threshold
  per process. This is documented and acceptable for a heuristic ``log`` detector.
* Response signal (optional): when this detector runs from the RESPONSE seam
  (:meth:`run_response`), only FAILED auth responses (HTTP 401/403 or a body containing an
  ``INVALID_OTP``-style marker) are counted, which sharply cuts false positives (legitimate
  successful logins do not accumulate). When only the request seam is available
  (:meth:`run_request`), every matching request is counted instead. Each request is counted once:
  if the response seam counts it, the request seam does not re-count (a per-request guard flag on the
  context prevents double counting).

Config keys (all optional):
* ``auth_routes``: route glob/substring patterns to watch (overrides the default set).
* ``max_attempts``: attempts allowed in the window before flagging (default 10).
* ``window_seconds``: sliding-window length in seconds (default 60).

Nothing here performs I/O; every path is guarded, so the detector is deterministic and fail-open.
"""

from __future__ import annotations

import fnmatch
from collections.abc import Sequence
from typing import Any

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.detector import CloudDetector, ResponseView
from bytehide_monitor.cloud.ratelimit.sliding_window_rate_limiter import SlidingWindowRateLimiter
from bytehide_monitor.core.protection.detection_result import DetectionResult
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_DEFAULT_AUTH_ROUTES = (
    "*login*", "*otp*", "*check-otp*", "*verify-otp*", "*forget-password*",
    "*forgot-password*", "*reset*", "*contact_mechanic*", "*signin*", "*authenticate*",
)
_DEFAULT_MAX_ATTEMPTS = 10
_DEFAULT_WINDOW_SECONDS = 60
# Body markers (case-insensitive) that indicate a FAILED auth attempt on a 200-style response.
_FAILURE_MARKERS = ("invalid_otp", "invalid otp", "invalid credential", "incorrect password",
                    "authentication failed", "login failed", "wrong otp")

# Module-level shared window (in-memory, per-process). Reuses the SDK's sliding-window util.
_WINDOW = SlidingWindowRateLimiter()
# Sentinel marking that THIS request was already counted (by the response seam), so the request
# seam does not double-count. Stored on the context object.
_COUNTED_ATTR = "_broken_auth_counted"


class BrokenAuthBruteForceDetector(CloudDetector):
    def type(self) -> ProtectionModuleType:
        return ProtectionModuleType.BROKEN_AUTH

    def return_early(self, user_input: str, arguments: Sequence[str]) -> bool:
        return True

    def run(self, user_input: str, arguments: Sequence[str]) -> DetectionResult:
        return DetectionResult.success()

    def run_request(self, context: ContextObject) -> DetectionResult | None:
        try:
            # Request seam: count every matching request (we have no failure signal here).
            return self._evaluate(context, count=True)
        except Exception:  # noqa: BLE001 - fail-open
            return None

    def run_response(self, context: ContextObject, response: ResponseView) -> DetectionResult | None:
        try:
            # Response seam: count ONLY failed auth responses (lower FP). Mark the request as
            # counted so the request seam (which runs earlier) is not double-counting it - though
            # in the current wiring response runs after request, the flag also protects re-entry.
            failed = _is_failed_auth(response)
            return self._evaluate(context, count=failed)
        except Exception:  # noqa: BLE001 - fail-open
            return None

    def _evaluate(self, context: ContextObject, count: bool) -> DetectionResult | None:
        if context is None:
            return None
        candidates = [c for c in (context.route, context.url) if c]
        if not candidates:
            return None

        config = _config(context)
        auth_routes = _str_list(config.get("auth_routes")) or list(_DEFAULT_AUTH_ROUTES)
        matched = next((c for c in candidates if _matches_any(c, auth_routes)), None)
        if matched is None:
            return None

        max_attempts = max(1, _config_int(config, "max_attempts", _DEFAULT_MAX_ATTEMPTS))
        window_seconds = max(1, _config_int(config, "window_seconds", _DEFAULT_WINDOW_SECONDS))
        window_ms = window_seconds * 1000

        client_ip = context.client_ip or "unknown"
        # Key on the matched route PATTERN-bearing value so siblings of the same endpoint share a
        # bucket; (ip, route) is the unit being brute-forced.
        key = f"{client_ip}|{matched}"

        if count and not _already_counted(context):
            # is_allowed appends the current timestamp and trims the window; we only use it to add.
            _WINDOW.is_allowed(key, window_ms, max_attempts)
            _mark_counted(context)

        attempts = _WINDOW.count_in_window(key, window_ms)
        if attempts <= max_attempts:
            return None

        metadata: dict[str, Any] = {
            "Route": matched[:256],
            "Attempts": attempts,
            "MaxAttempts": max_attempts,
            "WindowSeconds": window_seconds,
        }
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        # Confidence grows as attempts overshoot the threshold, capped.
        overshoot = attempts - max_attempts
        confidence = min(0.95, 0.6 + 0.05 * overshoot)
        return DetectionResult.threat(
            self.type().value,
            f"Brute-force / auth abuse on '{matched[:128]}': {attempts} attempts in {window_seconds}s "
            f"(max {max_attempts})",
            confidence,
            metadata,
        )


def _config(context: ContextObject) -> dict[str, Any]:
    cfg = getattr(context, "_request_detector_config", None)
    return cfg if isinstance(cfg, dict) else {}


def _is_failed_auth(response: ResponseView | None) -> bool:
    if response is None:
        return False
    if response.status_code in (401, 403):
        return True
    body = response.body
    if isinstance(body, str) and body:
        lowered = body.lower()
        return any(marker in lowered for marker in _FAILURE_MARKERS)
    return False


def _already_counted(context: ContextObject) -> bool:
    return bool(getattr(context, _COUNTED_ATTR, False))


def _mark_counted(context: ContextObject) -> None:
    try:
        setattr(context, _COUNTED_ATTR, True)
    except Exception:  # noqa: BLE001
        pass


def _matches_any(value: str, patterns: Sequence[str]) -> bool:
    lowered = value.lower()
    for pattern in patterns:
        if not pattern:
            continue
        pat = pattern.lower()
        if "*" in pat or "?" in pat or "[" in pat:
            if fnmatch.fnmatch(lowered, pat):
                return True
        elif pat in lowered:
            return True
    return False


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


def _config_int(config: dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key)
    try:
        if isinstance(raw, bool):
            return default
        if isinstance(raw, (int, float)):
            return int(raw)
        if isinstance(raw, str) and raw.strip().lstrip("-").isdigit():
            return int(raw.strip())
    except (ValueError, TypeError):
        return default
    return default


def _reset_state_for_tests() -> None:
    """Clear the shared window. Test-only helper (state is module-level and per-process)."""
    global _WINDOW
    _WINDOW = SlidingWindowRateLimiter()

"""Detects an attack wave: a burst of web-scanner-like requests from the same IP.

A request is suspicious when it uses a known scan method, targets a known scan path,
or carries a dangerous query payload. When an IP exceeds the threshold within the time
frame, :meth:`check` returns ``True`` once and suppresses further events for that IP
for ``min_time_between_events_ms``. Time is injectable for deterministic tests.
"""

from __future__ import annotations

import threading
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.core.helpers.datetime import now_unix_ms

DEFAULT_THRESHOLD = 15
DEFAULT_TIME_FRAME_MS = 60_000
DEFAULT_MIN_TIME_BETWEEN_EVENTS_MS = 20 * 60_000
DEFAULT_MAX_SAMPLES_PER_IP = 15

_WEB_SCAN_METHODS = frozenset(("BADMETHOD", "BADHTTPMETHOD", "BADDATA", "BADMTHD", "BDMTHD"))
_DANGEROUS_QUERY_KEYWORDS = (
    "SELECT (CASE WHEN", "SELECT COUNT(", "SLEEP(", "WAITFOR DELAY", "SELECT LIKE(CHAR(",
    "INFORMATION_SCHEMA.COLUMNS", "INFORMATION_SCHEMA.TABLES", "MD5(",
    "DBMS_PIPE.RECEIVE_MESSAGE", "SYSIBM.SYSTABLES", "RANDOMBLOB(", "SELECT * FROM",
    "1'='1", "PG_SLEEP(", "UNION ALL SELECT", "../",
)
_SCAN_PATH_SEGMENTS = frozenset(
    (
        ".env", ".git", ".aws", "wp-config.php", "phpinfo.php", "phpmyadmin", "wp-admin",
        "wp-login.php", "shell.php", "cgi-bin", "boot.ini", "etc", "passwd", "config.php",
        "admin.php", ".ssh", "id_rsa",
    )
)
_SCAN_FILE_EXTENSIONS = frozenset(("php", "asp", "aspx", "jsp", "cgi", "bak", "old", "sql", "env"))


@dataclass(frozen=True)
class Sample:
    method: str | None
    url: str | None


class _Counter:
    __slots__ = ("window_start", "count")

    def __init__(self, window_start: int) -> None:
        self.window_start = window_start
        self.count = 0


class AttackWaveDetector:
    def __init__(
        self,
        threshold: int = DEFAULT_THRESHOLD,
        time_frame_ms: int = DEFAULT_TIME_FRAME_MS,
        min_time_between_events_ms: int = DEFAULT_MIN_TIME_BETWEEN_EVENTS_MS,
        max_samples_per_ip: int = DEFAULT_MAX_SAMPLES_PER_IP,
        clock: Callable[[], int] = now_unix_ms,
    ) -> None:
        self._threshold = threshold
        self._time_frame_ms = time_frame_ms
        self._min_time_between_events_ms = min_time_between_events_ms
        self._max_samples_per_ip = max_samples_per_ip
        self._clock = clock
        self._lock = threading.Lock()
        self._suspicious_counts: dict[str, _Counter] = {}
        self._samples: dict[str, list[Sample]] = {}
        self._sent_events: dict[str, int] = {}

    def check(self, ctx: ContextObject | None) -> bool:
        if ctx is None:
            return False
        ip = ctx.client_ip
        if ip is None:
            return False
        with self._lock:
            now = self._clock()
            sent_at = self._sent_events.get(ip)
            if sent_at is not None:
                if now - sent_at < self._min_time_between_events_ms:
                    return False
                del self._sent_events[ip]

            if not self.is_web_scanner(ctx):
                return False

            counter = self._suspicious_counts.get(ip)
            if counter is None or now - counter.window_start >= self._time_frame_ms:
                counter = _Counter(now)
                self._suspicious_counts[ip] = counter
            counter.count += 1

            self._track_sample(ip, ctx.method, ctx.url)

            if counter.count < self._threshold:
                return False
            self._sent_events[ip] = now
            return True

    def get_samples_for_ip(self, ip: str) -> list[Sample]:
        with self._lock:
            return list(self._samples.get(ip, []))

    @staticmethod
    def is_web_scanner(ctx: ContextObject) -> bool:
        method = ctx.method
        if method is not None and method.upper() in _WEB_SCAN_METHODS:
            return True
        route = ctx.route
        if route is not None and _is_scan_path(route):
            return True
        return _query_contains_dangerous_payload(ctx.query)

    def _track_sample(self, ip: str, method: str | None, url: str | None) -> None:
        stored = self._samples.get(ip)
        if stored is None:
            stored = []
            self._samples[ip] = stored
        if len(stored) >= self._max_samples_per_ip:
            return
        sample = Sample(method, url)
        if sample in stored:
            return
        stored.append(sample)


def _is_scan_path(path: str) -> bool:
    normalized = path.lower()
    for segment in normalized.split("/"):
        if not segment:
            continue
        if segment in _SCAN_PATH_SEGMENTS:
            return True
        dot = segment.rfind(".")
        if dot >= 0 and segment[dot + 1 :] in _SCAN_FILE_EXTENSIONS:
            return True
    return False


def _query_contains_dangerous_payload(query: Mapping[str, str] | None) -> bool:
    if not query:
        return False
    for value in query.values():
        if value is None or len(value) < 5 or len(value) > 1000:
            continue
        upper = value.upper()
        if any(keyword in upper for keyword in _DANGEROUS_QUERY_KEYWORDS):
            return True
    return False

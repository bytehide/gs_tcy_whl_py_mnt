"""Per-route hit counter keyed by ``"METHOD route"``.

Bounded to a maximum number of distinct routes; when full, the least-hit route is
evicted. Feeds per-route analytics in the heartbeat.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass

DEFAULT_MAX_SIZE = 1000


@dataclass
class RouteHit:
    method: str
    route: str
    hits: int = 0


class RouteStore:
    def __init__(self, max_size: int = DEFAULT_MAX_SIZE) -> None:
        self._max_size = max_size if max_size > 0 else DEFAULT_MAX_SIZE
        self._routes: dict[str, RouteHit] = {}
        self._lock = threading.Lock()

    def increment(self, method: str, route: str) -> None:
        if method is None or route is None:
            return
        key = _key(method, route)
        with self._lock:
            entry = self._routes.get(key)
            if entry is None:
                self._manage_size()
                entry = RouteHit(method, route)
                self._routes[key] = entry
            entry.hits += 1

    def get_hits(self, method: str, route: str) -> int:
        with self._lock:
            entry = self._routes.get(_key(method, route))
            return entry.hits if entry is not None else 0

    def size(self) -> int:
        with self._lock:
            return len(self._routes)

    def top_routes(self, n: int) -> list[RouteHit]:
        with self._lock:
            ordered = sorted(
                (RouteHit(e.method, e.route, e.hits) for e in self._routes.values()),
                key=lambda e: e.hits,
                reverse=True,
            )
        if n >= 0 and len(ordered) > n:
            return ordered[:n]
        return ordered

    def clear(self) -> None:
        with self._lock:
            self._routes.clear()

    def _manage_size(self) -> None:
        if len(self._routes) < self._max_size:
            return
        least_key = min(self._routes, key=lambda k: self._routes[k].hits, default=None)
        if least_key is not None:
            del self._routes[least_key]


def _key(method: str, route: str) -> str:
    return f"{method} {route}"

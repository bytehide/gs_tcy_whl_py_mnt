"""Request/route/attack-wave statistics."""

"""Thread-safe cloud request/incident counters feeding the heartbeat stats.

Tracks request totals (total/blocked/successful), incident totals (total/blocked and
per-module breakdown) and per-module execution/detection counts.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field

from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType


@dataclass(frozen=True)
class StatisticsSnapshot:
    requests_total: int
    requests_blocked: int
    requests_successful: int
    incidents_total: int
    incidents_blocked: int
    incidents_by_module: dict[ProtectionModuleType, int] = field(default_factory=dict)
    module_executions: dict[ProtectionModuleType, int] = field(default_factory=dict)
    module_detections: dict[ProtectionModuleType, int] = field(default_factory=dict)


class StatisticsStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._requests_total = 0
        self._requests_blocked = 0
        self._requests_successful = 0
        self._incidents_total = 0
        self._incidents_blocked = 0
        self._incidents_by_module: dict[ProtectionModuleType, int] = {}
        self._module_executions: dict[ProtectionModuleType, int] = {}
        self._module_detections: dict[ProtectionModuleType, int] = {}

    def record_request(self, blocked: bool) -> None:
        with self._lock:
            self._requests_total += 1
            if blocked:
                self._requests_blocked += 1
            else:
                self._requests_successful += 1

    def record_incident(self, module: ProtectionModuleType, blocked: bool) -> None:
        with self._lock:
            self._incidents_total += 1
            if blocked:
                self._incidents_blocked += 1
            if module is not None:
                self._incidents_by_module[module] = self._incidents_by_module.get(module, 0) + 1

    def record_module_execution(self, module: ProtectionModuleType) -> None:
        if module is None:
            return
        with self._lock:
            self._module_executions[module] = self._module_executions.get(module, 0) + 1

    def record_module_detection(self, module: ProtectionModuleType) -> None:
        if module is None:
            return
        with self._lock:
            self._module_detections[module] = self._module_detections.get(module, 0) + 1

    def snapshot(self) -> StatisticsSnapshot:
        with self._lock:
            return StatisticsSnapshot(
                requests_total=self._requests_total,
                requests_blocked=self._requests_blocked,
                requests_successful=self._requests_successful,
                incidents_total=self._incidents_total,
                incidents_blocked=self._incidents_blocked,
                incidents_by_module=dict(self._incidents_by_module),
                module_executions=dict(self._module_executions),
                module_detections=dict(self._module_detections),
            )

    def reset(self) -> None:
        with self._lock:
            self._requests_total = 0
            self._requests_blocked = 0
            self._requests_successful = 0
            self._incidents_total = 0
            self._incidents_blocked = 0
            self._incidents_by_module.clear()
            self._module_executions.clear()
            self._module_detections.clear()

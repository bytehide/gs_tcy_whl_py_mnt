"""IP/CIDR resolution and validation."""

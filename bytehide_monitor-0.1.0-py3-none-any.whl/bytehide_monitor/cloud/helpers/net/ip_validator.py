"""IP-literal validity check (IPv4/IPv6), no DNS resolution."""

from __future__ import annotations

import ipaddress


def is_ip(value: str | None) -> bool:
    if not value:
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

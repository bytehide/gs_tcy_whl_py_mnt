"""Resolves the real client IP behind reverse proxies.

Header precedence: ``X-Forwarded-For`` (first valid IP in the chain) ->
``CF-Connecting-IP`` -> ``X-Real-IP`` -> the raw remote address. Port suffixes on
forwarded IPv4 addresses are stripped. No DNS resolution.
"""

from __future__ import annotations

from collections.abc import Mapping

from bytehide_monitor.cloud.helpers.net.ip_validator import is_ip

_X_FORWARDED_FOR = "x-forwarded-for"
_CF_CONNECTING_IP = "cf-connecting-ip"
_X_REAL_IP = "x-real-ip"


def resolve(remote_address: str | None, headers: Mapping[str, str] | None) -> str | None:
    forwarded_for = _get_header(headers, _X_FORWARDED_FOR)
    if forwarded_for is not None:
        ip = _extract_from_forwarded_for(forwarded_for)
        if ip is not None:
            return ip

    cf_connecting = _get_header(headers, _CF_CONNECTING_IP)
    if cf_connecting is not None:
        ip = cf_connecting.strip() or None
        if ip is not None and is_ip(ip):
            return ip

    real_ip = _get_header(headers, _X_REAL_IP)
    if real_ip is not None:
        ip = real_ip.strip() or None
        if ip is not None and is_ip(ip):
            return ip

    return remote_address


def _extract_from_forwarded_for(header_value: str) -> str | None:
    for part in header_value.split(","):
        candidate = part.strip()
        if not candidate:
            continue
        first_colon = candidate.find(":")
        if first_colon > 0 and candidate.find(":", first_colon + 1) < 0:
            host = candidate[:first_colon]
            if is_ip(host):
                return host
        if is_ip(candidate):
            return candidate
    return None


def _get_header(headers: Mapping[str, str] | None, name: str) -> str | None:
    if not headers:
        return None
    for key, value in headers.items():
        if key is not None and key.lower() == name:
            if value is not None and value.strip():
                return value
    return None

"""Matches an IP against CIDR ranges or bare IPs (for firewall allow/block lists).

A bare IP (no ``/prefix``) is an exact match. Same-family matching only (IPv4 never
matches an IPv6 range). Invalid inputs never match.
"""

from __future__ import annotations

import ipaddress
from collections.abc import Iterable


def matches_any(ip: str | None, cidrs: Iterable[str] | None) -> bool:
    if not cidrs:
        return False
    try:
        address = ipaddress.ip_address(ip) if ip else None
    except ValueError:
        return False
    if address is None:
        return False
    return any(_matches(address, cidr) for cidr in cidrs)


def matches(ip: str | None, cidr: str) -> bool:
    try:
        address = ipaddress.ip_address(ip) if ip else None
    except ValueError:
        return False
    if address is None:
        return False
    return _matches(address, cidr)


def _matches(address, cidr: str | None) -> bool:
    if not cidr:
        return False
    entry = cidr.strip()
    if not entry:
        return False
    try:
        if "/" in entry:
            network = ipaddress.ip_network(entry, strict=False)
            return address.version == network.version and address in network
        return address == ipaddress.ip_address(entry)
    except ValueError:
        return False

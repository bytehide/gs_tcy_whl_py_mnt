"""Reflected-XSS analysis of HTTP responses (port of .NET XssDetectionMiddleware).

Checks whether any user input that is itself an XSS payload is reflected in the
response body. Reuses the inbound :class:`CrossSiteScriptingDetector` (same patterns
and order) so detection stays consistent. Only textual content types are analyzed.
"""

from __future__ import annotations

import uuid

from bytehide_monitor.cloud.collectors.cloud_engine import CloudEngine
from bytehide_monitor.cloud.context.context_object import ContextObject
from bytehide_monitor.cloud.detectors.cross_site_scripting import CrossSiteScriptingDetector
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core.action.action_type import ActionType
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_EXCLUDED_CONTENT_TYPES = (
    "image/", "video/", "audio/", "application/pdf", "application/octet-stream",
    "application/zip", "font/",
)
_DETECTOR = CrossSiteScriptingDetector()


def is_analyzable(content_type: str | None) -> bool:
    if not content_type:
        return False
    ctype = content_type.lower()
    return not any(excluded in ctype for excluded in _EXCLUDED_CONTENT_TYPES)


def scan(
    engine: CloudEngine,
    context: ContextObject | None,
    response_text: str | None,
    content_type: str | None,
    status_code: int = 200,
) -> BlockDecision | None:
    """Return a block decision when a reflected XSS payload is found, else ``None``."""
    if context is None or not response_text:
        return None
    if not (200 <= status_code < 300) or not is_analyzable(content_type):
        return None

    protection = (engine.protections or {}).get(ProtectionModuleType.CROSS_SITE_SCRIPTING.value)
    if protection is None or not protection.enabled:
        return None

    inputs = context.get_user_inputs()
    if not inputs:
        return None
    lower_body = response_text.lower()

    for value in inputs.values():
        if not value or len(value) < 2:
            continue
        if value.lower() not in lower_body:
            continue
        result = _DETECTOR.run(value, ())
        if not result.threat_detected:
            continue

        action = ActionType.from_value(protection.action, default=ActionType.LOG)
        block = action == ActionType.BLOCK
        engine.statistics.record_incident(ProtectionModuleType.CROSS_SITE_SCRIPTING, block)

        if not block:
            MonitorLogger.warning(
                "C003_THREAT_DETECTED", f"Reflected XSS detected in response (logged): {value[:100]}"
            )
        # A detection always yields a decision so the incident is reported; ``blocked``
        # gates whether the response is swapped for a 403 or passed through unchanged.
        reference_id = str(uuid.uuid4())
        return BlockDecision.detected(
            ProtectionModuleType.CROSS_SITE_SCRIPTING,
            result.description,
            result,
            reference_id,
            blocked=block,
            action=protection.action or "log",
        )
    return None

"""Shared threat taxonomy for the nine cloud detection modules.

Single source of truth mapping each :class:`ProtectionModuleType` to its public threat
code (``BHM-T00X``), human-readable attack type, OWASP-style category and documentation
URL. Reused by the RFC 7807 block-response builder and the standalone input validator so
codes, names and categories never drift between the blocking path and the validation API.
"""

from __future__ import annotations

from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

DOCS_BASE = "https://docs.bytehide.com/monitor/errors/"

CATEGORY_INJECTION = "injection"
CATEGORY_XSS = "xss"

DEFAULT_CODE = "BHM-T000"
DEFAULT_ATTACK_TYPE = "Security Threat"
DEFAULT_SLUG = "security-threat"

MODULE_CODES = {
    ProtectionModuleType.SQL_INJECTION: "BHM-T001",
    ProtectionModuleType.CROSS_SITE_SCRIPTING: "BHM-T002",
    ProtectionModuleType.PATH_TRAVERSAL: "BHM-T003",
    ProtectionModuleType.COMMAND_INJECTION: "BHM-T004",
    ProtectionModuleType.SERVER_SIDE_REQUEST_FORGERY: "BHM-T005",
    ProtectionModuleType.LDAP_INJECTION: "BHM-T006",
    ProtectionModuleType.XML_EXTERNAL_ENTITY: "BHM-T007",
    ProtectionModuleType.NO_SQL_INJECTION: "BHM-T008",
    ProtectionModuleType.LLM_PROMPT_INJECTION: "BHM-T009",
    ProtectionModuleType.TEMPLATE_INJECTION: "BHM-T010",
    ProtectionModuleType.UNSAFE_DESERIALIZATION: "BHM-T011",
    ProtectionModuleType.OPEN_REDIRECT: "BHM-T012",
    ProtectionModuleType.HTTP_RESPONSE_SPLITTING: "BHM-T013",
}
MODULE_NAMES = {
    ProtectionModuleType.SQL_INJECTION: "SQL Injection",
    ProtectionModuleType.CROSS_SITE_SCRIPTING: "XSS",
    ProtectionModuleType.PATH_TRAVERSAL: "Path Traversal",
    ProtectionModuleType.COMMAND_INJECTION: "Command Injection",
    ProtectionModuleType.SERVER_SIDE_REQUEST_FORGERY: "SSRF",
    ProtectionModuleType.LDAP_INJECTION: "LDAP Injection",
    ProtectionModuleType.XML_EXTERNAL_ENTITY: "XXE",
    ProtectionModuleType.NO_SQL_INJECTION: "NoSQL Injection",
    ProtectionModuleType.LLM_PROMPT_INJECTION: "LLM Prompt Injection",
    ProtectionModuleType.TEMPLATE_INJECTION: "Template Injection (SSTI)",
    ProtectionModuleType.UNSAFE_DESERIALIZATION: "Unsafe Deserialization",
    ProtectionModuleType.OPEN_REDIRECT: "Open Redirect",
    ProtectionModuleType.HTTP_RESPONSE_SPLITTING: "HTTP Response Splitting",
}
TYPE_SLUGS = {
    "BHM-T001": "sql-injection", "BHM-T002": "xss", "BHM-T003": "path-traversal",
    "BHM-T004": "command-injection", "BHM-T005": "ssrf", "BHM-T006": "ldap-injection",
    "BHM-T007": "xxe", "BHM-T008": "nosql-injection", "BHM-T009": "llm-prompt-injection",
    "BHM-T010": "template-injection", "BHM-T011": "unsafe-deserialization",
    "BHM-T012": "open-redirect", "BHM-T013": "http-response-splitting",
    "BHM-F001": "ip-blocked", "BHM-F002": "geo-blocked", "BHM-F003": "user-agent-blocked",
    "BHM-F004": "session-blocked", "BHM-F005": "user-blocked", "BHM-R001": "rate-limit",
    "BHM-A001": "ip-changed", "BHM-A002": "user-agent-changed",
}


def code_for_module(module: ProtectionModuleType | None) -> str:
    if module is None:
        return DEFAULT_CODE
    return MODULE_CODES.get(module, DEFAULT_CODE)


def attack_type_for_module(module: ProtectionModuleType | None) -> str:
    if module is None:
        return DEFAULT_ATTACK_TYPE
    return MODULE_NAMES.get(module, DEFAULT_ATTACK_TYPE)


def category_for_module(module: ProtectionModuleType | None) -> str:
    """Category for a detection module: ``xss`` for XSS, ``injection`` for the rest."""
    if module == ProtectionModuleType.CROSS_SITE_SCRIPTING:
        return CATEGORY_XSS
    return CATEGORY_INJECTION


def type_url(code: str) -> str:
    return DOCS_BASE + TYPE_SLUGS.get(code, DEFAULT_SLUG)

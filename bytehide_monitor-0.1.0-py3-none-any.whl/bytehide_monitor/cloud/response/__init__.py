"""RFC 7807 block responses."""

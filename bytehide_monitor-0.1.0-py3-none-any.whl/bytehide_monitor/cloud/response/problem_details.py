"""Immutable RFC 7807 ``application/problem+json`` block response.

Pure data object: the source adapter writes the status, the serialized body
(:meth:`to_json`) and the ``application/problem+json`` content type onto the real
HTTP response. Field names serialize to camelCase to match the .NET output exactly
(distinct from the snake_case backend wire format). Built by ``BlockResponseBuilder``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class ThreatInfo:
    code: str | None = None
    category: str | None = None
    attack_type: str | None = None
    confidence: float | None = None
    payload: str | None = None
    source: str | None = None
    reference: str | None = None

    def to_dict(self) -> dict:
        raw = {
            "code": self.code,
            "category": self.category,
            "attackType": self.attack_type,
            "confidence": self.confidence,
            "payload": self.payload,
            "source": self.source,
            "reference": self.reference,
        }
        return {key: value for key, value in raw.items() if value is not None}


@dataclass(frozen=True)
class ProblemDetails:
    status: int
    type: str | None = None
    title: str | None = None
    detail: str | None = None
    instance: str | None = None
    message: str | None = None
    info: str | None = None
    reference: str | None = None
    threat_info: ThreatInfo | None = None

    CONTENT_TYPE = "application/problem+json"

    def to_dict(self) -> dict:
        raw = {
            "type": self.type,
            "title": self.title,
            "status": self.status,
            "detail": self.detail,
            "instance": self.instance,
            "message": self.message,
            "info": self.info,
            "reference": self.reference,
            "threatInfo": self.threat_info.to_dict() if self.threat_info is not None else None,
        }
        return {key: value for key, value in raw.items() if value is not None}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), ensure_ascii=False)

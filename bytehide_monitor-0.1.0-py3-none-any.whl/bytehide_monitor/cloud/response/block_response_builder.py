"""Builds an immutable :class:`ProblemDetails` from a :class:`BlockDecision`.

1:1 port of the .NET ``BlockResponse.Create`` / ``BlockRequestAction`` logic: threat
codes (T/F/R/A), categories, titles, type URLs, the ``BHM-XXXXXXXX`` reference id and
payload truncation all match the .NET output. Production mode emits a generic message
plus the reference id; debug mode emits the full problem document with threat detail.
"""

from __future__ import annotations

import uuid

from bytehide_monitor.cloud.response import threat_taxonomy
from bytehide_monitor.cloud.response.problem_details import ProblemDetails, ThreatInfo
from bytehide_monitor.cloud.scanner.block_decision import STATUS_TOO_MANY_REQUESTS, BlockDecision
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType

_MAX_PAYLOAD_LENGTH = 100
_INFO_TEXT = "This application is protected by ByteHide Monitor. Learn more at https://bytehide.com"

_CATEGORY_INJECTION = threat_taxonomy.CATEGORY_INJECTION
_CATEGORY_XSS = threat_taxonomy.CATEGORY_XSS
_CATEGORY_FIREWALL = "firewall"
_CATEGORY_RATE_LIMIT = "ratelimit"
_CATEGORY_ANOMALY = "anomaly"
_CATEGORY_SECURITY = "security"


def build(decision: BlockDecision, instance: str | None, debug_responses: bool) -> ProblemDetails:
    if decision is None:
        raise ValueError("decision must not be None")

    reference_id = generate_reference_id()
    category = _resolve_category(decision)
    status = decision.http_status

    if not debug_responses:
        return _production_response(reference_id, category, status)

    code = _resolve_code(decision)
    attack_type = _resolve_attack_type(decision, category)
    result = decision.result
    confidence = result.confidence if result is not None else None
    payload = _truncate_payload(result.description) if result is not None else None

    threat_info = ThreatInfo(
        code=code,
        category=category,
        attack_type=attack_type,
        confidence=confidence,
        payload=payload,
        source=None,
        reference=reference_id,
    )
    return ProblemDetails(
        status=status,
        type=_type_url(code),
        title=_title(category, attack_type),
        detail=decision.reason,
        instance=instance,
        threat_info=threat_info,
    )


def generate_reference_id() -> str:
    return "BHM-" + uuid.uuid4().hex[:8].upper()


def _production_response(reference_id: str, category: str, status: int) -> ProblemDetails:
    if category == _CATEGORY_FIREWALL:
        message = "Access denied by firewall rules."
    elif category == _CATEGORY_RATE_LIMIT:
        message = "Too many requests. Please try again later."
    else:
        message = "Request blocked."
    return ProblemDetails(
        status=status, message=message, info=_INFO_TEXT, reference=reference_id
    )


def _resolve_category(decision: BlockDecision) -> str:
    if decision.http_status == STATUS_TOO_MANY_REQUESTS:
        return _CATEGORY_RATE_LIMIT
    module = decision.module
    if module is None:
        return _anomaly_or_firewall(decision.reason)
    if module == ProtectionModuleType.CROSS_SITE_SCRIPTING:
        return _CATEGORY_XSS
    return _CATEGORY_INJECTION


def _anomaly_or_firewall(reason: str | None) -> str:
    if reason is not None:
        if reason.startswith("ip_changed") or reason.startswith("user_agent_changed"):
            return _CATEGORY_ANOMALY
        if (
            reason.startswith("ip_blocked")
            or reason.startswith("user_agent_blocked")
            or reason.startswith("user_blocked")
            or reason.startswith("session_blocked")
        ):
            return _CATEGORY_FIREWALL
    return _CATEGORY_SECURITY


def _resolve_code(decision: BlockDecision) -> str:
    if decision.http_status == STATUS_TOO_MANY_REQUESTS:
        return "BHM-R001"
    module = decision.module
    if module is not None:
        return threat_taxonomy.code_for_module(module)
    return _code_for_reason(decision.reason)


def _code_for_reason(reason: str | None) -> str:
    if reason is None:
        return "BHM-S001"
    # Order matters: the threat-intel (geo) prefix is more specific than "ip_blocked".
    prefixes = (
        ("ip_blocked_by_threat_intel", "BHM-F002"),
        ("ip_blocked", "BHM-F001"),
        ("user_agent_blocked", "BHM-F003"),
        ("session_blocked", "BHM-F004"),
        ("user_blocked", "BHM-F005"),
        ("ip_changed", "BHM-A001"),
        ("user_agent_changed", "BHM-A002"),
    )
    for prefix, code in prefixes:
        if reason.startswith(prefix):
            return code
    return "BHM-S001"


def _resolve_attack_type(decision: BlockDecision, category: str) -> str:
    module = decision.module
    if module is not None:
        return threat_taxonomy.attack_type_for_module(module)
    if category == _CATEGORY_FIREWALL:
        return "Firewall"
    if category == _CATEGORY_RATE_LIMIT:
        return "Rate Limit"
    if category == _CATEGORY_ANOMALY:
        return "Session Anomaly"
    return "Security Threat"


def _title(category: str, attack_type: str) -> str:
    if category == _CATEGORY_INJECTION:
        return f"{attack_type} Detected"
    if category == _CATEGORY_XSS:
        return "XSS Attack Detected"
    if category == _CATEGORY_FIREWALL:
        return "Access Denied"
    if category == _CATEGORY_RATE_LIMIT:
        return "Rate Limit Exceeded"
    if category == _CATEGORY_ANOMALY:
        return "Anomaly Detected"
    return "Security Threat Detected"


def _type_url(code: str) -> str:
    return threat_taxonomy.type_url(code)


def _truncate_payload(payload: str | None) -> str | None:
    if not payload:
        return None
    if len(payload) <= _MAX_PAYLOAD_LENGTH:
        return payload
    return payload[:_MAX_PAYLOAD_LENGTH] + "..."

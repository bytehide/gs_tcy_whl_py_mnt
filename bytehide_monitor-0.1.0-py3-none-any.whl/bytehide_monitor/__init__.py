"""ByteHide Monitor - RASP firewall for Python web/API applications.

Public API::

    import bytehide_monitor

    # One call protects the whole app: it reads monitor-config.json / env vars, applies the "cloud" preset by
    # default, starts background reporting, AND auto-instruments the web framework in use (Flask, FastAPI/
    # Starlette, Django) - no manual middleware wiring. Call it at the top of the entrypoint, before the app
    # is constructed.
    runtime = bytehide_monitor.protect(token="your-project-token")

    # Or fluent configuration:
    runtime = bytehide_monitor.configure(lambda c: (
        c.use_token("your-project-token").preset("cloud").debug_responses(False)
    ))

To wire a framework by hand instead, pass ``auto_integrate=False`` and use the matching adapter:

- Flask:    ``from bytehide_monitor.sources.flask import ByteHideMonitor; ByteHideMonitor(app, runtime)``
- FastAPI:  ``from bytehide_monitor.sources.asgi import ByteHideMonitorASGI; app.add_middleware(ByteHideMonitorASGI, runtime=runtime)``
- Django:   add ``"bytehide_monitor.sources.django.ByteHideMonitorMiddleware"`` to ``MIDDLEWARE``
- WSGI:     ``from bytehide_monitor.sources.wsgi import ByteHideMonitorWSGI; app = ByteHideMonitorWSGI(app, runtime)``
"""

from __future__ import annotations

import atexit
import json
from collections.abc import Callable

from bytehide_monitor.cloud.config import cloud_config_loader
from bytehide_monitor.cloud.config.cloud_monitor_config import CloudMonitorConfig
from bytehide_monitor.cloud.config.protection_presets import CLOUD as CLOUD_PRESET
from bytehide_monitor.cloud.runtime import CloudRuntime, get_active, set_active
from bytehide_monitor.core.action import action_registry
from bytehide_monitor.core.action.action_type import ActionType
from bytehide_monitor.core.action.threat_context import ThreatContext
from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.protection.attack_context import AttackContext
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType
from bytehide_monitor.version import LIBRARY_NAME, VERSION

ActionHandler = Callable[[ThreatContext], None]

__all__ = [
    "VERSION",
    "LIBRARY_NAME",
    "ActionType",
    "ProtectionModuleType",
    "ThreatContext",
    "AttackContext",
    "CloudRuntime",
    "MonitorBuilder",
    "protect",
    "configure",
    "register_custom_action",
    "shutdown",
    "get_active",
    "ai_route_target",
]


def ai_route_target() -> "tuple[str | None, str | None]":
    """Resolves (routeUrl, key) of the project's in-process AI gateway route for explicit validators.

    Priority: explicit env (BYTEHIDE_AI_GATEWAY_URL/KEY) -> bootstrap from monitor-api using BYTEHIDE_MONITOR_TOKEN.
    Returns (None, None) when AI is not configured. Lets an app validate chat I/O with only the project token set."""
    from bytehide_monitor.sinks.ai import ai_route_target as _impl

    return _impl()


def register_custom_action(name: str, handler: ActionHandler) -> None:
    """Register a named custom action handler.

    Reference it from a module's config with ``action: "custom"`` and
    ``customActionName: "<name>"``. The handler receives a :class:`ThreatContext` and
    sets ``should_block = True`` to block the request.
    """
    action_registry.instance().register_custom_action(name, handler)


class MonitorBuilder:
    """Fluent builder over a :class:`CloudMonitorConfig` for :func:`configure`."""

    def __init__(self) -> None:
        self._config = CloudMonitorConfig()

    def use_token(self, token: str) -> MonitorBuilder:
        self._config.project_token = token
        return self

    def preset(self, preset: str) -> MonitorBuilder:
        self._config.preset = preset
        return self

    def debug_responses(self, enabled: bool = True) -> MonitorBuilder:
        self._config.debug_responses = enabled
        return self

    def enabled(self, enabled: bool = True) -> MonitorBuilder:
        self._config.enabled = enabled
        return self

    def register_custom_action(self, name: str, handler: ActionHandler) -> MonitorBuilder:
        register_custom_action(name, handler)
        return self

    def name(self, name: str) -> MonitorBuilder:
        self._config.name = name
        return self

    def config(self) -> CloudMonitorConfig:
        return self._config


def protect(
    token: str | None = None,
    *,
    config_path: str | None = None,
    debug: bool | None = None,
    install_sinks: bool = True,
    start_reporting: bool = True,
    auto_integrate: bool = True,
) -> CloudRuntime:
    """Initialize the firewall: resolve config, build the runtime, start reporting, auto-instrument the framework.

    Resolution order: explicit arguments > environment variables > config file >
    ``cloud`` preset default. With ``auto_integrate`` (default), the web framework in use
    (Flask, FastAPI/Starlette, Django) is patched automatically - no manual middleware
    wiring. Returns the active :class:`CloudRuntime`.
    """
    config = _load_config(config_path)
    if token is not None:
        config.project_token = token
    if debug is not None:
        config.debug_responses = debug
    _validate_license(config)
    _apply_defaults(config)
    return _build_runtime(config, install_sinks=install_sinks, start_reporting=start_reporting, auto_integrate=auto_integrate)


def configure(
    fn: Callable[[MonitorBuilder], object],
    *,
    install_sinks: bool = True,
    start_reporting: bool = True,
    auto_integrate: bool = True,
) -> CloudRuntime:
    """Fluent initialization: ``fn`` receives a :class:`MonitorBuilder` to configure."""
    builder = MonitorBuilder()
    fn(builder)
    config = cloud_config_loader.apply_environment_overrides(builder.config())
    _validate_license(config)
    _apply_defaults(config)
    return _build_runtime(config, install_sinks=install_sinks, start_reporting=start_reporting, auto_integrate=auto_integrate)


def _validate_license(config: CloudMonitorConfig) -> None:
    """Validate the signed license from ``BYTEHIDE_LICENSE`` when present.

    A valid license supplies the project token and tier; an invalid or expired license
    disables protection (fail-closed). When no license is configured, the project token
    from config/env is used directly (the standard cloud flow).
    """
    from bytehide_monitor.core.license import license_validator
    from bytehide_monitor.core.license.license_exception import LicenseException
    from bytehide_monitor.core.logging.logger import MonitorLogger

    try:
        license_data = license_validator.validate_from_env()
    except LicenseException as exc:
        MonitorLogger.critical("C008_LICENSE_REVOKED", f"License validation failed: {exc}")
        config.enabled = False
        return
    if license_data is not None:
        config.project_token = license_data.token
        MonitorLogger.info("I006_LICENSE_OK", f"License validated (tier: {license_data.tier})")


def shutdown() -> None:
    """Shut down the active runtime (flush reporting, stop background threads)."""
    runtime = get_active()
    if runtime is not None:
        runtime.shutdown()


def _load_config(config_path: str | None) -> CloudMonitorConfig:
    if config_path is None:
        return cloud_config_loader.load()
    try:
        with open(config_path, encoding="utf-8") as handle:
            data = json.load(handle)
        config = CloudMonitorConfig.from_dict(data) if isinstance(data, dict) else CloudMonitorConfig()
    except (OSError, json.JSONDecodeError):
        config = CloudMonitorConfig()
    return cloud_config_loader.apply_environment_overrides(config)


def _apply_defaults(config: CloudMonitorConfig) -> None:
    # Out-of-the-box, enable the full cloud detector set when nothing else is configured.
    if config.preset is None and not config.protections:
        config.preset = CLOUD_PRESET


def _build_runtime(
    config: CloudMonitorConfig, *, install_sinks: bool, start_reporting: bool, auto_integrate: bool = True
) -> CloudRuntime:
    runtime = CloudRuntime(config)
    set_active(runtime)

    if install_sinks:
        _try_install_sinks(runtime)

    if auto_integrate:
        _try_auto_integrate()

    offline = env_vars.get_bool(env_vars.OFFLINE, False)
    if start_reporting and config.enabled and config.project_token and not offline:
        runtime.start_reporting()

    atexit.register(runtime.shutdown)
    return runtime


def _try_install_sinks(runtime: CloudRuntime) -> None:
    try:
        from bytehide_monitor.sinks import install as install_sinks_fn
    except ImportError:
        return
    try:
        install_sinks_fn(runtime)
    except Exception:  # noqa: BLE001 - sink installation is best-effort
        pass


def _try_auto_integrate() -> None:
    """Arm the framework import hooks so the app's web framework is instrumented without manual wiring."""
    try:
        from bytehide_monitor.sources import auto
    except ImportError:
        return
    try:
        auto.install()
    except Exception:  # noqa: BLE001 - auto-integration is best-effort; manual wiring remains available
        pass

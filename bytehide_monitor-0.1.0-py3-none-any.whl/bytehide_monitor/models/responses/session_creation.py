"""Session creation response (desktop/mobile only; kept for wire parity)."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class SessionCreationResponse(JsonModel):
    session_id: str | None = None
    created_at: int | None = None  # Unix ms

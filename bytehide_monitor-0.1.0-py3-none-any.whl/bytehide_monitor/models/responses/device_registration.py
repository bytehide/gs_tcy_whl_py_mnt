"""Device registration response."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.responses.configuration import RemoteConfiguration


@dataclass
class DeviceRegistrationResponse(JsonModel):
    machine_id: str | None = None
    config_updated_at: int | None = None  # Unix ms
    blocked: bool | None = None
    reason: str | None = None
    blocked_at: int | None = None  # Unix ms
    config: RemoteConfiguration | None = None

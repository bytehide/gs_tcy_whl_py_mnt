"""Heartbeat response (server time, config sync, emergency actions, commands)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.firewall_configuration import FirewallConfiguration
from bytehide_monitor.models.responses.configuration import RemoteConfiguration


@dataclass
class EmergencyActions(JsonModel):
    panic_mode: bool | None = None
    clear_memory: bool | None = None
    delete_files: bool | None = None


@dataclass
class Command(JsonModel):
    id: str | None = None
    type: str | None = None  # update_config, block_device, restart_module
    params: dict[str, Any] | None = None


@dataclass
class HeartbeatResponse(JsonModel):
    server_time: int | None = None  # Unix ms
    config_updated_at: int | None = None  # Unix ms
    next_heartbeat_in_ms: int | None = None
    blocked: bool | None = None
    blocked_reason: str | None = None
    actions: EmergencyActions | None = None
    firewall: FirewallConfiguration | None = None
    config: RemoteConfiguration | None = None
    commands: list[Command] | None = None

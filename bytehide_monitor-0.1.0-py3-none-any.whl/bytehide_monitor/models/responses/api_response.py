"""Generic API response envelope: ``{success, message, data, error}``.

``data`` is kept as the raw decoded value; callers use :meth:`data_as` to project
it into a concrete response model when the envelope reports success.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TypeVar

from bytehide_monitor.core.helpers.json import JsonModel

M = TypeVar("M", bound=JsonModel)


@dataclass
class ApiError(JsonModel):
    code: str | None = None
    details: str | None = None


@dataclass
class ApiResponse(JsonModel):
    success: bool | None = None
    message: str | None = None
    data: Any | None = None
    error: ApiError | None = None

    @property
    def is_success(self) -> bool:
        return self.success is True

    @property
    def is_error(self) -> bool:
        return self.success is False

    def data_as(self, model_type: type[M]) -> M | None:
        """Decode the ``data`` field into ``model_type`` (or ``None`` when absent)."""
        if isinstance(self.data, dict):
            return model_type.from_dict(self.data)
        return None

    @classmethod
    def ok(cls, message: str, data: Any) -> ApiResponse:
        return cls(success=True, message=message, data=data, error=None)

    @classmethod
    def fail(cls, message: str, code: str, details: str | None = None) -> ApiResponse:
        return cls(success=False, message=message, data=None, error=ApiError(code, details))

"""Remote configuration block and the GET /config response.

``RemoteConfiguration`` is the shared config payload embedded in device
registration, heartbeat and configuration responses (Java
``DeviceRegistrationResponse.Configuration``).
"""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.firewall_configuration import FirewallConfiguration
from bytehide_monitor.models.module_configuration import ModuleConfiguration


@dataclass
class RemoteConfiguration(JsonModel):
    block_mode: bool | None = None
    heartbeat_interval_ms: int | None = None
    firewall: FirewallConfiguration | None = None
    modules: list[ModuleConfiguration] | None = None


@dataclass
class ConfigurationResponse(JsonModel):
    config_updated_at: int | None = None  # Unix ms
    config: RemoteConfiguration | None = None

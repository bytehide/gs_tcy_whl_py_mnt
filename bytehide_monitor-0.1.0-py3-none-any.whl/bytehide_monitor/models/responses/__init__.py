"""API response DTOs."""

"""Backend wire DTOs (snake_case, omit-null)."""

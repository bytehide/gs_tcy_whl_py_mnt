"""Device information model (schema version 2).

Full wire schema is preserved for backend compatibility; server/web apps populate
only the relevant subset (name, os, runtime, network) and leave the rest ``None``
so they are omitted from the payload.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class Device(JsonModel):
    schema_version: int | None = 2

    # Core identity
    name: str | None = None
    model: str | None = None
    brand: str | None = None
    manufacturer: str | None = None

    # Operating system
    os_name: str | None = None
    os: str | None = None
    version: str | None = None
    os_build: str | None = None
    kernel_version: str | None = None
    architecture: str | None = None
    is_64bit_process: bool | None = None

    # Hardware
    processor_count: int | None = None
    processor_name: str | None = None
    total_memory: int | None = None
    available_memory: int | None = None
    total_storage: int | None = None
    available_storage: int | None = None
    screen_resolution: str | None = None
    screen_density: float | None = None
    battery_level: float | None = None
    is_charging: bool | None = None

    # Network
    ip_address: str | None = None
    local_ip_address: str | None = None
    mac: str | None = None  # deprecated, use mac_addresses
    mac_addresses: list[str] | None = None
    connection_type: str | None = None
    network_operator: str | None = None
    is_vpn_active: bool | None = None
    is_proxy_active: bool | None = None

    # Software environment
    runtime_version: str | None = None
    runtime_framework: str | None = None
    locale: str | None = None
    language: str | None = None
    timezone: str | None = None
    timezone_offset: int | None = None
    timezone_iana: str | None = None
    uptime: int | None = None
    boot_time: int | None = None

    # Security indicators
    is_jailbroken: bool | None = None
    is_developer_mode: bool | None = None
    is_emulator: bool | None = None
    is_debuggable: bool | None = None
    is_usb_debugging_enabled: bool | None = None
    is_mock_location_enabled: bool | None = None

    # Android-specific
    android_id: str | None = None
    build_fingerprint: str | None = None
    has_xposed_framework: bool | None = None
    has_magisk_hide: bool | None = None

    # iOS-specific
    identifier_for_vendor: str | None = None
    model_identifier: str | None = None
    is_simulator: bool | None = None
    is_testflight: bool | None = None

    # Desktop-specific
    motherboard_serial: str | None = None
    bios_version: str | None = None
    system_manufacturer: str | None = None
    system_product_name: str | None = None

    # Application context
    app_version: str | None = None
    app_build_number: str | None = None
    bundle_id: str | None = None
    app_install_time: int | None = None
    is_first_run: bool | None = field(default=None)

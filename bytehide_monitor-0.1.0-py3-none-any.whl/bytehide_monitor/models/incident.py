"""Incident/threat model."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class Incident(JsonModel):
    incident_id: str | None = None
    module_type: str | None = None
    level: str | None = None  # low, medium, high, critical
    blocked: bool | None = None
    action: str | None = None  # none, log, close, erase, block, custom
    payload: str | None = None
    metadata: dict[str, Any] | None = None
    stack: list[str] | None = None

"""Application metadata model (sent in device registration)."""

from __future__ import annotations

from dataclasses import dataclass, field

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class ApplicationRuntime(JsonModel):
    platform: str | None = None  # web, api
    framework: str | None = None  # flask, django, fastapi, asgi, wsgi
    version: str | None = None


@dataclass
class Dependency(JsonModel):
    name: str | None = None
    version: str | None = None
    type: str | None = None  # pypi, package, framework, native


@dataclass
class BuildInfo(JsonModel):
    configuration: str | None = None  # Debug, Release
    build_date: str | None = None  # ISO 8601
    commit_hash: str | None = None


@dataclass
class Application(JsonModel):
    name: str | None = None
    version: str | None = None
    type: str | None = None  # web, api, desktop, mobile
    language: str | None = None  # Python
    runtime: ApplicationRuntime | None = None
    dependencies: list[Dependency] | None = None
    build_info: BuildInfo | None = field(default=None)

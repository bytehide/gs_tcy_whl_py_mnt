"""Module configuration model (received from the backend)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, TypeVar

from bytehide_monitor.core.helpers.json import JsonModel

T = TypeVar("T")


@dataclass
class ModuleConfiguration(JsonModel):
    type: str | None = None
    enabled: bool | None = None
    interval_ms: int | None = None
    action: str | None = None  # none, log, close, erase, block, custom_action_name
    config: dict[str, Any] | None = field(default_factory=dict)

    def get_parameter(self, key: str, default: T) -> T:
        if not self.config or key not in self.config:
            return default
        value = self.config[key]
        return value if isinstance(value, type(default)) or default is None else default

    def set_parameter(self, key: str, value: Any) -> None:
        if self.config is None:
            self.config = {}
        self.config[key] = value

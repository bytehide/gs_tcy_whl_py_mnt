"""Agent identity model (library version reported to the backend)."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class Agent(JsonModel):
    version: str | None = None
    library: str | None = None

"""Firewall configuration model (received from the backend)."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class IpRange(JsonModel):
    start: str | None = None
    end: str | None = None
    description: str | None = None


@dataclass
class FirewallConfiguration(JsonModel):
    blocked_devices: list[str] | None = None
    blocked_ips: list[IpRange] | None = None
    allowed_ips: list[str] | None = None
    blocked_user_agents: list[str] | None = None
    blocked_users: list[str] | None = None
    blocked_sessions: list[str] | None = None
    blocked_countries: list[str] | None = None  # cloud only
    blocked_threat_actors: list[str] | None = None  # cloud only

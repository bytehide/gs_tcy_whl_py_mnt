"""Incident report request. Cloud reports carry a full ``session`` block."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.incident import Incident


@dataclass
class IncidentContext(JsonModel):
    platform: str | None = None  # web, api, desktop, mobile
    ip: str | None = None
    user_machine: str | None = None


@dataclass
class IncidentSession(JsonModel):
    session_id: str | None = None
    ip: str | None = None
    user_agent: str | None = None
    user_id: str | None = None
    user_name: str | None = None
    started_at: int | None = None  # Unix ms
    last_activity_at: int | None = None  # Unix ms
    total_requests: int | None = None
    method: str | None = None
    url: str | None = None
    route: str | None = None


@dataclass
class IncidentReportRequest(JsonModel):
    type: str | None = "detected_incident"
    time: int | None = None  # Unix ms
    session_id: str | None = None  # desktop/mobile only
    session: IncidentSession | None = None  # cloud only
    machine_id: str | None = None
    incident: Incident | None = None
    context: IncidentContext | None = None

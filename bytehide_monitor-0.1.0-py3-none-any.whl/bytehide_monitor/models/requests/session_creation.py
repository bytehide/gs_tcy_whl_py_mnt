"""Session creation request (desktop/mobile only; kept for wire parity)."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class SessionCreationRequest(JsonModel):
    session_id: str | None = None
    machine_id: str | None = None
    start_at: int | None = None  # Unix ms
    ip: str | None = None
    timezone: str | None = None
    platform: str | None = None  # desktop, mobile
    user_machine: str | None = None
    app_version: str | None = None

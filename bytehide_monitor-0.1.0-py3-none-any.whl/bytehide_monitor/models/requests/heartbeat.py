"""Heartbeat request and its nested statistics/session DTOs.

Cloud (web/API) heartbeats carry ``stats.requests`` and the full ``sessions`` array
with per-session ``routes`` (1:1 with the .NET ``BuildCloudHeartbeat`` wire shape).
"""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.agent import Agent


@dataclass
class SessionStats(JsonModel):
    total: int | None = None
    active: int | None = None


@dataclass
class RequestStats(JsonModel):
    total: int | None = None
    blocked: int | None = None
    successful: int | None = None


@dataclass
class IncidentStats(JsonModel):
    total: int | None = None
    blocked: int | None = None
    by_module: dict[str, int] | None = None


@dataclass
class ModuleStats(JsonModel):
    type: str | None = None
    executions: int | None = None
    detections: int | None = None
    compressed_timings: str | None = None  # "min/avg/max/p95" in ms


@dataclass
class RouteHit(JsonModel):
    method: str | None = None
    route: str | None = None
    hits: int | None = None


@dataclass
class HeartbeatStats(JsonModel):
    started_at: int | None = None  # Unix ms
    ended_at: int | None = None  # Unix ms
    sessions: SessionStats | None = None
    requests: RequestStats | None = None  # cloud only
    incidents: IncidentStats | None = None
    modules: list[ModuleStats] | None = None


@dataclass
class CloudSessionDetail(JsonModel):
    session_id: str | None = None
    ip: str | None = None
    user_agent: str | None = None
    user_id: str | None = None
    user_name: str | None = None
    started_at: int | None = None  # Unix ms
    last_activity_at: int | None = None  # Unix ms
    total_requests: int | None = None
    blocked: bool | None = None
    block_reason: str | None = None
    routes: list[RouteHit] | None = None


@dataclass
class HeartbeatRequest(JsonModel):
    machine_id: str | None = None
    time: int | None = None  # Unix ms
    type: str | None = "heartbeat"
    stats: HeartbeatStats | None = None
    sessions: list[CloudSessionDetail] | None = None  # cloud only
    agent: Agent | None = None

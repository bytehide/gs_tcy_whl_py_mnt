"""Device registration request."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel
from bytehide_monitor.models.agent import Agent
from bytehide_monitor.models.application import Application
from bytehide_monitor.models.device import Device


@dataclass
class DeviceRegistrationRequest(JsonModel):
    machine_id: str | None = None
    device: Device | None = None
    application: Application | None = None
    agent: Agent | None = None

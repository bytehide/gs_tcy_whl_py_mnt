"""Session end request (desktop/mobile only; kept for wire parity)."""

from __future__ import annotations

from dataclasses import dataclass

from bytehide_monitor.core.helpers.json import JsonModel


@dataclass
class SessionEndRequest(JsonModel):
    ended_at: int | None = None  # Unix ms
    duration_ms: int | None = None
    reason: str | None = None  # normal, crash, user_logout, blocked

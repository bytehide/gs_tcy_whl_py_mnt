"""Taint SOURCE: wraps the request parameter accessors of the supported web frameworks so the values
an application reads from the request come back as :class:`~bytehide_monitor.core.taint.TaintedStr`.

This is what makes taint propagate into the app's own code (and, when it survives, into the URL a
sink receives). Patching is best-effort and fail-open: a framework that is not installed is skipped,
and any error while wrapping a single accessor is swallowed (the app keeps working untainted).

Covered accessors (the ones apps use to read user input):
  * Django   - ``QueryDict.__getitem__`` / ``.get`` / ``.getlist`` (request.GET/POST, DRF query_params)
  * Werkzeug - ``MultiDict.__getitem__`` / ``.get`` / ``.getlist`` (Flask request.args/form/values)
  * Starlette- ``QueryParams.__getitem__`` / ``.get`` and ``FormData.__getitem__`` / ``.get`` (FastAPI)
"""
from __future__ import annotations

from typing import Any

from bytehide_monitor.core import taint
from bytehide_monitor.core.logging.logger import MonitorLogger


def _taint_scalar(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrap a single returned value (``get`` / ``__getitem__``) as tainted when it is a ``str``."""
    return taint.taint(wrapped(*args, **kwargs))


def _taint_list(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrap each ``str`` in a returned list (``getlist``) as tainted."""
    result = wrapped(*args, **kwargs)
    if isinstance(result, list):
        return [taint.taint(item) for item in result]
    return result


def _patch(module: Any, dotted: str, wrapper: Any) -> bool:
    import wrapt

    try:
        wrapt.wrap_function_wrapper(module, dotted, wrapper)
        return True
    except Exception:  # noqa: BLE001 - method absent in this version / already wrapped; skip
        return False


def _install_django(module: Any) -> None:
    patched = any(
        [
            _patch(module, "QueryDict.__getitem__", _taint_scalar),
            _patch(module, "QueryDict.get", _taint_scalar),
            _patch(module, "QueryDict.getlist", _taint_list),
        ]
    )
    if patched:
        taint.set_active()
        MonitorLogger.info("TAINT_DJANGO", "Taint source installed (Django QueryDict)")


def _install_werkzeug(module: Any) -> None:
    patched = any(
        [
            _patch(module, "MultiDict.__getitem__", _taint_scalar),
            _patch(module, "MultiDict.get", _taint_scalar),
            _patch(module, "MultiDict.getlist", _taint_list),
        ]
    )
    if patched:
        taint.set_active()
        MonitorLogger.info("TAINT_WERKZEUG", "Taint source installed (Werkzeug MultiDict)")


def _install_starlette(module: Any) -> None:
    patched = any(
        [
            _patch(module, "QueryParams.__getitem__", _taint_scalar),
            _patch(module, "QueryParams.get", _taint_scalar),
            _patch(module, "FormData.__getitem__", _taint_scalar),
            _patch(module, "FormData.get", _taint_scalar),
        ]
    )
    if patched:
        taint.set_active()
        MonitorLogger.info("TAINT_STARLETTE", "Taint source installed (Starlette QueryParams/FormData)")


def install() -> None:
    """Registers post-import hooks so each framework is tainted the moment it is imported."""
    try:
        import wrapt
    except ImportError:
        return
    wrapt.register_post_import_hook(_install_django, "django.http.request")
    wrapt.register_post_import_hook(_install_werkzeug, "werkzeug.datastructures")
    wrapt.register_post_import_hook(_install_starlette, "starlette.datastructures")

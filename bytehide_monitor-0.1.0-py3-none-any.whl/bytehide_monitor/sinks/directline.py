"""Direct Line (Microsoft Copilot Studio / Bot Framework) HTTP guard — covers Copilot OUTSIDE Chainlit.

Copilot Studio is normally reached over the Direct Line REST API with raw ``requests`` (there is no SDK class to
hook). This sink intercepts ``requests.Session.send`` and, ONLY for the Direct Line host, guards:
  * INPUT  — the user prompt: a ``POST .../activities`` whose JSON body carries ``text`` (the message Activity).
             Mask -> rewrite the body text; block -> raise (the send fails). Other POSTs (start conversation) have
             no ``text`` and pass untouched.
  * OUTPUT — the bot reply: a ``GET .../activities`` whose JSON response carries ``activities[].text``.
             Mask/block -> rewrite the reply text before the app sees it.
Every non-Direct-Line request passes through untouched (no effect on the rest of the app / the SSRF sink).

NO overlap with the Chainlit guard: while a Chainlit turn is in progress, the chat-boundary guard owns the
validation and this HTTP guard DEFERS (``ai._HTTP_GUARD_SUPPRESSED``). So a Chainlit app is guarded once at the
boundary; a non-Chainlit app (plain script, a FastAPI service, ...) is guarded here. Default on; disable with
``BYTEHIDE_DIRECTLINE_GUARD=0``. Fail-open and best-effort throughout.
"""

from __future__ import annotations

import json
import os
from typing import Any
from urllib.parse import urlsplit

import wrapt

from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.protection.security_exception import SecurityException
from bytehide_monitor.sinks import ai as _ai

_REQUESTS_MODULE = "requests.sessions"
_DEFAULT_HOST = "directline.botframework.com"
_PATH_MARKER = "/v3/directline"
_WRAPPED: set = set()


def _enabled() -> bool:
    return os.environ.get("BYTEHIDE_DIRECTLINE_GUARD", "1").strip().lower() not in {"0", "false", "no", "off"}


def _hosts() -> set[str]:
    extra = os.environ.get("BYTEHIDE_DIRECTLINE_HOST", "").strip().lower()
    return {_DEFAULT_HOST, extra} if extra else {_DEFAULT_HOST}


def _is_directline(url: str) -> bool:
    try:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        return host in _hosts() or _PATH_MARKER in (parts.path or "").lower()
    except Exception:  # noqa: BLE001
        return False


def _load_json(raw: Any) -> Any:
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    if not isinstance(raw, str):
        return None
    try:
        return json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return None


def _guard_input(request: Any) -> None:
    """Guard the outgoing message Activity (POST .../activities). Mask rewrites the body; block raises."""
    data = _load_json(getattr(request, "body", None))
    if not isinstance(data, dict):
        return
    text = data.get("text")
    if not isinstance(text, str) or not text:
        return  # not a message activity (e.g. start conversation) -> nothing to guard
    action, value = _ai.guard_chat_text(text, "input")
    if action == "block":
        raise SecurityException(_ai.chat_block_decision(value, "directline.input"))
    if action == "mask" and value != text:
        data["text"] = value
        body = json.dumps(data).encode("utf-8")
        request.body = body
        try:
            request.headers["Content-Length"] = str(len(body))
        except Exception:  # noqa: BLE001 - headers may be immutable on exotic prepared requests
            pass


def _guard_output(response: Any) -> Any:
    """Guard the bot reply (GET .../activities). Mask/block rewrites activities[].text in the response body."""
    raw = getattr(response, "content", None)
    data = _load_json(raw)
    if not isinstance(data, dict):
        return response
    activities = data.get("activities")
    if not isinstance(activities, list):
        return response
    changed = False
    for activity in activities:
        if not isinstance(activity, dict):
            continue
        text = activity.get("text")
        if not isinstance(text, str) or not text:
            continue
        action, value = _ai.guard_chat_text(text, "output")
        if action in ("mask", "block") and value != text:
            activity["text"] = value
            changed = True
    if changed:
        try:
            response._content = json.dumps(data).encode("utf-8")  # noqa: SLF001 - requests caches the body here
        except Exception:  # noqa: BLE001 - leave the response untouched if it cannot be rewritten
            pass
    return response


def _send_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Wrap requests.Session.send: guard Direct Line traffic only; everything else passes straight through."""
    if not _enabled() or _ai._HTTP_GUARD_SUPPRESSED.get():
        return wrapped(*args, **kwargs)  # disabled, or a Chainlit turn already owns the guarding
    request = args[0] if args else kwargs.get("request")
    url = getattr(request, "url", None)
    if not isinstance(url, str) or not _is_directline(url):
        return wrapped(*args, **kwargs)  # not Direct Line -> do nothing
    method = (getattr(request, "method", "") or "").upper()
    if method == "POST":
        try:
            _guard_input(request)  # may raise SecurityException on a hard block
        except SecurityException:
            raise
        except Exception:  # noqa: BLE001 - guarding is best-effort; never break the send
            pass
        return wrapped(*args, **kwargs)
    response = wrapped(*args, **kwargs)
    if method == "GET":
        try:
            return _guard_output(response)
        except Exception:  # noqa: BLE001 - never break the response on a guard error
            return response
    return response


def install() -> None:
    """Arm the Direct Line HTTP guard (idempotent, fail-open). The hook fires if/when ``requests`` is imported."""
    def _hook(module: Any) -> None:
        session = getattr(module, "Session", None)
        if session is None:
            return
        key = (id(session), "send")
        if key in _WRAPPED:
            return
        try:
            wrapt.wrap_function_wrapper(session, "send", _send_wrapper)
            _WRAPPED.add(key)
        except Exception:  # noqa: BLE001 - requests variant without Session.send; skip
            return

    wrapt.register_post_import_hook(_hook, _REQUESTS_MODULE)
    MonitorLogger.info(
        "I_DIRECTLINE_GUARD",
        "Direct Line HTTP guard armed (Copilot Studio over requests) — defers to the Chainlit boundary guard",
    )

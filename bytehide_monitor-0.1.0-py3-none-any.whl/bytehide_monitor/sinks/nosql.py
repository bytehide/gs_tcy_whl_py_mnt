"""NoSQL-injection sink: instruments PyMongo / Motor collection operations (sync + async) and redis commands.

The query/filter (or aggregation pipeline) is serialized to JSON and handed to the NoSQL detector, which inspects
it against the request inputs (Mongo operators, JS in ``$where``, JSON structure manipulation, Cosmos SQL-like
patterns). Async drivers are wrapped synchronously: ``enforce`` runs before the returned coroutine is awaited.
"""

from __future__ import annotations

import json
from typing import Any

from bytehide_monitor.sinks._patcher import active_runtime, enforce

# Collection methods whose first positional argument is the query filter (sync PyMongo + async Motor/PyMongo).
_FILTER_METHODS = (
    "find",
    "find_one",
    "count_documents",
    "delete_one",
    "delete_many",
    "update_one",
    "update_many",
    "replace_one",
    "find_one_and_delete",
    "find_one_and_update",
    "find_one_and_replace",
)

# Collection modules to instrument: sync PyMongo + async PyMongo (4.9+) + Motor (asyncio).
_COLLECTION_TARGETS = (
    ("pymongo.collection", "Collection"),
    ("pymongo.asynchronous.collection", "AsyncCollection"),
    ("motor.motor_asyncio", "AsyncIOMotorCollection"),
)


def _serialize(value: Any) -> str | None:
    try:
        return json.dumps(value, default=str)
    except (TypeError, ValueError):
        return None


def _filter_wrapper(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        query = kwargs.get("filter", args[0] if args else None)
        if query is not None:
            text = _serialize(query)
            if text:
                enforce(runtime.nosql.report(text))
    return wrapped(*args, **kwargs)


def _aggregate_wrapper(wrapped, instance, args, kwargs):
    """aggregate(pipeline): a list of stages; ``$match``/``$expr`` can carry injected operators."""
    runtime = active_runtime()
    if runtime is not None:
        pipeline = kwargs.get("pipeline", args[0] if args else None)
        if pipeline is not None:
            text = _serialize(pipeline)
            if text:
                enforce(runtime.nosql.report(text))
    return wrapped(*args, **kwargs)


def _redis_command(wrapped, instance, args, kwargs):
    """redis-py execute_command(*args): inspect the assembled command (key/field injection via user input)."""
    runtime = active_runtime()
    if runtime is not None and args:
        text = _serialize([str(a) for a in args])
        if text:
            enforce(runtime.nosql.report(text))
    return wrapped(*args, **kwargs)


def install() -> None:
    import wrapt

    for module_name, class_name in _COLLECTION_TARGETS:
        try:
            __import__(module_name)
        except Exception:  # noqa: BLE001 - driver not installed
            continue
        for method in _FILTER_METHODS:
            try:
                wrapt.wrap_function_wrapper(module_name, f"{class_name}.{method}", _filter_wrapper)
            except Exception:  # noqa: BLE001 - method absent in this driver version
                continue
        try:
            wrapt.wrap_function_wrapper(module_name, f"{class_name}.aggregate", _aggregate_wrapper)
        except Exception:  # noqa: BLE001 - aggregate absent
            pass

    # redis-py: all commands funnel through execute_command (sync + async clients share the name).
    for module_name, class_name in (("redis.client", "Redis"), ("redis.asyncio.client", "Redis")):
        try:
            __import__(module_name)
            wrapt.wrap_function_wrapper(module_name, f"{class_name}.execute_command", _redis_command)
        except Exception:  # noqa: BLE001 - redis not installed / variant without execute_command
            continue

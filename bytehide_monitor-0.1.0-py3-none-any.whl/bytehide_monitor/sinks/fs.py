"""Path-traversal sink: instruments file-access entry points.

Covers ``builtins.open`` plus the idiomatic file APIs that do NOT route through it:
``pathlib.Path`` methods, the ``os`` filesystem calls (``os.open``/``remove``/``rename``/...), and ``shutil``
copy/move/delete. Each entry reports the path(s) to the path-traversal detector before the operation runs.
"""

from __future__ import annotations

import builtins
import os
import shutil
from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce


def _path_text(file: Any) -> str | None:
    try:
        if isinstance(file, bytes):
            return file.decode("utf-8", "replace")
        if isinstance(file, str):
            return file
        if hasattr(file, "__fspath__"):
            p = os.fspath(file)
            return p.decode("utf-8", "replace") if isinstance(p, bytes) else p
    except Exception:  # noqa: BLE001
        return None
    return None


def _report(runtime: Any, path: Any, op: str) -> None:
    if path is None or isinstance(path, int):  # skip file descriptors
        return
    text = _path_text(path)
    if text:
        enforce(runtime.file.report(text, op))


def _arg(args: tuple, kwargs: dict, index: int, name: str) -> Any:
    if name in kwargs:
        return kwargs[name]
    return args[index] if len(args) > index else None


def _open(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        _report(runtime, _arg(args, kwargs, 0, "file"), "file.open")
    return wrapped(*args, **kwargs)


def _os_one(op: str, name: str):
    """Wrapper for an os.* call whose first positional argument is a path."""
    def _w(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            _report(runtime, _arg(args, kwargs, 0, name), op)
        return wrapped(*args, **kwargs)
    return _w


def _os_two(op: str, a_name: str, b_name: str):
    """Wrapper for an os.* call that takes two paths (rename/replace): both are checked."""
    def _w(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            _report(runtime, _arg(args, kwargs, 0, a_name), op)
            _report(runtime, _arg(args, kwargs, 1, b_name), op)
        return wrapped(*args, **kwargs)
    return _w


def _pathlib_self(op: str):
    """Wrapper for a pathlib.Path method: the path is the bound instance (self)."""
    def _w(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            _report(runtime, instance, op)
        return wrapped(*args, **kwargs)
    return _w


def _shutil_two(op: str):
    """Wrapper for a shutil call (src, dst[, ...]): both paths are checked."""
    def _w(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            _report(runtime, _arg(args, kwargs, 0, "src"), op)
            _report(runtime, _arg(args, kwargs, 1, "dst"), op)
        return wrapped(*args, **kwargs)
    return _w


def _shutil_one(op: str, name: str):
    def _w(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            _report(runtime, _arg(args, kwargs, 0, name), op)
        return wrapped(*args, **kwargs)
    return _w


# os.* single-path calls: (attr, first-positional kwarg name, op label).
_OS_ONE = (
    ("open", "path", "os.open"),
    ("remove", "path", "os.remove"),
    ("unlink", "path", "os.unlink"),
    ("mkdir", "path", "os.mkdir"),
    ("makedirs", "name", "os.makedirs"),
    ("rmdir", "path", "os.rmdir"),
    ("scandir", "path", "os.scandir"),
    ("listdir", "path", "os.listdir"),
)
# os.* two-path calls.
_OS_TWO = (
    ("rename", "src", "dst", "os.rename"),
    ("replace", "src", "dst", "os.replace"),
)
# pathlib.Path methods whose target is the instance.
_PATHLIB = ("open", "read_text", "read_bytes", "write_text", "write_bytes", "unlink", "mkdir", "rmdir")
# shutil two-path calls.
_SHUTIL_TWO = ("copy", "copy2", "copyfile", "copymode", "copystat", "move")
# shutil single-path.
_SHUTIL_ONE = (("rmtree", "path"),)


def _safe_wrap(target: Any, attr: str, wrapper: Any) -> None:
    try:
        if hasattr(target, attr):
            wrapt.wrap_function_wrapper(target, attr, wrapper)
    except Exception:  # noqa: BLE001 - attribute absent / not wrappable on this platform
        pass


def install() -> None:
    wrapt.wrap_function_wrapper(builtins, "open", _open)

    for attr, name, op in _OS_ONE:
        _safe_wrap(os, attr, _os_one(op, name))
    for attr, a, b, op in _OS_TWO:
        _safe_wrap(os, attr, _os_two(op, a, b))

    for attr in _SHUTIL_TWO:
        _safe_wrap(shutil, attr, _shutil_two(f"shutil.{attr}"))
    for attr, name in _SHUTIL_ONE:
        _safe_wrap(shutil, attr, _shutil_one(f"shutil.{attr}", name))

    # pathlib.Path methods do not route through builtins.open, so they are patched directly.
    try:
        import pathlib

        for attr in _PATHLIB:
            _safe_wrap(pathlib.Path, attr, _pathlib_self(f"pathlib.Path.{attr}"))
    except Exception:  # noqa: BLE001 - pathlib always present, but never break install
        pass

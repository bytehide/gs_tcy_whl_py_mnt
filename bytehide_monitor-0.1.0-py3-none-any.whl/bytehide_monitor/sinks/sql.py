"""SQL-injection sink.

Two interception layers, mirroring the .NET interceptor's "patch the base class AND the
specific providers" strategy:

- **SQLAlchemy** (the Python analog of the common abstraction): the final SQL string for
  EVERY SQLAlchemy-backed execution funnels through ``DefaultDialect.do_execute`` /
  ``do_executemany`` / ``do_execute_no_params``, so one patch covers every dialect and
  driver SQLAlchemy can sit on (including ones with unpatchable C cursors) plus the
  stacks built on it: SQLModel, pandas ``read_sql``, Alembic, Flask-SQLAlchemy. While a
  dialect execution is in flight, the driver-level scan is suppressed (contextvar) so a
  query is never reported twice.

- **DB-API drivers**, for apps calling them directly. ``sqlite3``, ``pyodbc`` and ``psycopg2``
  expose immutable C types (their cursor methods cannot be patched in place), so their
  ``connect`` is proxied instead - the returned connection and every cursor it yields are
  wrapped. Pure-Python cursor classes are patched in place when their module is imported (lazy
  ``wrapt`` post-import hooks): pymysql, psycopg (v3), mysql connector, MySQLdb (mysqlclient),
  oracledb, and the async drivers asyncpg and aiomysql (their call methods take the query as the
  first argument; the scan runs synchronously before the coroutine is returned).

Transitively covered without their own patch: Django ORM and Peewee (they execute through
sqlite3/psycopg/MySQLdb/oracledb), aiosqlite and aiopg (thread/async wrappers over the
patched sqlite3/psycopg2), and Tortoise ORM (asyncpg/aiomysql/aiosqlite underneath).
"""

from __future__ import annotations

import contextvars
import sqlite3
from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce

# True while a SQLAlchemy dialect execution is scanning/executing: the driver-level
# patches skip their own scan so the same query is not reported twice.
_IN_DIALECT_EXEC: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "bh_sql_dialect_exec", default=False
)
# True while the Django CursorWrapper already scanned this query, so the underlying driver patch
# (e.g. sqlite3) does not scan/report it a second time.
_IN_OUTER_EXEC: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "bh_sql_outer_exec", default=False
)

# Django DB vendor -> the detector's dialect vocabulary.
_DJANGO_VENDORS = {"postgresql": "postgres", "mysql": "mysql", "sqlite": "sqlite", "oracle": "oracle"}

# SQLAlchemy dialect names that differ from the detector's dialect vocabulary.
_SQLALCHEMY_DIALECTS = {"postgresql": "postgres"}

# Async driver call methods whose first positional argument is the query text.
_ASYNCPG_METHODS = ("execute", "executemany", "fetch", "fetchrow", "fetchval", "prepare", "cursor")


def _scan(sql: Any, dialect: str | None) -> None:
    runtime = active_runtime()
    if runtime is not None and isinstance(sql, str):
        enforce(runtime.sql.report(sql, dialect, "sql.query"))


def _scan_driver(sql: Any, dialect: str | None) -> None:
    """Driver-level scan; a no-op while an OUTER layer (SQLAlchemy dialect or Django CursorWrapper)
    already scanned this query, so the same statement is never reported twice."""
    if _IN_DIALECT_EXEC.get() or _IN_OUTER_EXEC.get():
        return
    _scan(sql, dialect)


class _CursorProxy(wrapt.ObjectProxy):
    def __init__(self, wrapped: Any, dialect: str) -> None:
        super().__init__(wrapped)
        self._self_dialect = dialect

    def execute(self, sql, *args, **kwargs):
        _scan_driver(sql, self._self_dialect)
        return self.__wrapped__.execute(sql, *args, **kwargs)

    def executemany(self, sql, *args, **kwargs):
        _scan_driver(sql, self._self_dialect)
        return self.__wrapped__.executemany(sql, *args, **kwargs)


class _ConnectionProxy(wrapt.ObjectProxy):
    def __init__(self, wrapped: Any, dialect: str) -> None:
        super().__init__(wrapped)
        self._self_dialect = dialect

    def cursor(self, *args, **kwargs):
        return _CursorProxy(self.__wrapped__.cursor(*args, **kwargs), self._self_dialect)

    def execute(self, sql, *args, **kwargs):
        _scan_driver(sql, self._self_dialect)
        return self.__wrapped__.execute(sql, *args, **kwargs)

    def executemany(self, sql, *args, **kwargs):
        _scan_driver(sql, self._self_dialect)
        return self.__wrapped__.executemany(sql, *args, **kwargs)

    def executescript(self, sql, *args, **kwargs):
        # sqlite3 runs arbitrary SQL via executescript; scan it too (regression: it bypassed the proxy).
        _scan_driver(sql, self._self_dialect)
        return self.__wrapped__.executescript(sql, *args, **kwargs)

    def __enter__(self):
        # Return the proxy (not the wrapped connection) so statements inside `with conn:` stay scanned.
        self.__wrapped__.__enter__()
        return self

    def __exit__(self, *exc):
        return self.__wrapped__.__exit__(*exc)


def _connect_wrapper(dialect: str):
    def wrapper(wrapped, instance, args, kwargs):
        return _ConnectionProxy(wrapped(*args, **kwargs), dialect)

    return wrapper


def _execute_wrapper(dialect: str):
    def wrapper(wrapped, instance, args, kwargs):
        sql = kwargs.get("query", kwargs.get("operation", args[0] if args else None))
        _scan_driver(sql, dialect)
        return wrapped(*args, **kwargs)

    return wrapper


def _django_exec_wrapper(wrapped, instance, args, kwargs):
    # Django's CursorWrapper.execute(self, sql, params=None) / executemany(self, sql, param_list):
    # the statement is the first positional argument. This is pure-Python and the single funnel for
    # every Django query (ORM and raw ``connection.cursor().execute(...)``), so it covers psycopg2 -
    # whose C cursor cannot be patched and whose connection cannot be safely proxied under Django.
    sql = kwargs.get("sql", args[0] if args else None)
    dialect = None
    try:
        vendor = getattr(getattr(instance, "db", None), "vendor", None)
        dialect = _DJANGO_VENDORS.get(vendor, vendor)
    except Exception:  # noqa: BLE001 - dialect is best-effort
        dialect = None
    _scan(sql, dialect)
    token = _IN_OUTER_EXEC.set(True)
    try:
        return wrapped(*args, **kwargs)
    finally:
        _IN_OUTER_EXEC.reset(token)


def _sqlalchemy_dialect_name(dialect: Any) -> str | None:
    name = getattr(dialect, "name", None)
    if not isinstance(name, str) or not name:
        return None
    return _SQLALCHEMY_DIALECTS.get(name, name)


def _dialect_exec_wrapper(wrapped, instance, args, kwargs):
    # Signature: do_execute(cursor, statement, parameters, context) / do_execute_no_params
    # (cursor, statement, context); the statement is always the second positional argument.
    statement = args[1] if len(args) > 1 else kwargs.get("statement")
    _scan(statement, _sqlalchemy_dialect_name(instance))
    token = _IN_DIALECT_EXEC.set(True)
    try:
        return wrapped(*args, **kwargs)
    finally:
        _IN_DIALECT_EXEC.reset(token)


def install() -> None:
    # sqlite3's C types are immutable: proxy connect so connections/cursors are wrapped.
    wrapt.wrap_function_wrapper(sqlite3, "connect", _connect_wrapper("sqlite"))
    # SQLAlchemy: one patch on the default dialect covers every engine/driver/ORM on top.
    _install_sqlalchemy()
    # Pure-Python DB-API cursor classes, patched lazily when their module is imported.
    _install_methods("pymysql.cursors", "Cursor", ("execute", "executemany"), "mysql")
    # psycopg2's cursor/connection are C extension types: an in-place method patch raises TypeError
    # (silently dropped), and proxying ``connect`` is NOT safe here - Django's psycopg2 backend passes
    # the connection to C functions (``register_type`` etc.) that type-check it and reject an
    # ObjectProxy, crashing connection setup. psycopg2 is instead covered at the Django CursorWrapper
    # layer below (pure-Python, the single funnel for every Django query incl. raw cursor SQL).
    _install_django()
    # psycopg (v3) ships a pure-Python Cursor, so in-place patching works there (non-Django apps).
    _install_methods("psycopg", "Cursor", ("execute", "executemany"), "postgres")
    _install_methods(
        "mysql.connector.cursor", "MySQLCursor", ("execute", "executemany"), "mysql"
    )
    _install_methods("MySQLdb.cursors", "Cursor", ("execute", "executemany"), "mysql")
    _install_methods("oracledb", "Cursor", ("execute", "executemany"), "oracle")
    # Async drivers: the query is the first argument and the scan runs synchronously
    # before the coroutine is returned, so a block aborts at the call site.
    _install_methods("asyncpg.connection", "Connection", _ASYNCPG_METHODS, "postgres")
    _install_methods("aiomysql.cursors", "Cursor", ("execute", "executemany"), "mysql")
    # pyodbc is a C extension (immutable cursor type): proxy connect like sqlite3.
    _install_connect("pyodbc", "odbc")


def _install_methods(
    module_name: str, class_name: str, methods: tuple[str, ...], dialect: str
) -> None:
    """Patch ``class_name.<method>`` on ``module_name`` when (and if) it is imported."""

    def _hook(module: Any) -> None:
        target = getattr(module, class_name, None)
        if target is None:
            return
        for method in methods:
            try:
                wrapt.wrap_function_wrapper(target, method, _execute_wrapper(dialect))
            except Exception:  # noqa: BLE001 - method absent in this driver version
                continue

    wrapt.register_post_import_hook(_hook, module_name)


def _install_connect(module_name: str, dialect: str) -> None:
    """Proxy ``module.connect`` for drivers whose connection/cursor are C types."""

    def _hook(module: Any) -> None:
        try:
            wrapt.wrap_function_wrapper(module, "connect", _connect_wrapper(dialect))
        except Exception:  # noqa: BLE001 - no connect() in this module variant
            pass

    wrapt.register_post_import_hook(_hook, module_name)


def _install_django() -> None:
    """Patch Django's CursorWrapper.execute/executemany (pure-Python) when Django is imported."""

    def _hook(module: Any) -> None:
        wrapper_cls = getattr(module, "CursorWrapper", None)
        if wrapper_cls is None:
            return
        for method in ("execute", "executemany"):
            try:
                wrapt.wrap_function_wrapper(wrapper_cls, method, _django_exec_wrapper)
            except Exception:  # noqa: BLE001 - method/class absent in this Django version
                continue

    wrapt.register_post_import_hook(_hook, "django.db.backends.utils")


def _install_sqlalchemy() -> None:
    def _hook(module: Any) -> None:
        dialect_cls = getattr(module, "DefaultDialect", None)
        if dialect_cls is None:
            return
        for method in ("do_execute", "do_executemany", "do_execute_no_params"):
            try:
                wrapt.wrap_function_wrapper(dialect_cls, method, _dialect_exec_wrapper)
            except Exception:  # noqa: BLE001 - method absent in this SQLAlchemy version
                continue

    wrapt.register_post_import_hook(_hook, "sqlalchemy.engine.default")

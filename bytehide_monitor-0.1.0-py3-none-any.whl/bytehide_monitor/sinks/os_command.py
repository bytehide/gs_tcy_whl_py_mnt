"""Command-injection sink: instruments ``subprocess.Popen`` and ``os.system``."""

from __future__ import annotations

import os
import subprocess
from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce


def _command_text(args: Any) -> str:
    if isinstance(args, (list, tuple)):
        return " ".join(str(part) for part in args)
    return str(args)


def _popen_metadata(cmd: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
    """CommandInjectionMetadata fields from the subprocess.Popen call."""
    shell = bool(kwargs.get("shell", False))
    if isinstance(cmd, (list, tuple)):
        parts = [str(part) for part in cmd]
        file_name = str(kwargs.get("executable") or (parts[0] if parts else ""))
        arguments = " ".join(parts[1:])
    elif shell:
        # shell=True runs the string through the shell; FileName is the shell, the whole
        # command string is its argument (so FileName no longer duplicates Command).
        file_name = str(kwargs.get("executable") or ("cmd.exe" if os.name == "nt" else "/bin/sh"))
        arguments = str(cmd)
    else:
        file_name = str(kwargs.get("executable") or cmd)
        arguments = ""
    return {
        "FileName": file_name,
        "Arguments": arguments,
        "WorkingDirectory": str(kwargs.get("cwd") or ""),
        "UseShellExecute": shell,
    }


def _popen_init(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        cmd = kwargs.get("args", args[0] if args else None)
        if cmd is not None:
            enforce(runtime.command.report(_command_text(cmd), _popen_metadata(cmd, kwargs)))
    return wrapped(*args, **kwargs)


def _os_system(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None and args:
        cmd = str(args[0])
        # os.system always runs through the shell.
        meta = {"FileName": cmd, "Arguments": "", "WorkingDirectory": "", "UseShellExecute": True}
        enforce(runtime.command.report(cmd, meta))
    return wrapped(*args, **kwargs)


def _os_popen(wrapped, instance, args, kwargs):
    """os.popen(cmd) runs the command through the shell, exactly like os.system."""
    runtime = active_runtime()
    if runtime is not None:
        cmd = kwargs.get("cmd", args[0] if args else None)
        if cmd is not None:
            cmd = str(cmd)
            meta = {"FileName": cmd, "Arguments": "", "WorkingDirectory": "", "UseShellExecute": True}
            enforce(runtime.command.report(cmd, meta))
    return wrapped(*args, **kwargs)


def _os_exec(wrapped, instance, args, kwargs):
    """os.exec*/spawn*/posix_spawn: program path + arguments, executed directly (no shell)."""
    runtime = active_runtime()
    if runtime is not None and args:
        program = str(args[0])
        meta = {"FileName": program, "Arguments": _command_text(args[1:]), "WorkingDirectory": "", "UseShellExecute": False}
        enforce(runtime.command.report(_command_text(args), meta))
    return wrapped(*args, **kwargs)


# os.exec*/spawn* (program path is the first arg) and os.posix_spawn(path, argv, env...).
_EXEC_FUNCS = (
    "execl", "execle", "execlp", "execlpe", "execv", "execve", "execvp", "execvpe",
    "spawnl", "spawnle", "spawnlp", "spawnlpe", "spawnv", "spawnve", "spawnvp", "spawnvpe",
    "posix_spawn", "posix_spawnp",
)


def install() -> None:
    wrapt.wrap_function_wrapper(subprocess, "Popen.__init__", _popen_init)
    wrapt.wrap_function_wrapper(os, "system", _os_system)
    if hasattr(os, "popen"):
        wrapt.wrap_function_wrapper(os, "popen", _os_popen)
    for func in _EXEC_FUNCS:
        try:
            if hasattr(os, func):
                wrapt.wrap_function_wrapper(os, func, _os_exec)
        except Exception:  # noqa: BLE001 - not available on this platform
            continue

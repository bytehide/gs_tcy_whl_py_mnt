"""SSTI sink: instruments Jinja2 template compilation from a string.

``Environment.from_string`` is the single chokepoint for Jinja2 / Flask ``render_template_string`` and direct
``Template(source)`` use; the template source is handed to the template-injection detector before compilation.
"""

from __future__ import annotations

from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce

_WRAPPED: set = set()


def _from_string(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    runtime = active_runtime()
    if runtime is not None:
        source = kwargs.get("source", args[0] if args else None)
        if isinstance(source, (str, bytes)) and source:
            text = source.decode("utf-8", "replace") if isinstance(source, bytes) else source
            enforce(runtime.template.report(text))
    return wrapped(*args, **kwargs)


def _wrap(target: Any, attr: str) -> None:
    key = (id(target), attr)
    if key in _WRAPPED:
        return
    try:
        wrapt.wrap_function_wrapper(target, attr, _from_string)
        _WRAPPED.add(key)
    except Exception:  # noqa: BLE001 - jinja2 variant without this symbol; skip
        pass


def install() -> None:
    def _hook(module: Any) -> None:
        if getattr(module, "Environment", None) is not None:
            _wrap(module.Environment, "from_string")

    wrapt.register_post_import_hook(_hook, "jinja2.environment")

"""Mass-assignment ORM sink (taint/correlation + the endpoint's declared allowlist).

Mass assignment is a CODE property: request data is bound to a model attribute that the endpoint was
not meant to let the client control. It is invisible from the request alone - the same body shape is
benign on one endpoint (``role`` on an invite serializer) and an exploit on another (``status`` raw-set
on an order). So instead of flagging field NAMES in the body (which false-positives on legitimate
``role``/``status``/``credit`` fields and even on LLM calls whose messages carry a ``role`` key), this
sink watches the actual data flow:

1. ALLOWLIST: when a request runs a recognised validator (DRF ``Serializer``, Django ``Form``), the
   set of fields it declares/validated is recorded per-request. That is the endpoint's intended input
   contract - the fields the client is *allowed* to set.
2. ORM BIND: when a model is saved, each concrete field whose value matches what the client sent under
   the same key (i.e. the request value actually landed on the model) is a request-controlled bind.
3. DECISION: a request-controlled bind to a SENSITIVE field that is NOT in the validated allowlist is
   mass assignment - the client set a sensitive attribute outside the endpoint's contract.

Why this distinguishes the cases:
* crAPI ``PUT /shop/orders/{id}`` does ``order.status = request_data["status"]`` raw (no serializer):
  allowlist empty, ``status`` sensitive + correlated -> BLOCK.
* A legitimate invite (``InvitationSerializer`` with ``role`` in ``Meta.fields``): ``role`` is in the
  validated allowlist -> NOT flagged.
* ``POST /v1/chat/completions`` to an LLM: there is no model bind at all -> never evaluated.

Best-effort and fail-open: missing framework -> skipped; any error while evaluating is swallowed.
"""
from __future__ import annotations

import contextvars
import uuid
from typing import Any

from bytehide_monitor.core.logging.logger import MonitorLogger

# Per-request set of field names a recognised validator (serializer/form) accepted. Empty when no
# validator ran (e.g. a raw Django view) - then only SENSITIVE fields can trip the sink.
_ALLOWLIST: contextvars.ContextVar[set[str] | None] = contextvars.ContextVar("bh_ma_allowlist", default=None)

_WRITE_METHODS = {"POST", "PUT", "PATCH"}

# Fields a client must never set unless the endpoint explicitly declares them: privilege/role flags,
# money balances, workflow STATE that drives money, API keys. Mirrors the request-level list but here
# it only matters AFTER confirming the value was request-controlled and bound to the model.
_SENSITIVE_FIELDS = (
    "role", "roles", "role_id", "is_admin", "isadmin", "admin", "is_staff",
    "is_superuser", "superuser", "verified", "is_verified", "permissions", "scope", "scopes",
    "available_credit", "credit", "balance", "status", "api_key", "apikey",
)
_MAX_FIELDS = 20


def reset_request_state() -> None:
    """Clear the per-request allowlist (called by the framework source at request start/end)."""
    _ALLOWLIST.set(None)


def _add_allowed(keys: Any) -> None:
    try:
        names = {str(k).lower() for k in keys if k is not None}
    except Exception:  # noqa: BLE001
        return
    if not names:
        return
    current = _ALLOWLIST.get()
    _ALLOWLIST.set((current | names) if current else set(names))


# --------------------------------------------------------------------------- validators (allowlist)
def _drf_run_validation_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    result = wrapped(*args, **kwargs)
    try:
        if isinstance(result, dict):
            _add_allowed(result.keys())
    except Exception:  # noqa: BLE001 - allowlist capture must never break validation
        pass
    return result


def _django_form_clean_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    result = wrapped(*args, **kwargs)
    try:
        cleaned = getattr(instance, "cleaned_data", None)
        if isinstance(cleaned, dict):
            _add_allowed(cleaned.keys())
    except Exception:  # noqa: BLE001
        pass
    return result


def _marshmallow_load_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    result = wrapped(*args, **kwargs)
    try:
        if isinstance(result, dict):
            _add_allowed(result.keys())
    except Exception:  # noqa: BLE001
        pass
    return result


def _pydantic_init_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    result = wrapped(*args, **kwargs)
    try:
        _add_allowed(_pydantic_field_names(instance))
    except Exception:  # noqa: BLE001
        pass
    return result


def _pydantic_field_names(instance: Any) -> Any:
    cls = type(instance)
    model_fields = getattr(cls, "model_fields", None)  # pydantic v2
    if isinstance(model_fields, dict):
        return model_fields.keys()
    legacy_fields = getattr(cls, "__fields__", None)  # pydantic v1
    if isinstance(legacy_fields, dict):
        return legacy_fields.keys()
    return ()


# --------------------------------------------------------------------------- ORM bind (sink)
def _django_model_save_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    # Evaluate BEFORE the write so a block aborts the save. _check raises SecurityException on a hard
    # block (propagated to the framework source -> 403); everything else is swallowed (fail-open).
    _check_mass_assignment(instance)
    return wrapped(*args, **kwargs)


def _sqlalchemy_flush_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    # instance is the Session. Inspect pending inserts (session.new) and updates (session.dirty) and
    # evaluate each BEFORE the flush hits the DB. A block raises SecurityException; other errors are
    # swallowed (fail-open). SQLAlchemy has no built-in input allowlist, so it relies on the validator
    # hooks (Pydantic/Marshmallow) for the allowlist, falling back to sensitive-only when none ran.
    try:
        targets = list(getattr(instance, "new", []) or []) + list(getattr(instance, "dirty", []) or [])
    except Exception:  # noqa: BLE001
        targets = []
    for obj in targets:
        _check_mass_assignment(obj)
    return wrapped(*args, **kwargs)


def _check_mass_assignment(model: Any) -> None:
    from bytehide_monitor.sinks._patcher import enforce

    enforce(_evaluate(model))  # None -> no-op; blocking decision -> raises SecurityException


def _evaluate(model: Any):
    try:
        from bytehide_monitor.cloud.context import context as context_holder
        from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
        from bytehide_monitor.cloud.scanner.scanner import execute_action
        from bytehide_monitor.core.protection.detection_result import DetectionResult
        from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType
        from bytehide_monitor.sinks._patcher import active_runtime

        runtime = active_runtime()
        if runtime is None:
            return None
        context = context_holder.get()
        if context is None or not context.method:
            return None
        if str(context.method).strip().upper() not in _WRITE_METHODS:
            return None
        body = context.body
        if not isinstance(body, dict) or not body:
            return None

        engine = runtime.engine
        protections = getattr(engine, "protections", None) or {}
        protection = protections.get(ProtectionModuleType.MASS_ASSIGNMENT.value)
        if protection is None or not protection.enabled:
            return None

        config = protection.config if isinstance(getattr(protection, "config", None), dict) else {}
        sensitive = {f.lower() for f in (_str_list(config.get("sensitive_fields")) or list(_SENSITIVE_FIELDS))}
        sensitive |= {f.lower() for f in (_str_list(config.get("extra_sensitive_fields")) or [])}
        allow = {f.lower() for f in (_str_list(config.get("allow_fields")) or [])}
        allowlist = (_ALLOWLIST.get() or set()) | allow

        # Lower-cased view of the request body keys for matching against model field names.
        body_lower = {str(k).lower(): v for k, v in body.items()}

        flagged: list[str] = []
        for field in _concrete_fields(model):
            name = field.lower()
            if name not in sensitive or name in allowlist or name not in body_lower:
                continue
            model_value = _model_value(model, field)
            if model_value is None:
                continue
            # The request value actually landed on the model attribute -> request-controlled bind.
            if str(model_value) == str(body_lower[name]):
                flagged.append(field)
                if len(flagged) >= _MAX_FIELDS:
                    break

        if not flagged:
            return None

        reason = f"Mass assignment: request-controlled bind to sensitive field(s): {', '.join(flagged)}"
        metadata: dict[str, Any] = {"Fields": flagged, "Model": _model_name(model)}
        if context.method:
            metadata["RequestMethod"] = str(context.method)
        path = context.route or context.url
        if path:
            metadata["RequestPath"] = str(path)

        result = DetectionResult.threat(ProtectionModuleType.MASS_ASSIGNMENT.value, reason, 0.85, metadata)
        block, action_name = execute_action(ProtectionModuleType.MASS_ASSIGNMENT, protection, result)
        return BlockDecision.detected(
            ProtectionModuleType.MASS_ASSIGNMENT, reason, result, str(uuid.uuid4()),
            blocked=block, action=action_name,
        )
    except Exception:  # noqa: BLE001 - the sink must never break a model save
        return None


def _concrete_fields(model: Any) -> list[str]:
    """Names of the model's own (non-relational scalar) fields, best-effort across ORMs."""
    names: list[str] = []
    meta = getattr(model, "_meta", None)
    fields = getattr(meta, "concrete_fields", None) if meta is not None else None
    if fields is not None:
        for f in fields:
            name = getattr(f, "name", None)
            if isinstance(name, str):
                names.append(name)
        return names
    # SQLAlchemy / generic fallback: instrumented attribute names from the mapper, else instance dict.
    table = getattr(model, "__table__", None)
    if table is not None and hasattr(table, "columns"):
        try:
            return [c.name for c in table.columns]
        except Exception:  # noqa: BLE001
            pass
    return [k for k in vars(model).keys() if not k.startswith("_")] if hasattr(model, "__dict__") else []


def _model_value(model: Any, field: str) -> Any:
    meta = getattr(model, "_meta", None)
    if meta is not None:
        # Use attname for Django so FK ids are read without triggering a DB fetch.
        try:
            f = meta.get_field(field)
            attname = getattr(f, "attname", field)
            return getattr(model, attname, None)
        except Exception:  # noqa: BLE001
            return getattr(model, field, None)
    return getattr(model, field, None)


def _model_name(model: Any) -> str:
    try:
        return type(model).__name__
    except Exception:  # noqa: BLE001
        return "model"


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
        return items or None
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return None


# --------------------------------------------------------------------------- install
def _patch(module: Any, dotted: str, wrapper: Any) -> bool:
    import wrapt

    try:
        wrapt.wrap_function_wrapper(module, dotted, wrapper)
        return True
    except Exception:  # noqa: BLE001 - method absent in this version / already wrapped
        return False


def install() -> None:
    """Register post-import hooks: capture validator allowlists and guard the ORM bind."""
    try:
        import wrapt
    except ImportError:
        return

    def _hook_drf(module: Any) -> None:
        if _patch(module, "Serializer.run_validation", _drf_run_validation_wrapper):
            MonitorLogger.info("MA_DRF", "Mass-assignment allowlist source installed (DRF serializer)")

    def _hook_django_forms(module: Any) -> None:
        _patch(module, "BaseForm.full_clean", _django_form_clean_wrapper)

    def _hook_django_models(module: Any) -> None:
        if _patch(module, "Model.save", _django_model_save_wrapper):
            MonitorLogger.info("MA_DJANGO", "Mass-assignment ORM guard installed (Django Model.save)")

    def _hook_marshmallow(module: Any) -> None:
        _patch(module, "Schema.load", _marshmallow_load_wrapper)

    def _hook_pydantic(module: Any) -> None:
        # Pydantic models are the input contract in FastAPI/Starlette apps; their declared fields are
        # the allowlist. __init__ covers both ``Model(**data)`` and ``model_validate``.
        if _patch(module, "BaseModel.__init__", _pydantic_init_wrapper):
            MonitorLogger.info("MA_PYDANTIC", "Mass-assignment allowlist source installed (Pydantic)")

    def _hook_sqlalchemy(module: Any) -> None:
        if _patch(module, "Session.flush", _sqlalchemy_flush_wrapper):
            MonitorLogger.info("MA_SQLALCHEMY", "Mass-assignment ORM guard installed (SQLAlchemy flush)")

    # Allowlist sources (validators).
    wrapt.register_post_import_hook(_hook_drf, "rest_framework.serializers")
    wrapt.register_post_import_hook(_hook_django_forms, "django.forms.forms")
    wrapt.register_post_import_hook(_hook_marshmallow, "marshmallow")
    wrapt.register_post_import_hook(_hook_pydantic, "pydantic")
    # ORM bind sinks.
    wrapt.register_post_import_hook(_hook_django_models, "django.db.models.base")
    wrapt.register_post_import_hook(_hook_sqlalchemy, "sqlalchemy.orm.session")

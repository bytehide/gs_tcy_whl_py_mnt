"""Installs the in-app sink instrumentation (idempotent, fail-open).

Each sink is patched once globally. The active runtime is resolved lazily at call
time, so installing before or after :func:`bytehide_monitor.protect` both work. A
missing ``wrapt`` (the ``[sinks]`` extra is not installed) disables instrumentation
without error.
"""

from __future__ import annotations

import threading
from typing import Any

from bytehide_monitor.core.logging.logger import MonitorLogger

_installed = False
_lock = threading.Lock()


def install(runtime: Any = None) -> None:
    global _installed
    with _lock:
        if _installed:
            return
        try:
            import wrapt  # noqa: F401
        except ImportError:
            MonitorLogger.warning("SINK_NO_WRAPT", "Sink instrumentation disabled (wrapt missing)")
            return
        _installed = True

    for module_name in (
        # Taint source FIRST: it wraps the framework request accessors so values the app reads from the
        # request carry their TaintedStr marking into the sinks (used by SSRF to confirm user control).
        "bytehide_monitor.sinks.taint_source",
        "bytehide_monitor.sinks.sql",
        "bytehide_monitor.sinks.os_command",
        "bytehide_monitor.sinks.fs",
        "bytehide_monitor.sinks.http_out",
        "bytehide_monitor.sinks.ldap",
        "bytehide_monitor.sinks.nosql",
        "bytehide_monitor.sinks.xml_parse",
        "bytehide_monitor.sinks.template_render",
        "bytehide_monitor.sinks.deserialize",
        "bytehide_monitor.sinks.http_response",
        "bytehide_monitor.sinks.orm",
        "bytehide_monitor.sinks.ai",
        "bytehide_monitor.sinks.chainlit",
        "bytehide_monitor.sinks.directline",
    ):
        try:
            module = __import__(module_name, fromlist=["install"])
            module.install()
        except Exception as exc:  # noqa: BLE001 - one sink failing must not block the rest
            MonitorLogger.warning("SINK_INSTALL_FAIL", f"Sink {module_name} failed: {exc}")

"""SSRF sink: instruments outbound HTTP (``urllib`` and ``http.client``).

Optionally instruments ``requests`` and ``httpx`` when installed.
"""

from __future__ import annotations

import http.client
import urllib.request
from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce


def _urlopen(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        target = kwargs.get("url", args[0] if args else None)
        url = getattr(target, "full_url", None) or (target if isinstance(target, str) else None)
        if url:
            # A urllib Request infers its verb from whether a body is set; a bare URL is a GET.
            get_method = getattr(target, "get_method", None)
            method = get_method() if callable(get_method) else "GET"
            enforce(runtime.url.report(url, method))
    return wrapped(*args, **kwargs)


def _http_request(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        scheme = "https" if isinstance(instance, http.client.HTTPSConnection) else "http"
        host = getattr(instance, "host", "")
        port = getattr(instance, "port", None)
        method = kwargs.get("method", args[0] if args else "")
        path = kwargs.get("url", args[1] if len(args) > 1 else "")
        authority = f"{host}:{port}" if port else host
        enforce(runtime.url.report(f"{scheme}://{authority}{path}", str(method) or None))
    return wrapped(*args, **kwargs)


def _session_request(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        # requests/httpx Session.request(method, url, ...): method is the first positional arg.
        method = kwargs.get("method", args[0] if args else None)
        url = kwargs.get("url", args[1] if len(args) > 1 else None)
        if isinstance(url, str):
            enforce(runtime.url.report(url, str(method) if method else None))
    return wrapped(*args, **kwargs)


def _aiohttp_request(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        # aiohttp ClientSession._request(self, method, str_or_url, ...): the URL may be a yarl.URL.
        method = kwargs.get("method", args[0] if args else None)
        url = kwargs.get("str_or_url", args[1] if len(args) > 1 else None)
        if url is not None:
            enforce(runtime.url.report(str(url), str(method) if method else None))
    return wrapped(*args, **kwargs)


def install() -> None:
    wrapt.wrap_function_wrapper(urllib.request, "urlopen", _urlopen)
    wrapt.wrap_function_wrapper(http.client, "HTTPConnection.request", _http_request)
    _install_optional("requests.sessions", "Session.request", _session_request)
    _install_optional("httpx", "Client.request", _session_request)
    # AsyncClient.request shares the (method, url, ...) signature; enforce() runs before
    # the returned coroutine is awaited, so an SSRF target is blocked synchronously.
    _install_optional("httpx", "AsyncClient.request", _session_request)
    # aiohttp: all verbs funnel through ClientSession._request; enforce() runs before the coroutine is awaited.
    _install_optional("aiohttp.client", "ClientSession._request", _aiohttp_request)


def _install_optional(module_name: str, attribute: str, wrapper: Any) -> None:
    try:
        __import__(module_name)
        wrapt.wrap_function_wrapper(module_name, attribute, wrapper)
    except Exception:  # noqa: BLE001 - optional target not installed
        pass

"""Universal Chainlit guard — intercepts the CHAT BOUNDARY instead of the LLM SDK.

Why this exists: an app can talk to its model/agent through ANY transport — an SDK we patch (OpenAI, Anthropic,
Bedrock, ...), an SDK we don't, or raw HTTP (e.g. Copilot Studio via the Direct Line API with ``requests``).
There is no SDK method to hook in the raw-HTTP case, so SDK-level interception cannot cover it. But in a Chainlit
app EVERY user prompt arrives through ``@cl.on_message`` and EVERY reply leaves through ``cl.Message.send()``.
Guarding those two points protects the chat input + output regardless of what runs underneath — with no app code.

What it does (against the project's in-process route, reusing the AI sink's validation):
  * INPUT  (``on_message``):    block prompt-injection / mask PII on the user message BEFORE the handler runs (so
                                the masked text is what reaches Copilot / the model). A block replies with the
                                policy message and skips the handler (block-as-message, no exception).
  * OUTPUT (``Message.send``):  mask PII / block on the assistant reply BEFORE it is shown.

It is a SAFETY NET layered on top of the SDK sinks: when the inner SDK is already covered, the input guard runs
first (so the SDK sees masked text) and the output guard re-validates already-clean text (idempotent, one extra
round-trip). Default on; disable with ``BYTEHIDE_CHAINLIT_GUARD=0``. Fail-open and best-effort throughout: any
internal error, or no resolved gateway route (no token), leaves Chainlit untouched.
"""

from __future__ import annotations

import asyncio
import inspect
import os
from typing import Any

import wrapt

from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.sinks import ai as _ai

# Marks a Message whose content we have already guarded (or that we created ourselves, e.g. a block reply) so the
# output wrapper does not re-validate it on a later send()/update().
_SKIP_ATTR = "_bh_chainlit_guarded"
_DEFAULT_BLOCK = "\U0001f6e1️ Request blocked by security policy."

# Idempotency tracked here (not via an attribute on the target): Chainlit's top-level module uses a PEP-562
# lazy ``__getattr__`` that raises KeyError for unknown names, so probing a sentinel attribute on it would throw.
_WRAPPED: set = set()


def _wrap_attr(target: Any, attr: str, wrapper: Any) -> bool:
    """Wrap ``target.attr`` once. Robust to Chainlit's lazy module ``__getattr__``. Returns True if wrapped now."""
    key = (id(target), attr)
    if key in _WRAPPED:
        return False
    try:
        wrapt.wrap_function_wrapper(target, attr, wrapper)
        _WRAPPED.add(key)
        return True
    except Exception:  # noqa: BLE001 - Chainlit variant without this symbol; skip it
        return False


def _enabled() -> bool:
    return os.environ.get("BYTEHIDE_CHAINLIT_GUARD", "1").strip().lower() not in {"0", "false", "no", "off"}


def _guard_text(text: str, direction: str) -> tuple[str, str]:
    """Validate one chat string against the in-process route (delegates to the shared guard in the AI sink)."""
    return _ai.guard_chat_text(text, direction)


async def _aguard(text: str, direction: str) -> tuple[str, str]:
    """Run the blocking validate off the event loop so the Chainlit handler stays responsive."""
    return await asyncio.to_thread(_guard_text, text, direction)


async def _send_block(text: str) -> None:
    """Reply with a block message (marked so the output wrapper does not re-guard it)."""
    from chainlit.message import Message

    msg = Message(content=text)
    setattr(msg, _SKIP_ATTR, True)
    await msg.send()


def _make_guarded_handler(user_func: Any) -> Any:
    """Wrap a user ``on_message`` handler so the INPUT is guarded before it runs. The wrapper always takes the
    message (so Chainlit passes it to us); the original handler is then called with its own arity."""
    try:
        takes_message = len(inspect.signature(user_func).parameters) > 0
    except (TypeError, ValueError):
        takes_message = True

    async def _guarded(message: Any) -> Any:
        if _enabled():
            try:
                action, value = await _aguard(getattr(message, "content", "") or "", "input")
                if action == "block":
                    await _send_block(value)
                    return None
                if action == "mask":
                    message.content = value  # the handler now forwards the masked text to the model/Copilot
            except Exception:  # noqa: BLE001 - never break the handler on a guard error
                pass
        # While the handler runs, this turn owns the guarding: any raw-HTTP guard (e.g. Direct Line) defers so the
        # same prompt/reply is not validated twice. Reset on exit so out-of-turn HTTP calls are still guarded.
        token = _ai._HTTP_GUARD_SUPPRESSED.set(True)
        _ai._TURN_MODEL.set(None)  # clear last turn's model; the deferred SDK call sets this turn's real model
        try:
            return await user_func(message) if takes_message else await user_func()
        finally:
            _ai._HTTP_GUARD_SUPPRESSED.reset(token)

    return _guarded


def _on_message_deco(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Wrap ``cl.on_message`` so the registered handler is input-guarded."""
    if not args:
        return wrapped(*args, **kwargs)
    return wrapped(_make_guarded_handler(args[0]), *args[1:], **kwargs)


async def _send_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Wrap ``Message.send`` so the OUTPUT (assistant reply) is masked/blocked before it is shown. ``send`` is the
    finalizer for both plain and streamed messages (the full text lives in ``instance.content`` at this point)."""
    if _enabled() and not getattr(instance, _SKIP_ATTR, False):
        try:
            content = getattr(instance, "content", None)
            if isinstance(content, str) and content.strip():
                action, value = await _aguard(content, "output")
                if action in ("mask", "block"):
                    instance.content = value
                setattr(instance, _SKIP_ATTR, True)  # guarded once; skip on any later update()/send()
        except Exception:  # noqa: BLE001 - never break the reply on a guard error
            pass
    return await wrapped(*args, **kwargs)


def install() -> None:
    """Arm the Chainlit chat-boundary guard (idempotent, fail-open). Hooks fire only if/when Chainlit is imported.

    ``on_message`` is re-exported from ``chainlit`` and ``chainlit.callbacks`` as the SAME object but bound under two
    names, so both bindings are wrapped. ``Message.send`` is wrapped on the class, so every Message (and subclass that
    inherits send) is covered from one hook."""
    def _hook_message(module: Any) -> None:
        if getattr(module, "Message", None) is not None:
            _wrap_attr(module.Message, "send", _send_wrapper)

    def _hook_on_message(module: Any) -> None:
        try:
            present = getattr(module, "on_message", None) is not None
        except Exception:  # noqa: BLE001 - lazy module without the symbol
            present = False
        if present:
            _wrap_attr(module, "on_message", _on_message_deco)

    wrapt.register_post_import_hook(_hook_message, "chainlit.message")
    wrapt.register_post_import_hook(_hook_on_message, "chainlit.callbacks")
    wrapt.register_post_import_hook(_hook_on_message, "chainlit")
    MonitorLogger.info(
        "I_CHAINLIT_GUARD",
        "Chainlit chat-boundary guard armed (on_message input + Message.send output) — universal, transport-agnostic",
    )

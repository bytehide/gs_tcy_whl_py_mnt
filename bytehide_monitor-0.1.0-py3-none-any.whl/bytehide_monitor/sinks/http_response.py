"""Response-side sinks: open redirect and CRLF / HTTP response splitting (Starlette/FastAPI).

- ``RedirectResponse(url)``  -> open-redirect detector (blocks a redirect whose target is a user-controlled
  off-site URL before the response is built).
- ``Response.set_cookie(key, value, ...)`` -> CRLF detector (blocks a cookie value carrying CR/LF).

Best-effort: covers the common Starlette primitives that carry user input into the response.
"""

from __future__ import annotations

from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce

_WRAPPED: set = set()


def _redirect_init(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    runtime = active_runtime()
    if runtime is not None:
        url = kwargs.get("url", args[0] if args else None)
        if isinstance(url, str) and url:
            enforce(runtime.redirect.report(url))
    return wrapped(*args, **kwargs)


def _set_cookie(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    runtime = active_runtime()
    if runtime is not None:
        value = kwargs.get("value", args[1] if len(args) > 1 else None)
        if isinstance(value, str) and value:
            enforce(runtime.response_splitting.report(value))
    return wrapped(*args, **kwargs)


def _wrap(target: Any, attr: str, wrapper: Any) -> None:
    key = (id(target), attr)
    if key in _WRAPPED:
        return
    try:
        wrapt.wrap_function_wrapper(target, attr, wrapper)
        _WRAPPED.add(key)
    except Exception:  # noqa: BLE001 - variant without this symbol; skip
        pass


def install() -> None:
    def _hook(module: Any) -> None:
        redirect = getattr(module, "RedirectResponse", None)
        if redirect is not None:
            _wrap(redirect, "__init__", _redirect_init)
        response = getattr(module, "Response", None)
        if response is not None and hasattr(response, "set_cookie"):
            _wrap(response, "set_cookie", _set_cookie)

    wrapt.register_post_import_hook(_hook, "starlette.responses")

"""LDAP-injection sink: instruments ldap3 and python-ldap searches."""

from __future__ import annotations

from bytehide_monitor.sinks._patcher import active_runtime, enforce


def _ldap3_search(wrapped, instance, args, kwargs):
    runtime = active_runtime()
    if runtime is not None:
        # ldap3 Connection.search(search_base, search_filter, ...)
        search_filter = kwargs.get("search_filter", args[1] if len(args) > 1 else None)
        if isinstance(search_filter, str):
            enforce(runtime.ldap.report(search_filter))
    return wrapped(*args, **kwargs)


def _pyldap_search(index: int):
    def wrapper(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            filterstr = kwargs.get("filterstr", args[index] if len(args) > index else None)
            if isinstance(filterstr, str):
                enforce(runtime.ldap.report(filterstr))
        return wrapped(*args, **kwargs)

    return wrapper


def install() -> None:
    import wrapt

    _install(wrapt, "ldap3", "Connection.search", _ldap3_search)
    # python-ldap: SimpleLDAPObject.search_s(base, scope, filterstr, ...) and search_ext_s.
    _install(wrapt, "ldap.ldapobject", "SimpleLDAPObject.search_s", _pyldap_search(2))
    _install(wrapt, "ldap.ldapobject", "SimpleLDAPObject.search_ext_s", _pyldap_search(2))


def _install(wrapt, module_name: str, attribute: str, wrapper) -> None:
    try:
        __import__(module_name)
        wrapt.wrap_function_wrapper(module_name, attribute, wrapper)
    except Exception:  # noqa: BLE001 - optional library not installed
        pass

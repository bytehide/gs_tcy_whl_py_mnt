"""XXE sink: instruments XML parsers (lxml, ElementTree, minidom, SAX).

Entry points that receive the XML document as a string/bytes are inspected by the XXE
detector before parsing (Python equivalent of the .NET ``XxeInterceptor``).
"""

from __future__ import annotations

import os
from typing import Any

from bytehide_monitor.sinks._patcher import active_runtime, enforce

_MAX_XML_BYTES = 1_048_576  # read at most 1 MiB to inspect for XXE (DOCTYPE/ENTITY live at the top of the doc)


def _to_text(value: Any) -> str | None:
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    if isinstance(value, str):
        return value
    return None


def _source_text(source: Any) -> str | None:
    """Read a bounded chunk of an XML parse SOURCE (a filename, path, or file-like) to inspect for XXE.

    For a filename/path the file is read fresh (the parser reopens it by name, so nothing is consumed). For a
    file object the position is restored after reading; a non-seekable stream is skipped (we must not consume it)."""
    try:
        if hasattr(source, "read"):  # file-like
            seekable = getattr(source, "seekable", None)
            if not (callable(seekable) and source.seekable()):
                return None  # cannot restore -> do not consume the parser's stream
            pos = source.tell()
            try:
                data = source.read(_MAX_XML_BYTES)
            finally:
                source.seek(pos)
            return data.decode("utf-8", "replace") if isinstance(data, bytes) else (data if isinstance(data, str) else None)
        if isinstance(source, (str, bytes, os.PathLike)):
            path = os.fspath(source)
            path = path.decode("utf-8", "replace") if isinstance(path, bytes) else path
            with open(path, "rb") as handle:  # noqa: PTH123 - reading to inspect, not on behalf of the app
                return handle.read(_MAX_XML_BYTES).decode("utf-8", "replace")
    except Exception:  # noqa: BLE001 - unreadable source -> skip (fail-open)
        return None
    return None


def _string_arg_wrapper(index: int = 0, kw: str | None = None):
    def wrapper(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            raw = kwargs.get(kw) if kw else None
            if raw is None and len(args) > index:
                raw = args[index]
            text = _to_text(raw)
            if text:
                enforce(runtime.xml.report(text))
        return wrapped(*args, **kwargs)

    return wrapper


def _file_arg_wrapper(index: int = 0, kw: str | None = None):
    """Wrap a file/stream parser (``parse(source)``): read a bounded chunk of the source and inspect for XXE."""
    def wrapper(wrapped, instance, args, kwargs):
        runtime = active_runtime()
        if runtime is not None:
            raw = kwargs.get(kw) if kw else None
            if raw is None and len(args) > index:
                raw = args[index]
            text = _source_text(raw)
            if text:
                enforce(runtime.xml.report(text))
        return wrapped(*args, **kwargs)

    return wrapper


def install() -> None:
    import wrapt

    # lxml: fromstring(text) / XML(text) (string) + parse(source) (file/stream)
    _install(wrapt, "lxml.etree", "fromstring", _string_arg_wrapper(0))
    _install(wrapt, "lxml.etree", "XML", _string_arg_wrapper(0))
    _install(wrapt, "lxml.etree", "parse", _file_arg_wrapper(0))
    # Standard library ElementTree (string + file)
    _install(wrapt, "xml.etree.ElementTree", "fromstring", _string_arg_wrapper(0))
    _install(wrapt, "xml.etree.ElementTree", "XML", _string_arg_wrapper(0))
    _install(wrapt, "xml.etree.ElementTree", "parse", _file_arg_wrapper(0))
    # minidom / SAX (string + file)
    _install(wrapt, "xml.dom.minidom", "parseString", _string_arg_wrapper(0))
    _install(wrapt, "xml.dom.minidom", "parse", _file_arg_wrapper(0))
    _install(wrapt, "xml.sax", "parseString", _string_arg_wrapper(0))
    _install(wrapt, "xml.sax", "parse", _file_arg_wrapper(0))


def _install(wrapt, module_name: str, attribute: str, wrapper) -> None:
    try:
        __import__(module_name)
        wrapt.wrap_function_wrapper(module_name, attribute, wrapper)
    except Exception:  # noqa: BLE001 - parser/module not available
        pass

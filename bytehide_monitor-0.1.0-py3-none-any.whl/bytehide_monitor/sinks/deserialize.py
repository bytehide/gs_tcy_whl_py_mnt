"""Unsafe-deserialization sink: instruments ``pickle.loads`` and PyYAML's unsafe loaders.

The payload about to be deserialized is scanned for RCE gadgets (pickle GLOBAL+REDUCE of a dangerous module,
or a YAML ``!!python/...`` tag) before it runs.
"""

from __future__ import annotations

from typing import Any

import wrapt

from bytehide_monitor.sinks._patcher import active_runtime, enforce


def _as_text(value: Any) -> str | None:
    if isinstance(value, bytes):
        return value.decode("latin-1", "replace")
    if isinstance(value, str):
        return value
    return None


def _pickle_loads(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    runtime = active_runtime()
    if runtime is not None:
        data = kwargs.get("data", args[0] if args else None)
        text = _as_text(data)
        if text:
            enforce(runtime.deserialization.report(text))
    return wrapped(*args, **kwargs)


def _yaml_load(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    runtime = active_runtime()
    if runtime is not None:
        stream = kwargs.get("stream", args[0] if args else None)
        text = _as_text(stream)
        if text:
            enforce(runtime.deserialization.report(text))
    return wrapped(*args, **kwargs)


def install() -> None:
    import pickle

    wrapt.wrap_function_wrapper(pickle, "loads", _pickle_loads)

    def _hook(module: Any) -> None:
        # Only the UNSAFE loaders (full_load/unsafe_load/load with default Loader execute Python tags).
        for fn in ("load", "unsafe_load", "full_load", "load_all", "unsafe_load_all", "full_load_all"):
            if getattr(module, fn, None) is not None:
                try:
                    wrapt.wrap_function_wrapper(module, fn, _yaml_load)
                except Exception:  # noqa: BLE001 - already wrapped / absent
                    pass

    wrapt.register_post_import_hook(_hook, "yaml")

"""Aikido-style in-app sink instrumentation (optional, requires wrapt)."""

from bytehide_monitor.sinks.installer import install

__all__ = ["install"]

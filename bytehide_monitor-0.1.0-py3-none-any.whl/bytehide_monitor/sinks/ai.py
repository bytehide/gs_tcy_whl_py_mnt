"""AI SDK guard sink: protects outbound LLM SDK traffic with the ByteHide AI gateway.

Aikido's AI sinks only record provider/model/token statistics ``@after`` a call. This sink instead applies
the gateway's guardrails (prompt-injection + PII/secret detection) to the host application's OpenAI- and
Anthropic-SDK calls, in one of two modes selectable by the host developer via ``BYTEHIDE_AI_MODE``:

- ``gateway`` (default): transparently rewrite the SDK client ``base_url`` to the gateway and inject the
  ``x-gateway-key`` credential, so the gateway calls the provider on the host's behalf and guards the request
  inline. The client's own provider key stays in ``Authorization`` / ``x-api-key`` and is forwarded verbatim;
  the gateway never stores it. The SDK ``create`` call is also wrapped so that, when the gateway rejects a
  request (403 ``guardrail_blocked`` / 503 ``guardrail_unavailable``), a cloud incident is reported before the
  SDK error propagates to the host.

- ``inline``: leave the host calling the provider directly, but wrap the SDK ``create`` call to PRE-VALIDATE
  every request against the gateway's ``POST /monitor/validate`` endpoint first - the prompt-injection-only
  verdict backing the ``LlmPromptInjection`` rule, evaluated against the client's gateway-side policy (or the
  gateway default when the client has none). On a guardrail hit the incident is reported and the call is aborted
  with a :class:`SecurityException` (exactly like the SQL/LDAP/... sinks). On a clean verdict the original call
  proceeds untouched to the real provider. The input pass response also carries ``validate_output``: when the
  client's config requires it, the model OUTPUT is validated in-process too - after the call returns, its
  response text is sent back to ``/monitor/validate`` (as ``output``) and a gateway block aborts the response
  (the host never receives the flagged output) and reports an incident. When ``validate_output`` is false the
  output is not validated. Output extraction is per-SDK (OpenAI-compatible and Anthropic today); an SDK without
  an extractor, or a streaming response, gets input-only guarding.

Governance (AI guard carve-out): the ``LlmPromptInjection`` rule's PRESENCE governs this guard, NOT its action.
The interception hooks are armed whenever a gateway URL is set; per call, a disabled rule no-ops and an enabled
rule (or, with no active runtime, the null-config default) pre-validates against ``/monitor/validate``. The
gateway is the enforcement AUTHORITY: its policy verdict decides the block, and the local rule's action
(``log``/``none``/``block``) is intentionally IGNORED here - a gateway block always aborts the AI call. This
deliberately diverges from the HTTP sinks (where the action still decides) and from the original .NET
``LlmPromptInjectionInterceptor`` action semantics, because for AI traffic the gateway holds the per-client
prompt-injection policy. In ``gateway`` mode enforcement likewise happens at the gateway itself (the observer
only reports); only the rule's ``enabled`` flag gates reporting.

SDK coverage: the redirectable SDKs (openai - and through it every OpenAI-compatible provider and the
frameworks built on it (LangChain, LlamaIndex, autogen, instructor, openai-agents, pydantic-ai, ...) - and
anthropic) follow the selected mode. Native SDKs that build their own URLs cannot be redirected and are
ALWAYS inline pre-validated in both modes: groq, mistralai, google-generativeai, google-genai, Vertex AI
(``vertexai.generative_models``), LiteLLM (module-level ``completion``/``acompletion`` - which transitively
covers DSPy, CrewAI and smolagents), Ollama (``chat``/``generate``, sync and async) and AWS Bedrock
(boto3 ``bedrock-runtime``: ``converse``/``converse_stream``/``invoke_model``/``invoke_model_with_response_stream``,
guarded at botocore client creation). The Anthropic ``messages.stream()`` helper bypasses ``create`` and
returns a lazy manager that cannot be observed, so it is always pre-validated inline (in both modes); OpenAI's
``.stream()`` delegates to ``create`` and is covered transitively. Known limit: SDK modules imported BEFORE
``protect()`` keep any module-level bindings taken at their import time (call ``protect()`` first, as with
every sink).

Activation: inactive unless ``BYTEHIDE_AI_GATEWAY_URL`` is set. When set, the interception hooks are ALWAYS
armed (inline pre-validation, governed per call by the LlmPromptInjection rule). The gateway project config
(``GET /monitor/config``, keyed by the project token) selects only whether the redirectable SDKs additionally
run the full AI-guard product in ``gateway`` mode; ``BYTEHIDE_AI_MODE`` is an explicit local override, and an
unreachable gateway falls back to the local env so a config outage never drops protection.

Fail-open: any internal error (patching, construction, an unreachable gateway, a non-guardrail status) leaves
the host call untouched rather than breaking it. Only an explicit guardrail verdict (gateway 403/503) blocks.
"""

from __future__ import annotations

import asyncio
import contextvars
import json
import os
import types
import ssl
import traceback
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

import wrapt

from bytehide_monitor.cloud.config.protection_config import ProtectionConfig
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.config import env_vars
from bytehide_monitor.core.http.tls import create_ssl_context
from bytehide_monitor.core.http.api_client import PRODUCTION_BASE_URL, STAGING_BASE_URL
from bytehide_monitor.core.logging.logger import MonitorLogger
from bytehide_monitor.core.protection.detection_result import DetectionResult, sanitize_frames
from bytehide_monitor.core.protection.protection_module_type import ProtectionModuleType
from bytehide_monitor.core.protection.security_exception import SecurityException
from bytehide_monitor.sinks._patcher import active_runtime, enforce

# Tenant credential header the gateway authenticates against (maps a key to a tenant policy).
GATEWAY_KEY_HEADER = "x-gateway-key"

# Guard mode (BYTEHIDE_AI_MODE): transparent base_url redirect vs in-process pre-validation.
MODE_GATEWAY = "gateway"
MODE_INLINE = "inline"

# Bound on the /validate round-trip (inline mode); the gateway guard may invoke an ML model, so allow headroom.
_VALIDATE_TIMEOUT_SECONDS = 15
# Bound on the /monitor/config discovery read at startup; kept short so an unreachable gateway never hangs install.
_CONFIG_TIMEOUT_SECONDS = 8

# Provider API host -> gateway provider slug. Mirrors the gateway's provider allowlist. The OpenAI SDK
# talks to api.openai.com by default but can be pointed at any OpenAI-compatible provider via base_url;
# mapping the host lets the gateway route to the correct upstream. A host that is not in this map is
# left untouched, so a self-hosted or unknown endpoint is never silently rerouted.
_OPENAI_COMPATIBLE_HOSTS: dict[str, str] = {
    "api.openai.com": "openai",
    "api.groq.com": "groq",
    "api.mistral.ai": "mistral",
    "api.deepseek.com": "deepseek",
    "api.together.xyz": "together",
    "openrouter.ai": "openrouter",
    "api.x.ai": "xai",
    "api.perplexity.ai": "perplexity",
    "api.fireworks.ai": "fireworks",
    "api.cerebras.ai": "cerebras",
    "integrate.api.nvidia.com": "nvidia",
    # An OpenAI SDK pointed at Anthropic's OpenAI-compatible endpoint maps to the anthropic provider; the
    # gateway routes /anthropic/v1/chat/completions to it. The Anthropic SDK (native /v1/messages) is
    # handled separately by _anthropic_init.
    "api.anthropic.com": "anthropic",
}
_ANTHROPIC_HOST = "api.anthropic.com"

# SDK modules carrying the call methods we pre-validate / observe. Both the parent and leaf module paths are
# registered because the resource class is re-exported across SDK versions; a per-class sentinel
# (_wrap_class_method) makes the double registration idempotent.
_OPENAI_CALL_MODULES = ("openai.resources.chat.completions", "openai.resources.chat.completions.completions")
# OpenAI/Azure-OpenAI Responses API (client.responses.create) - a different method + body shape than chat.completions.
_OPENAI_RESPONSES_MODULES = ("openai.resources.responses", "openai.resources.responses.responses")
_ANTHROPIC_CALL_MODULES = ("anthropic.resources.messages", "anthropic.resources.messages.messages")
# Native (non-redirectable) SDKs - their clients build their own URLs, so they cannot be transparently rerouted
# by a base_url rewrite. They are always guarded by inline pre-validation, in both modes.
_GROQ_CALL_MODULES = ("groq.resources.chat.completions",)
# mistralai v2 moved the client under a `client/` subpackage; register both layouts (only one resolves).
_MISTRAL_CALL_MODULES = ("mistralai.chat", "mistralai.client.chat")
# Gemini: the legacy google-generativeai SDK and the unified google-genai SDK. Neither is OpenAI chat-shaped.
_GEMINI_LEGACY_MODULES = ("google.generativeai.generative_models",)
_GEMINI_UNIFIED_MODULES = ("google.genai.models",)
# LiteLLM exposes module-level completion()/acompletion() functions (no client class). Guarding them also
# covers the frameworks that route through LiteLLM under the hood (DSPy, CrewAI, smolagents, ...).
_LITELLM_MODULES = ("litellm",)
# Ollama: the class lives in ollama._client; the package re-exports it and binds the module-level chat()/
# generate() helpers to a default Client at import, so wrapping the class covers both call styles.
_OLLAMA_CALL_MODULES = ("ollama._client", "ollama")
# Vertex AI GenerativeModel (google-cloud-aiplatform); the preview namespace re-exports the same class.
_VERTEX_CALL_MODULES = ("vertexai.generative_models", "vertexai.preview.generative_models")
# Cohere: v2 (ClientV2.chat - OpenAI-shaped `messages`) and v1 (Client.chat - a single `message` string). Both
# methods are defined on the mixin base classes reached via MRO, so the base modules are the interception point.
_COHERE_V2_MODULES = ("cohere.v2.client",)
_COHERE_V1_MODULES = ("cohere.base_client",)
# Hugging Face InferenceClient.chat_completion (OpenAI-shaped messages); covers the sync and async clients.
_HF_MODULES = ("huggingface_hub", "huggingface_hub.inference._client")
# Azure AI Inference ChatCompletionsClient.complete - OpenAI-shaped, but messages may be typed SDK objects.
_AZURE_SYNC_MODULES = ("azure.ai.inference",)
_AZURE_ASYNC_MODULES = ("azure.ai.inference.aio",)
# Replicate: run(ref, input={"prompt": ...}) - prompt-shaped, not chat. The module-level run()/async_run() bind
# to a default Client, and the class lives in replicate.client; register both.
_REPLICATE_FUNC_MODULES = ("replicate",)
_REPLICATE_CLIENT_MODULES = ("replicate.client", "replicate")
# Bedrock clients are generated at runtime by botocore, so the interception point is client creation.
_BOTOCORE_CLIENT_MODULE = "botocore.client"
_BEDROCK_SERVICE = "bedrock-runtime"
_BEDROCK_AGENT_SERVICE = "bedrock-agent-runtime"  # managed Bedrock Agent (invoke_agent)
# LangChain / LangGraph: every chat model (ChatOpenAI, ChatAnthropic, ChatBedrock, ...) routes through
# BaseChatModel.generate / agenerate (invoke/ainvoke -> generate_prompt -> generate; bind_tools(...).ainvoke
# and LangGraph create_agent reach the same method). One hook on the base class covers all providers and the
# agent path, so a langchain app is guarded regardless of the underlying model.
_LANGCHAIN_MODULES = ("langchain_core.language_models.chat_models",)

_SSL_CONTEXT: ssl.SSLContext | None = None


@dataclass(frozen=True)
class _GatewayConfig:
    """Resolved gateway wiring: the base URL (no trailing slash) and the optional tenant key.

    route_mode=True means ``url`` is the project's in-process route (``{root}/{org}/{route}``): validation POSTs the
    body DIRECTLY to it (full in-process pipeline: injection + PII + toxicity + secrets, returns sanitized content),
    and the project is ALWAYS inline (never base_url rewrite). route_mode=False keeps the explicit-env behaviour."""

    url: str
    key: str | None
    route_mode: bool = False


@dataclass(frozen=True)
class _Verdict:
    """Outcome of a gateway guard check (from /validate, or parsed off a gateway SDK error)."""

    blocked: bool
    status: int
    violation_types: list[str]
    cwe_codes: list[str]
    category: str | None
    fallback: bool
    # Input-direction only: the gateway tells the monitor whether the client's config also requires
    # validating the model OUTPUT in-process after the call (see _validate / _make_inline_wrapper).
    validate_output: bool = False
    # Sanitized content from a non-blocking 200 in route_mode (mask): list[messages] for input, str for output.
    sanitized: Any = None
    # Block-as-message: the route returned 200 but the policy blocked and asked to REPLY with a message instead of a
    # 403. Not a hard block (no exception): the SDK short-circuits the model and returns ``block_message`` as output.
    soft_block: bool = False
    block_message: str | None = None


@dataclass(frozen=True)
class _PreCheck:
    """Result of the inline input pre-validation: a block decision to enforce (or None), plus whether the
    gateway asked the monitor to validate the model output afterwards."""

    decision: BlockDecision | None
    validate_output: bool
    # Block-as-message on the INPUT check: the wrapper returns this text as the model reply (no model call, no raise).
    block_message: str | None = None


# One-token bootstrap: with only BYTEHIDE_MONITOR_TOKEN set (no BYTEHIDE_AI_GATEWAY_URL), ask monitor-api
# (GET {base}/config/ai/{token}) for the gateway coordinates. Cached per process: False = not tried, None =
# tried without result, dict = coords. Fail-open: any error -> no AI config (the app layer still guards).
_AI_BOOTSTRAP: "dict[str, Any] | None | bool" = False


def _monitor_api_base() -> str:
    return STAGING_BASE_URL if env_vars.get_bool(env_vars.STAGING) else PRODUCTION_BASE_URL


def _bootstrap_ai() -> "dict[str, Any] | None":
    """Resolve gateway coordinates from monitor-api using the project token (cached; None if no token/unreachable)."""
    global _AI_BOOTSTRAP
    if _AI_BOOTSTRAP is not False:
        return _AI_BOOTSTRAP or None
    _AI_BOOTSTRAP = None
    token = env_vars.resolve_token()
    if not token:
        return None
    request = urllib.request.Request(url=f"{_monitor_api_base().rstrip('/')}/config/ai/{token}", method="GET")
    request.add_header("Accept", "application/json")
    try:
        with reentry_guard.internal(), urllib.request.urlopen(  # noqa: S310 - configured https monitor URL
            request, timeout=_CONFIG_TIMEOUT_SECONDS, context=_ssl_context()
        ) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except Exception:  # noqa: BLE001 - monitor unreachable / bad payload -> AI off, never raise
        return None
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data.get("gatewayUrl"):
        return None
    _AI_BOOTSTRAP = data
    return data


def ai_route_target() -> "tuple[str | None, str | None]":
    """(routeUrl, gatewayKey) for the project's in-process route, resolved via monitor-api. Helper for apps that
    validate I/O explicitly (e.g. Chainlit) when the SDK sink cannot intercept the call (custom transports)."""
    boot = _bootstrap_ai()
    if not boot:
        return None, None
    return boot.get("routeUrl") or boot.get("gatewayUrl"), boot.get("gatewayKey") or env_vars.resolve_token()


def _gateway_config() -> _GatewayConfig | None:
    """Resolved gateway wiring. Prefers BYTEHIDE_AI_GATEWAY_URL; otherwise falls back to the one-token bootstrap
    (monitor-api discovers the gateway URL from the project token), so only BYTEHIDE_MONITOR_TOKEN is required."""
    url = env_vars.get(env_vars.AI_GATEWAY_URL)
    if url:
        key = env_vars.get(env_vars.AI_GATEWAY_KEY) or env_vars.resolve_token()
        return _GatewayConfig(url.rstrip("/"), key)
    # One-token: a Monitor project is ALWAYS in-process -> use its route ({root}/{org}/{route}) and validate by
    # POSTing the body directly to it (full pipeline + sanitized), never /monitor/validate, never base_url rewrite.
    boot = _bootstrap_ai()
    route_url = (boot or {}).get("routeUrl") or (boot or {}).get("gatewayUrl")
    if boot and route_url:
        key = boot.get("gatewayKey") or env_vars.resolve_token()
        return _GatewayConfig(str(route_url).rstrip("/"), key, route_mode=True)
    return None


def _coerce_mode(value: str) -> str:
    """Coerces a mode string to a known value; anything other than ``inline`` is the default ``gateway``."""
    return MODE_INLINE if value.strip().lower() == MODE_INLINE else MODE_GATEWAY


def _mode() -> str:
    """Resolves the guard mode from env; anything other than ``inline`` (incl. unset) is the default ``gateway``."""
    return _coerce_mode(env_vars.get(env_vars.AI_MODE) or MODE_GATEWAY)


def _mode_override() -> str | None:
    """The explicit local mode override (BYTEHIDE_AI_MODE), or None when unset so the gateway decides the mode."""
    value = env_vars.get(env_vars.AI_MODE)
    return _coerce_mode(value) if value is not None else None


def _fetch_remote_config(config: _GatewayConfig) -> tuple[bool, str] | None:
    """Asks the gateway (GET /monitor/config, keyed by the project token) for (ai_enabled, mode). None on failure."""
    request = urllib.request.Request(url=f"{config.url}/monitor/config", method="GET")
    request.add_header("Accept", "application/json")
    if config.key:
        request.add_header(GATEWAY_KEY_HEADER, config.key)
    try:
        with reentry_guard.internal(), urllib.request.urlopen(  # noqa: S310 - configured https gateway URL
            request, timeout=_CONFIG_TIMEOUT_SECONDS, context=_ssl_context()
        ) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except Exception:  # noqa: BLE001 - gateway unreachable / bad payload -> caller falls back to local env
        return None
    if not isinstance(payload, dict):
        return None
    enabled, mode = payload.get("ai_enabled"), payload.get("mode")
    if not isinstance(enabled, bool) or not isinstance(mode, str):
        return None
    return enabled, _coerce_mode(mode)


def _resolve_activation(config: _GatewayConfig) -> tuple[bool, str]:
    """Decides whether to arm the AI guard and in which mode. The gateway is authoritative when reachable.

    Precedence: a reachable gateway governs enablement; the mode is the explicit local override
    (BYTEHIDE_AI_MODE) if set, else what the gateway returns. If the gateway cannot be reached, fall back to
    the local env (armed, env-selected mode) so a config outage never silently drops protection.
    """
    if config.route_mode:
        return True, MODE_INLINE  # one-token in-process route: always inline, never base_url rewrite
    remote = _fetch_remote_config(config)
    if remote is not None:
        ai_enabled, remote_mode = remote
        return ai_enabled, (_mode_override() or remote_mode)
    return True, _mode()


def _ssl_context() -> ssl.SSLContext:
    """Lazily-built default TLS context (full verification) reused across /validate calls."""
    global _SSL_CONTEXT
    if _SSL_CONTEXT is None:
        _SSL_CONTEXT = create_ssl_context()
    return _SSL_CONTEXT


def _host_of(base_url: Any) -> str:
    """Lowercased host of a base_url value (str or URL-like), or empty string when unparseable."""
    try:
        return (urlsplit(str(base_url)).hostname or "").lower()
    except Exception:  # noqa: BLE001 - never raise on a malformed base_url
        return ""


def _extra_hosts() -> dict[str, str]:
    """Parses the optional extra host->slug map (BYTEHIDE_AI_EXTRA_PROVIDERS); empty on missing/invalid JSON."""
    raw = env_vars.get(env_vars.AI_EXTRA_PROVIDERS)
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return {}
    return {str(host).lower(): str(slug) for host, slug in parsed.items()} if isinstance(parsed, dict) else {}


def _openai_slug(base_url: Any) -> str | None:
    """Maps an OpenAI client base_url to a gateway provider slug (default openai), or None to leave it untouched."""
    if base_url is None:
        return "openai"
    host = _host_of(base_url)
    return _OPENAI_COMPATIBLE_HOSTS.get(host) or _extra_hosts().get(host)


def _apply_gateway(kwargs: dict[str, Any], base_url: str, config: _GatewayConfig) -> None:
    """Overrides base_url and merges the gateway key header into the client constructor kwargs."""
    kwargs["base_url"] = base_url
    if config.key:
        headers = dict(kwargs.get("default_headers") or {})
        headers[GATEWAY_KEY_HEADER] = config.key
        kwargs["default_headers"] = headers


def _openai_init(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Redirects an OpenAI(-compatible) client to ``{gateway}/{provider}/v1`` when the host is known."""
    try:
        config = _gateway_config()
        if config is not None:
            slug = _openai_slug(kwargs.get("base_url"))
            if slug is not None:
                _apply_gateway(kwargs, f"{config.url}/{slug}/v1", config)
    except Exception:  # noqa: BLE001 - redirect is best-effort; never break client construction
        pass
    return wrapped(*args, **kwargs)


def _anthropic_init(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Redirects an Anthropic client to ``{gateway}/anthropic`` (the SDK appends ``/v1/messages``)."""
    try:
        config = _gateway_config()
        if config is not None:
            base = kwargs.get("base_url")
            if base is None or _host_of(base) == _ANTHROPIC_HOST:
                _apply_gateway(kwargs, f"{config.url}/anthropic", config)
    except Exception:  # noqa: BLE001 - redirect is best-effort; never break client construction
        pass
    return wrapped(*args, **kwargs)


def _patch_clients(module: Any, classes: tuple[str, ...], wrapper: Any) -> None:
    """Wraps each client class ``__init__`` in ``module``; a missing/unpatchable class is skipped."""
    for class_name in classes:
        try:
            wrapt.wrap_function_wrapper(module, f"{class_name}.__init__", wrapper)
        except Exception:  # noqa: BLE001 - SDK variant without this class; skip it
            pass


# --------------------------------------------------------------------------------------------------------- #
# Request bodies for the guard: distill an SDK ``create`` call into the chat shape /validate (and the gateway)
# understand. Only user/tool message content is what the injection/PII guard inspects.
# --------------------------------------------------------------------------------------------------------- #


def _model_of(kwargs: dict[str, Any]) -> str:
    model = kwargs.get("model")
    return model if isinstance(model, str) and model else "unknown"


def _text_of_content(content: Any) -> str:
    """Flattens a message ``content`` (str, list of parts/chunks, or an SDK object) into plain text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks: list[str] = []
        for part in content:
            text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
            if isinstance(text, str):
                chunks.append(text)
        return "\n".join(chunks)
    text = getattr(content, "text", None)
    return text if isinstance(text, str) else ""


def _normalize_messages(messages: list[Any]) -> list[dict[str, str]]:
    """Coerces SDK messages (dicts or typed objects, str or multimodal content) into JSON-safe {role, content}."""
    normalized: list[dict[str, str]] = []
    for message in messages:
        if isinstance(message, dict):
            role, content = message.get("role", "user"), message.get("content")
        else:
            role, content = getattr(message, "role", "user"), getattr(message, "content", None)
        normalized.append({"role": str(role), "content": _text_of_content(content)})
    return normalized


def _openai_chat_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from an OpenAI/Groq/Mistral chat ``create``/``complete`` call (messages kwarg); None when empty."""
    messages = kwargs.get("messages")
    if not isinstance(messages, list) or not messages:
        return None
    return {"model": _model_of(kwargs), "messages": _normalize_messages(messages)}


def _responses_input_messages(value: Any) -> list[dict[str, str]]:
    """Coerce the OpenAI Responses ``input`` (a plain string, or a list of message/items) into {role, content}."""
    if isinstance(value, str):
        return [{"role": "user", "content": value}] if value else []
    if isinstance(value, list):
        out: list[dict[str, str]] = []
        for item in value:
            if isinstance(item, dict):
                role, content = item.get("role", "user"), item.get("content")
            else:
                role, content = getattr(item, "role", "user"), getattr(item, "content", None)
            text = _text_of_content(content)
            if text:
                out.append({"role": str(role), "content": text})
        return out
    return []


def _openai_responses_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from an OpenAI/Azure-OpenAI Responses ``create`` call: the prompt is the ``input`` kwarg (string
    or message list), with the optional ``instructions`` kwarg folded in as a system message. None when empty."""
    messages = _responses_input_messages(kwargs.get("input"))
    instructions = kwargs.get("instructions")
    if isinstance(instructions, str) and instructions:
        messages.insert(0, {"role": "system", "content": instructions})
    if not messages:
        return None
    return {"model": _model_of(kwargs), "messages": messages}


def _anthropic_msg_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from an Anthropic ``messages.create`` call (the separate ``system`` prompt folded in)."""
    messages = kwargs.get("messages")
    if not isinstance(messages, list) or not messages:
        return None
    normalized = _normalize_messages(messages)
    system = kwargs.get("system")
    if isinstance(system, str) and system:
        normalized.insert(0, {"role": "system", "content": system})
    return {"model": _model_of(kwargs), "messages": normalized}


def _gemini_part_text(parts: Any) -> str:
    """Joins the text of a Gemini ``Content.parts`` list (parts may be str, dicts, or Part objects)."""
    if not isinstance(parts, list):
        return ""
    chunks: list[str] = []
    for part in parts:
        if isinstance(part, str):
            chunks.append(part)
            continue
        text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
        if isinstance(text, str):
            chunks.append(text)
    return "\n".join(chunks)


def _gemini_message(item: Any) -> dict[str, str] | None:
    """Maps one Gemini content item (str / Content dict / Content object) to a {role, content} message."""
    if isinstance(item, str):
        return {"role": "user", "content": item}
    if isinstance(item, dict):
        if isinstance(item.get("text"), str):  # a bare Part dict {"text": ...}
            return {"role": "user", "content": item["text"]}
        text = _gemini_part_text(item.get("parts"))
        return {"role": str(item.get("role", "user")), "content": text} if text else None
    role = getattr(item, "role", None) or "user"
    parts = getattr(item, "parts", None)
    text = _gemini_part_text(parts) if parts is not None else _text_of_content(item)
    return {"role": str(role), "content": text} if text else None


def _gemini_contents_to_messages(contents: Any) -> list[dict[str, str]]:
    """Normalizes Gemini ``contents`` (str / single Content / list of contents) into chat-shaped messages."""
    if contents is None:
        return []
    if isinstance(contents, str):
        return [{"role": "user", "content": contents}]
    items = contents if isinstance(contents, list) else [contents]
    return [message for message in (_gemini_message(item) for item in items) if message is not None]


def _gemini_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Gemini/Vertex ``generate_content`` call (``contents`` kwarg, or positional arg[0])."""
    contents = kwargs.get("contents")
    if contents is None and args:
        contents = args[0]
    messages = _gemini_contents_to_messages(contents)
    if not messages:
        return None
    # The unified SDK passes ``model`` on the call; google-generativeai binds it on the GenerativeModel
    # instance as ``model_name``; Vertex AI keeps it private as ``_model_name``.
    model = (
        kwargs.get("model")
        or getattr(instance, "model_name", None)
        or getattr(instance, "_model_name", None)
    )
    return {"model": model if isinstance(model, str) and model else "unknown", "messages": messages}


def _positional_chat_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a ``(model, messages)`` call shape (LiteLLM ``completion``, Ollama ``chat``)."""
    messages = kwargs.get("messages")
    if messages is None and len(args) > 1:
        messages = args[1]
    if not isinstance(messages, list) or not messages:
        return None
    model = kwargs.get("model") or (args[0] if args and isinstance(args[0], str) else None)
    return {
        "model": model if isinstance(model, str) and model else "unknown",
        "messages": _normalize_messages(messages),
    }


def _ollama_generate_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from an Ollama ``generate(model, prompt)`` call; the prompt becomes one user message."""
    prompt = kwargs.get("prompt")
    if prompt is None and len(args) > 1:
        prompt = args[1]
    if not isinstance(prompt, str) or not prompt:
        return None
    model = kwargs.get("model") or (args[0] if args and isinstance(args[0], str) else None)
    return {
        "model": model if isinstance(model, str) and model else "unknown",
        "messages": [{"role": "user", "content": prompt}],
    }


_LANGCHAIN_ROLE = {"human": "user", "ai": "assistant", "system": "system", "tool": "tool", "function": "tool"}


def _langchain_messages(value: Any) -> list[dict[str, str]]:
    """Flatten LangChain ``generate``/``agenerate`` messages (``list[list[BaseMessage]]``) into {role, content}.

    ``invoke``/``ainvoke`` wrap a single conversation, so it arrives as ``[[BaseMessage, ...]]``; we flatten every
    batch. Each ``BaseMessage`` carries ``.type`` (human/ai/system/tool) and ``.content`` (str or content parts)."""
    if not isinstance(value, list) or not value:
        return []
    batches = value if isinstance(value[0], list) else [value]
    out: list[dict[str, str]] = []
    for batch in batches:
        if not isinstance(batch, list):
            continue
        for message in batch:
            mtype = getattr(message, "type", None) or getattr(message, "role", None) or "user"
            text = _text_of_content(getattr(message, "content", None))
            if text:
                out.append({"role": _LANGCHAIN_ROLE.get(str(mtype), str(mtype)), "content": text})
    return out


def _langchain_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a LangChain ``BaseChatModel.generate``/``agenerate`` call (messages are positional arg[0])."""
    messages = kwargs.get("messages", args[0] if args else None)
    normalized = _langchain_messages(messages)
    if not normalized:
        return None
    model = getattr(instance, "model_name", None) or getattr(instance, "model", None)
    return {"model": str(model) if model else "unknown", "messages": normalized}


def _cohere_v1_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Cohere v1 ``chat`` call - a single ``message`` string (history is not pre-validated)."""
    message = kwargs.get("message")
    if not isinstance(message, str) or not message:
        return None
    return {"model": _model_of(kwargs), "messages": [{"role": "user", "content": message}]}


def _hf_chat_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Hugging Face ``InferenceClient.chat_completion`` call (messages 1st positional or kwarg)."""
    messages = kwargs.get("messages")
    if messages is None and args:
        messages = args[0]
    if not isinstance(messages, list) or not messages:
        return None
    return {"model": _model_of(kwargs), "messages": _normalize_messages(messages)}


def _replicate_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Replicate ``run(ref, input={"prompt": ...})`` call; the prompt becomes one user message."""
    payload = kwargs.get("input")
    if not isinstance(payload, dict):
        return None
    for key in ("prompt", "input", "text", "message"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            ref = args[0] if args and isinstance(args[0], str) else None
            return {"model": ref or "unknown", "messages": [{"role": "user", "content": value}]}
    return None


def _bedrock_block_text(blocks: Any) -> str:
    """Joins the ``text`` fields of a Bedrock content/system block list (``[{"text": ...}, ...]``)."""
    if not isinstance(blocks, list):
        return blocks if isinstance(blocks, str) else ""
    return "\n".join(block["text"] for block in blocks if isinstance(block, dict) and isinstance(block.get("text"), str))


def _bedrock_converse_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Bedrock ``converse``/``converse_stream`` call (kwargs-only boto3 API)."""
    raw_messages = kwargs.get("messages")
    if not isinstance(raw_messages, list) or not raw_messages:
        return None
    messages: list[dict[str, str]] = []
    for message in raw_messages:
        if not isinstance(message, dict):
            continue
        messages.append(
            {"role": str(message.get("role", "user")), "content": _bedrock_block_text(message.get("content"))}
        )
    if not messages:
        return None
    system = _bedrock_block_text(kwargs.get("system"))
    if system:
        messages.insert(0, {"role": "system", "content": system})
    model = kwargs.get("modelId")
    return {"model": model if isinstance(model, str) and model else "unknown", "messages": messages}


def _bedrock_invoke_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Bedrock ``invoke_model`` call: the JSON ``body`` differs per model family.

    Anthropic/Nova carry ``messages`` (+ optional ``system``); Llama/Mistral carry ``prompt``;
    Titan carries ``inputText``. Anything else (or an unparseable body) is left unguarded (fail-open).
    """
    raw = kwargs.get("body")
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="replace")
    if not isinstance(raw, str) or not raw:
        return None
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(payload, dict):
        return None
    messages: list[dict[str, str]] = []
    if isinstance(payload.get("messages"), list) and payload["messages"]:
        messages = _normalize_messages(payload["messages"])
        system = payload.get("system")
        system_text = system if isinstance(system, str) else _bedrock_block_text(system)
        if system_text:
            messages.insert(0, {"role": "system", "content": system_text})
    else:
        prompt = payload.get("prompt") or payload.get("inputText")
        if isinstance(prompt, str) and prompt:
            messages = [{"role": "user", "content": prompt}]
    if not messages:
        return None
    model = kwargs.get("modelId")
    return {"model": model if isinstance(model, str) and model else "unknown", "messages": messages}


# --------------------------------------------------------------------------------------------------------- #
# Gateway verdict: call /validate (inline mode) or parse a gateway SDK error (gateway mode), then turn a block
# into a cloud incident under the LlmPromptInjection module, governed by that module's protection rule.
# --------------------------------------------------------------------------------------------------------- #


def _read_json(exc: urllib.error.HTTPError) -> dict[str, Any]:
    try:
        raw = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
        parsed = json.loads(raw) if raw else {}
    except Exception:  # noqa: BLE001 - a malformed error body still yields a block (just without detail)
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _parse_validate_output(raw: bytes) -> bool:
    """Reads the ``validate_output`` flag from a 200 ``/monitor/validate`` body (best-effort; default False)."""
    try:
        parsed = json.loads(raw) if raw else {}
        return bool(parsed.get("validate_output")) if isinstance(parsed, dict) else False
    except Exception:  # noqa: BLE001 - a missing/malformed flag just means no output validation
        return False


def _validate(config: _GatewayConfig, body: dict[str, Any]) -> _Verdict | None:
    """Asks the gateway's ``POST /monitor/validate`` endpoint whether a request is safe.

    Handles both directions by the body shape: an ``messages`` body is an INPUT check (prompt-injection only,
    backing the ``LlmPromptInjection`` rule) whose 200 response also carries ``validate_output``; an ``output``
    body is an OUTPUT check (the client's output/PII policy). None = fail-open (unreachable / unexpected status).
    """
    try:
        data = json.dumps(body).encode("utf-8")
    except (TypeError, ValueError):
        return None
    # route_mode: ``url`` IS the in-process route -> POST directly (full pipeline). Else the monitor/validate endpoint.
    validate_url = config.url if config.route_mode else f"{config.url}/monitor/validate"
    request = urllib.request.Request(url=validate_url, data=data, method="POST")
    request.add_header("Content-Type", "application/json")
    request.add_header("Accept", "application/json")
    if config.key:
        request.add_header(GATEWAY_KEY_HEADER, config.key)
    try:
        # The monitor's own outbound HTTP must not be intercepted by the SSRF/http sinks.
        with reentry_guard.internal(), urllib.request.urlopen(  # noqa: S310 - configured https gateway URL
            request, timeout=_VALIDATE_TIMEOUT_SECONDS, context=_ssl_context()
        ) as response:
            raw = response.read()
            if config.route_mode:
                # 200 from the in-process route may carry sanitized content (mask): ``sanitized`` (input messages)
                # or ``output`` (text). Always validate output too (the route runs the full output pipeline).
                try:
                    parsed = json.loads(raw.decode("utf-8")) if raw else {}
                except (ValueError, UnicodeDecodeError):
                    parsed = {}
                if not isinstance(parsed, dict):
                    parsed = {}
                bh = parsed.get("bytehide") if isinstance(parsed.get("bytehide"), dict) else {}
                err = parsed.get("error") if isinstance(parsed.get("error"), dict) else {}
                # Block-as-message (200): treat ANY block signal in a 200 as a soft block (reply the message, never
                # call the model, report, no exception). Covers the standardized in-process shape (verdict "blocked"),
                # the proxy shape (bytehide.blocked), and a defensive 200-with-error body.
                if parsed.get("verdict") == "blocked" or bh.get("blocked") or err:
                    msg = parsed.get("message") or err.get("message")
                    if not msg:
                        try:
                            msg = parsed["choices"][0]["message"]["content"]  # OpenAI-wire proxy body
                        except (KeyError, IndexError, TypeError):
                            msg = None
                    if not msg:
                        try:
                            msg = parsed["content"][0]["text"]  # Anthropic proxy body
                        except (KeyError, IndexError, TypeError):
                            msg = None
                    cat = parsed.get("category") or bh.get("category") or err.get("code") or "policy"
                    return _Verdict(False, response.status, [str(cat)], [], cat, False, False, None,
                                    soft_block=True, block_message=msg or "")
                sanitized = parsed.get("sanitized") if parsed.get("sanitized") is not None else parsed.get("output")
                return _Verdict(False, response.status, [], [], None, False, True, sanitized)
            return _Verdict(False, response.status, [], [], None, False, _parse_validate_output(raw))
    except urllib.error.HTTPError as exc:
        # 403 = guardrail block, 503 = guardrail unavailable (fail-closed). Both abort the call and are reported.
        if exc.code in (403, 503):
            payload = _read_json(exc)
            error = payload.get("error") or {}
            guard = payload.get("guardrail") or {}
            return _Verdict(
                blocked=True,
                status=exc.code,
                violation_types=[str(v) for v in (guard.get("violation_types") or [])],
                cwe_codes=[str(c) for c in (guard.get("cwe_codes") or [])],
                category=error.get("code"),
                fallback=(exc.code == 503),
            )
        return None  # any other status -> fail-open
    except Exception:  # noqa: BLE001 - gateway unreachable / timeout -> fail-open, never break the host
        return None


def _error_payload(exc: BaseException) -> dict[str, Any] | None:
    """Extracts the JSON error body from an SDK exception (OpenAI/Anthropic both expose ``.body`` / ``.response``).

    The Anthropic SDK keeps ``.body`` as the full response envelope, but the OpenAI SDK UNWRAPS it to the
    inner ``error`` object (``body.get("error", body)`` in ``_make_status_error``), dropping the sibling
    ``guardrail`` detail. When the envelope is missing, re-read it from ``.response``; if that fails, rebuild
    a minimal envelope from the unwrapped error so a gateway block is still recognized.
    """
    body = getattr(exc, "body", None)
    if isinstance(body, dict) and isinstance(body.get("error"), dict):
        return body
    response = getattr(exc, "response", None)
    if response is not None:
        try:
            parsed = response.json()
        except Exception:  # noqa: BLE001 - non-JSON / unreadable response
            parsed = None
        if isinstance(parsed, dict) and isinstance(parsed.get("error"), dict):
            return parsed
    if isinstance(body, dict) and body.get("type") in ("guardrail_blocked", "guardrail_unavailable"):
        return {"error": body}
    return None


def _verdict_from_exception(exc: BaseException) -> _Verdict | None:
    """A gateway guardrail block surfaces as an SDK 4xx/5xx whose body carries our ``guardrail_*`` error type."""
    payload = _error_payload(exc)
    if not isinstance(payload, dict):
        return None
    error = payload.get("error") or {}
    error_type = error.get("type")
    if error_type not in ("guardrail_blocked", "guardrail_unavailable"):
        return None
    guard = payload.get("guardrail") or {}
    status = getattr(exc, "status_code", None) or (503 if error_type == "guardrail_unavailable" else 403)
    return _Verdict(
        blocked=True,
        status=int(status),
        violation_types=[str(v) for v in (guard.get("violation_types") or [])],
        cwe_codes=[str(c) for c in (guard.get("cwe_codes") or [])],
        category=error.get("code"),
        fallback=(error_type == "guardrail_unavailable"),
    )


def _describe(verdict: _Verdict) -> str:
    if verdict.fallback:
        return "AI request blocked: gateway guardrail unavailable (fail-closed)"
    details = ", ".join(verdict.violation_types) if verdict.violation_types else "policy violation"
    category = (verdict.category or "prompt_injection").lower()
    if category == "pii":
        return f"Disallowed PII detected in AI request: {details}"
    if category == "toxicity":
        return f"Toxic content detected in AI request: {details}"
    if category in ("quarantine", "approval_required"):
        return f"AI request blocked by action policy: {details}"
    return f"LLM prompt injection detected: {details}"


def _confidence(verdict: _Verdict) -> float:
    if verdict.fallback:
        return 0.7
    return 0.95 if (verdict.category or "prompt_injection").lower() == "prompt_injection" else 0.9


def _module_protection() -> ProtectionConfig | None:
    """The live ``LlmPromptInjection`` rule: the preset/file baseline overlaid by dashboard heartbeats.

    None when no runtime is active (the guard then falls back to blocking, like the .NET
    interceptor's null-config default).
    """
    runtime = active_runtime()
    if runtime is None:
        return None
    try:
        return runtime.engine.protections.get(ProtectionModuleType.LLM_PROMPT_INJECTION.value)
    except Exception:  # noqa: BLE001 - a partially built runtime (bootstrap/tests) carries no rule
        return None


def _sdk_method(wrapped: Any) -> str | None:
    """Dotted path of the intercepted SDK callable (module.Class.method), best-effort.

    Names the host-facing SDK function whose call carried the injection (e.g.
    ``openai.resources.chat.completions.Completions.create``) for the incident report.
    """
    try:
        qualname = getattr(wrapped, "__qualname__", None) or getattr(wrapped, "__name__", None)
        module = getattr(wrapped, "__module__", None)
        if not qualname:
            # Callable object (no function metadata): name it by its type.
            qualname = getattr(type(wrapped), "__qualname__", None)
            module = getattr(type(wrapped), "__module__", None)
        if not qualname:
            return None
        return f"{module}.{qualname}" if module else str(qualname)
    except Exception:  # noqa: BLE001 - naming is best-effort; never break the call path
        return None


def _call_site_stack() -> list[str] | None:
    """Sanitized host stack at the SDK call site.

    Valid only on the thread executing the host's call: synchronously inside the
    wrapper, or - for async callers - on the event loop thread at wrapper entry, where
    the awaiting coroutine frames are still live on the C stack (the ``send()`` chain),
    BEFORE handing validation off to a worker thread.
    """
    try:
        return sanitize_frames(traceback.extract_stack()[:-1])
    except Exception:  # noqa: BLE001 - stack capture is best-effort
        return None


def _build_result(
    verdict: _Verdict, sdk_method: str | None = None, stack: list[str] | None = None
) -> DetectionResult:
    """DetectionResult for a gateway guard verdict (shared by the inline and observer paths).

    ``sdk_method`` names the intercepted SDK function in the description and metadata;
    ``stack`` carries the host call-site frames captured at the wrapper (required for
    async callers, whose frames are unreachable by the automatic capture).
    """
    metadata: dict[str, Any] = {
        "source": "ai_gateway",
        "mode": _mode(),
        "category": verdict.category,
        "violationTypes": verdict.violation_types,
    }
    if sdk_method:
        metadata["sdkMethod"] = sdk_method
    if verdict.cwe_codes:
        metadata["cweCodes"] = verdict.cwe_codes
    if verdict.fallback:
        metadata["failClosed"] = True
    description = _describe(verdict)
    if sdk_method:
        description = f"{description} via {sdk_method}"
    return DetectionResult.threat(
        ProtectionModuleType.LLM_PROMPT_INJECTION.value,
        description,
        _confidence(verdict),
        metadata,
        stack=stack,
    )


def _decide_inline(
    verdict: _Verdict,
    sdk_method: str | None = None,
    stack: list[str] | None = None,
) -> BlockDecision:
    """Builds the inline block decision for a gateway guardrail verdict.

    The ``LlmPromptInjection`` rule's local ACTION is intentionally ignored: the gateway is the
    enforcement authority for AI prompt-injection. The monitor rule's presence + ``enabled`` flag
    only ARM the guard (gated by the caller); once armed, the gateway's policy verdict decides.
    This function is reached only on a gateway block verdict, so the host call is always aborted -
    ``log``/``none`` no longer downgrade an AI-injection block to incident-only. The incident is
    still reported. (The action concept remains in force for the HTTP sinks; this carve-out is
    specific to the gateway-backed AI guard.)
    """
    result = _build_result(verdict, sdk_method, stack)
    return BlockDecision.detected(
        ProtectionModuleType.LLM_PROMPT_INJECTION,
        result.description,
        result,
        uuid.uuid4().hex,
        blocked=True,
        action="block",
    )


def _report(decision: BlockDecision) -> None:
    """Reports the incident through the active runtime, when one is present (fail-safe)."""
    runtime = active_runtime()
    if runtime is None:
        return
    try:
        runtime.report_sink_incident(decision)
    except Exception:  # noqa: BLE001 - reporting must never break the host call
        pass


def _pre_validate(
    body_builder: Any,
    instance: Any,
    args: tuple,
    kwargs: dict[str, Any],
    sdk_method: str | None = None,
    stack: list[str] | None = None,
) -> _PreCheck:
    """Inline mode: pre-check a call against /monitor/validate. Returns the block decision (or None) plus
    whether the gateway asked the monitor to ALSO validate the model output after the call.

    The ``LlmPromptInjection`` rule's PRESENCE governs this guard, not its action: a disabled rule turns
    the guard off entirely; otherwise the call is validated against the gateway, and the gateway's policy
    verdict (the client's gateway-side policy, or the gateway default) is authoritative. A gateway block
    aborts the host call regardless of how the local rule's action is configured (``log``/``none`` no longer
    downgrade an AI-injection block - see :func:`_decide_inline`). The incident is reported on every block.
    Async callers pre-capture ``stack`` on the loop thread (this runs in a worker); sync callers leave it
    None and the host frames are captured lazily on a verdict.
    """
    try:
        config = _gateway_config()
        if config is None:
            return _PreCheck(None, False)
        # The LlmPromptInjection rule (live from the dashboard heartbeat) is the on/off switch for the AI guard,
        # in BOTH the in-process route path and the explicit-env path: a disabled rule turns the guard off
        # entirely (no validate call), exactly like disabling a web detector. None = no runtime -> guard on.
        protection = _module_protection()
        if protection is not None and not protection.enabled:
            return _PreCheck(None, False)
        body = body_builder(instance, args, kwargs)
        if body is None:
            return _PreCheck(None, False)
        verdict = _validate(config, body)
        if verdict is None:
            return _PreCheck(None, False)  # gateway unreachable -> fail-open, no output validation
        if verdict.soft_block:
            # Block-as-message: report the incident and carry both the message AND a hard-block decision, so the
            # wrapper replies with the message when it can shape it, or falls back to enforcing the block otherwise.
            if stack is None:
                stack = _call_site_stack()
            decision = _decide_inline(verdict, sdk_method, stack)
            _report(decision)
            return _PreCheck(decision, False, block_message=verdict.block_message or "")
        if not verdict.blocked:
            if config.route_mode and verdict.sanitized:
                _apply_input_sanitized(kwargs, verdict.sanitized)  # mask: substitute the sanitized input
            return _PreCheck(None, True if config.route_mode else verdict.validate_output)
        if stack is None:
            stack = _call_site_stack()
        decision = _decide_inline(verdict, sdk_method, stack)
        _report(decision)
        return _PreCheck(decision, False)
    except Exception:  # noqa: BLE001 - pre-validation is best-effort; never break the host on internal error
        return _PreCheck(None, False)


def _validate_output_result(
    result: Any, sdk_method: str | None = None, stack: list[str] | None = None
) -> BlockDecision | None:
    """Output-direction check: extract the model's response text and validate it against the gateway's output
    policy. Returns a block decision to enforce, or None to let the response through.

    Only invoked when the input pre-check reported ``validate_output``. :func:`_output_text` is best-effort and
    returns None for shapes it cannot read (e.g. a streaming manager), in which case output validation is
    skipped. Like the input path, a gateway block is authoritative and reported.
    """
    try:
        text = _output_text(result)
        if not text:
            return None
        config = _gateway_config()
        if config is None:
            return None
        verdict = _validate(config, {"output": text})
        if verdict is not None and verdict.soft_block:
            # Block-as-message on output: replace the model reply with the block message and report (no raise).
            if verdict.block_message:
                _apply_output_sanitized(result, verdict.block_message)
            if stack is None:
                stack = _call_site_stack()
            _report(_decide_inline(verdict, sdk_method, stack))
            return None
        if verdict is None or not verdict.blocked:
            if config.route_mode and verdict is not None and isinstance(verdict.sanitized, str) and verdict.sanitized != text:
                _apply_output_sanitized(result, verdict.sanitized)  # mask: substitute the sanitized output
            return None
        if stack is None:
            stack = _call_site_stack()
        decision = _decide_inline(verdict, sdk_method, stack)
        _report(decision)
        return decision
    except Exception:  # noqa: BLE001 - output validation is best-effort; never break the host on internal error
        return None


# --------------------------------------------------------------------------------------------------------- #
# Shared chat-text guard (used by the framework-boundary sinks: Chainlit + Direct Line). Validates one string
# against the in-process route and returns a normalized decision; never raises (block is surfaced as a message).
# --------------------------------------------------------------------------------------------------------- #

# Set True (per async context) while a Chainlit turn owns the guarding, so the Direct Line HTTP guard defers and
# the same prompt/reply is not validated twice. Outside a Chainlit turn it is False and the HTTP guard acts.
_HTTP_GUARD_SUPPRESSED: "contextvars.ContextVar[bool]" = contextvars.ContextVar("bh_http_guard_suppressed", default=False)

# Real model name seen during the current turn. When the SDK sink defers to a border guard (Chainlit/Direct
# Line) it records the model here so the border's OUTPUT trace shows the actual model (e.g. claude-sonnet-4-6)
# instead of the generic "chat". The INPUT border runs before any model call, so it stays "chat" by design.
_TURN_MODEL: "contextvars.ContextVar[str | None]" = contextvars.ContextVar("bh_turn_model", default=None)


def _capture_turn_model(body_builder: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> None:
    """Record the real model of the call being deferred, for the border output guard. Best-effort, never raises."""
    try:
        body = body_builder(instance, args, kwargs)
        model = body.get("model") if isinstance(body, dict) else None
        if isinstance(model, str) and model and model not in ("unknown", "chat"):
            _TURN_MODEL.set(model)
    except Exception:  # noqa: BLE001 - capturing the model name must never affect the host call
        pass


_CHAT_DEFAULT_BLOCK = "\U0001f6e1️ Request blocked by security policy."


def _chat_messages_text(sanitized: Any) -> str | None:
    """Join the ``content`` of a sanitized INPUT messages list into one string (None if not shaped so)."""
    if not isinstance(sanitized, list):
        return None
    parts = [m.get("content", "") for m in sanitized if isinstance(m, dict)]
    joined = "\n".join(p for p in parts if isinstance(p, str) and p)
    return joined or None


def _report_chat_block(verdict: _Verdict, sdk_method: str) -> None:
    try:
        _report(_decide_inline(verdict, sdk_method, _call_site_stack()))
    except Exception:  # noqa: BLE001 - reporting must never break the host
        pass


def chat_block_decision(message: str | None, sdk_method: str = "chat.input") -> BlockDecision:
    """Build a BlockDecision for a chat-text hard block (for raising SecurityException where no chat-UX reply is
    possible, e.g. a raw-HTTP send). The incident itself is already reported by :func:`guard_chat_text`."""
    verdict = _Verdict(True, 403, [], [], message or "policy", False)
    return _decide_inline(verdict, sdk_method, _call_site_stack())


def guard_chat_text(text: str, direction: str) -> tuple[str, str]:
    """Validate one chat string against the in-process route. ``direction`` is 'input' or 'output'. Returns:
        ("ok", text)        -> let it through unchanged
        ("mask", masked)    -> substitute the sanitized text
        ("block", message)  -> do not proceed; use this message instead
    Blocking is surfaced as a message (never raises here). Fail-open on any error / no resolved route."""
    try:
        if not isinstance(text, str) or not text.strip():
            return ("ok", text)
        config = _gateway_config()
        if config is None:
            return ("ok", text)
        # Same on/off switch as the SDK guard: a disabled LlmPromptInjection rule turns the border guard off too.
        protection = _module_protection()
        if protection is not None and not protection.enabled:
            return ("ok", text)
        # INPUT runs before the model call, so the model is unknown -> "chat". OUTPUT runs after it, so use the
        # real model captured during the turn (set by the deferred SDK sink), falling back to "chat" (e.g. an
        # echo app or an unsupported SDK that never set it).
        body: dict[str, Any] = (
            {"model": "chat", "messages": [{"role": "user", "content": text}]}
            if direction == "input"
            else {"output": text, "model": _TURN_MODEL.get() or "chat"}
        )
        verdict = _validate(config, body)
        if verdict is None:
            return ("ok", text)
        sdk_method = f"chat.{direction}"
        if verdict.soft_block:
            _report_chat_block(verdict, sdk_method)
            return ("block", verdict.block_message or _CHAT_DEFAULT_BLOCK)
        if verdict.blocked:
            _report_chat_block(verdict, sdk_method)
            cat = getattr(verdict, "category", None)
            return ("block", f"\U0001f6e1️ Blocked by security policy ({cat})" if cat else _CHAT_DEFAULT_BLOCK)
        masked = _chat_messages_text(verdict.sanitized) if direction == "input" else (
            verdict.sanitized if isinstance(verdict.sanitized, str) else None
        )
        if masked and masked != text:
            return ("mask", masked)
        return ("ok", text)
    except Exception:  # noqa: BLE001 - guarding is best-effort; never break the host
        return ("ok", text)


def _observe_gateway_block(
    exc: BaseException, sdk_method: str | None = None, stack: list[str] | None = None
) -> None:
    """Gateway mode: when the SDK call fails with a gateway guardrail error, report the incident (then re-raise).

    The gateway already refused the call upstream, so the module rule's action cannot
    change the outcome here; only its ``enabled`` flag applies (a disabled rule reports
    nothing, like a disabled .NET interceptor). The decision reports what happened: blocked.
    """
    try:
        verdict = _verdict_from_exception(exc)
        if verdict is None or not verdict.blocked:
            return
        protection = _module_protection()
        if protection is not None and not protection.enabled:
            return
        result = _build_result(verdict, sdk_method, stack if stack is not None else _call_site_stack())
        _report(
            BlockDecision.forbidden(
                ProtectionModuleType.LLM_PROMPT_INJECTION, result.description, result, uuid.uuid4().hex
            )
        )
    except Exception:  # noqa: BLE001 - observation must never alter the propagating error
        pass


# --------------------------------------------------------------------------------------------------------- #
# Output extraction: distill ANY SDK response object into the model's plain-text output for the output guard.
# One universal probe rather than a per-SDK map, because SDKs that share an input body builder can return
# different response shapes (e.g. Cohere v2 builds its input like OpenAI but answers under message.content,
# and LiteLLM vs Ollama share a body builder with different outputs). Best-effort and side-effect-free: each
# shape is tried in turn and the first non-empty text wins; an unrecognized shape (e.g. a streaming manager)
# yields None, which skips output validation for that call.
# --------------------------------------------------------------------------------------------------------- #


def _attr_or_key(obj: Any, name: str) -> Any:
    """Reads ``name`` from an object attribute or a dict key (SDKs return either)."""
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def _join_text_blocks(blocks: Any) -> str | None:
    """Concatenates the ``text`` of a content-block list (Anthropic, Cohere v2, Gemini parts, Bedrock)."""
    if not isinstance(blocks, list):
        return None
    parts = [_attr_or_key(block, "text") for block in blocks]
    text = "".join(part for part in parts if isinstance(part, str))
    return text or None


def _output_text(result: Any) -> str | None:
    """Plain-text model output from any supported SDK response, or None when the shape is not recognized.

    Covers: OpenAI-compatible (openai/groq/mistral/azure/litellm/huggingface) ``choices[0].message.content``;
    Anthropic ``content[].text``; Cohere v2 ``message.content[].text`` and v1 ``text``; Gemini/Vertex ``text``
    and ``candidates[0].content.parts[].text``; Ollama chat ``message.content`` / generate ``response``;
    Bedrock Converse ``output.message.content[].text``; Replicate ``str`` / ``list[str]``.
    """
    try:
        if isinstance(result, str):
            return result or None
        if isinstance(result, list) and result and all(isinstance(item, str) for item in result):
            joined = "".join(result)
            return joined or None
        # OpenAI/Azure Responses API: the SDK exposes a flattened ``output_text`` convenience over output[].content[].text.
        responses_text = _attr_or_key(result, "output_text")
        if isinstance(responses_text, str) and responses_text:
            return responses_text
        # OpenAI-compatible: choices[0].message.content (chat) or choices[0].text (completions).
        choices = _attr_or_key(result, "choices")
        if isinstance(choices, list) and choices:
            message = _attr_or_key(choices[0], "message")
            content = _attr_or_key(message, "content") if message is not None else None
            if isinstance(content, str) and content:
                return content
            legacy = _attr_or_key(choices[0], "text")
            if isinstance(legacy, str) and legacy:
                return legacy
        # Anthropic: a top-level content-block list.
        text = _join_text_blocks(_attr_or_key(result, "content"))
        if text:
            return text
        # Ollama chat (message.content str) and Cohere v2 (message.content blocks).
        message = _attr_or_key(result, "message")
        if message is not None:
            inner = _attr_or_key(message, "content")
            if isinstance(inner, str) and inner:
                return inner
            text = _join_text_blocks(inner)
            if text:
                return text
        # Ollama generate.
        response = _attr_or_key(result, "response")
        if isinstance(response, str) and response:
            return response
        # Gemini / Vertex / Cohere v1: a flattened .text.
        flat = _attr_or_key(result, "text")
        if isinstance(flat, str) and flat:
            return flat
        # Gemini candidates: candidates[0].content.parts[].text.
        candidates = _attr_or_key(result, "candidates")
        if isinstance(candidates, list) and candidates:
            content = _attr_or_key(candidates[0], "content")
            text = _join_text_blocks(_attr_or_key(content, "parts") if content is not None else None)
            if text:
                return text
        # Bedrock Converse: output.message.content[].text.
        output = _attr_or_key(result, "output")
        if output is not None:
            msg = _attr_or_key(output, "message")
            text = _join_text_blocks(_attr_or_key(msg, "content") if msg is not None else None)
            if text:
                return text
        # LangChain LLMResult (generate/agenerate): generations[0][0].message.content (chat) or .text.
        generations = _attr_or_key(result, "generations")
        if isinstance(generations, list) and generations and isinstance(generations[0], list) and generations[0]:
            gen = generations[0][0]
            gen_msg = _attr_or_key(gen, "message")
            gen_content = _attr_or_key(gen_msg, "content") if gen_msg is not None else None
            if isinstance(gen_content, str) and gen_content:
                return gen_content
            gen_text = _attr_or_key(gen, "text")
            if isinstance(gen_text, str) and gen_text:
                return gen_text
    except Exception:  # noqa: BLE001 - any extraction error -> skip output validation, never break the host
        return None
    return None


# --------------------------------------------------------------------------------------------------------- #
# Call-method instrumentation: wrap the SDK ``create`` methods (sync + async) for both modes.
# --------------------------------------------------------------------------------------------------------- #


def _apply_input_sanitized(kwargs: dict[str, Any], sanitized: Any) -> None:
    """Substitute the gateway-sanitized input (mask) before the model call. Safe across SDK shapes: only replaces
    OpenAI-style ``messages`` (string content) or Bedrock-Agent ``inputText``; block-style inputs are left intact."""
    try:
        if not (isinstance(sanitized, list) and sanitized):
            return
        msgs = kwargs.get("messages")
        if isinstance(msgs, list) and msgs and isinstance(msgs[0], dict) and isinstance(msgs[0].get("content"), str):
            kwargs["messages"] = sanitized
        elif "input" in kwargs:  # OpenAI/Azure Responses API: ``input`` is a string or a message list
            user_msgs = [m for m in sanitized if isinstance(m, dict) and m.get("role") != "system"]
            if isinstance(kwargs.get("input"), str):
                joined = "\n".join(str(m.get("content", "")) for m in user_msgs)
                if joined:
                    kwargs["input"] = joined
            elif user_msgs:
                kwargs["input"] = user_msgs
        elif isinstance(kwargs.get("inputText"), str):
            text = "\n".join(
                str(m.get("content", "")) for m in sanitized if isinstance(m, dict) and m.get("role") != "system"
            )
            if text:
                kwargs["inputText"] = text
    except Exception:  # noqa: BLE001 - substitution is best-effort; never break the call
        pass


def _apply_output_sanitized(result: Any, text: str) -> None:
    """Write the gateway-sanitized text back onto the response object (mask). Best-effort across common SDK shapes;
    no-op if the object is immutable or unrecognized (the block path still protects)."""
    try:
        choices = getattr(result, "choices", None)
        if isinstance(choices, list) and choices:
            msg = getattr(choices[0], "message", None)
            if msg is not None and isinstance(getattr(msg, "content", None), str):
                msg.content = text
                return
        content = getattr(result, "content", None)
        if isinstance(content, list):
            for block in content:
                if isinstance(getattr(block, "text", None), str):
                    block.text = text
                    return
        # OpenAI/Azure Responses API: output[].content[].text (``output_text`` itself is read-only/computed).
        output = getattr(result, "output", None)
        if isinstance(output, list):
            for item in output:
                blocks = getattr(item, "content", None)
                if isinstance(blocks, list):
                    for block in blocks:
                        if isinstance(getattr(block, "text", None), str):
                            block.text = text
                            return
        msg = getattr(result, "message", None)
        if msg is not None and isinstance(getattr(msg, "content", None), str):
            msg.content = text
            return
        if isinstance(getattr(result, "response", None), str):
            result.response = text
            return
        # LangChain LLMResult: generations[0][0].message.content (chat) or .text.
        generations = getattr(result, "generations", None)
        if isinstance(generations, list) and generations and isinstance(generations[0], list) and generations[0]:
            gen = generations[0][0]
            gen_msg = getattr(gen, "message", None)
            if gen_msg is not None and isinstance(getattr(gen_msg, "content", None), str):
                gen_msg.content = text
                return
            if isinstance(getattr(gen, "text", None), str):
                gen.text = text
                return
    except Exception:  # noqa: BLE001 - response object may be immutable; leave it untouched
        pass


def _extract_delta(chunk: Any) -> str:
    """Best-effort text delta from one streaming chunk (Anthropic ``delta.text`` / OpenAI ``choices[].delta.content``)."""
    try:
        delta = getattr(chunk, "delta", None)
        # OpenAI/Azure Responses API stream: ResponseTextDeltaEvent.delta is the text string itself.
        if isinstance(delta, str):
            return delta
        text = getattr(delta, "text", None) if delta is not None else None
        if isinstance(text, str):
            return text
        choices = getattr(chunk, "choices", None)
        if choices:
            inner = getattr(choices[0], "delta", None)
            content = getattr(inner, "content", None) if inner is not None else None
            if isinstance(content, str):
                return content
    except Exception:  # noqa: BLE001
        return ""
    return ""


def _stream_guard_mode() -> str:
    """Streaming output-guard mode. 'final' (default): stream chunks, validate the full accumulated output at the end.
    'off': disable the streamed output guard. 'buffer' (validate-before-emit) reserved for later."""
    return os.getenv("BYTEHIDE_AI_STREAM_GUARD", "final").strip().lower()


def _final_stream_check(text: str, sdk_method: str | None = None) -> None:
    """After a stream completes: validate the full accumulated output against the in-process route. A block verdict
    is reported and raised (chunks already emitted, so the host decides); a clean verdict is a no-op. Fail-open."""
    try:
        config = _gateway_config()
        if config is None:
            return
        verdict = _validate(config, {"output": text})
        if verdict is None or not verdict.blocked:
            return
        decision = _decide_inline(verdict, sdk_method, _call_site_stack())
        _report(decision)
        enforce(decision)  # raises after the stream is exhausted
    except SecurityException:
        raise
    except Exception:  # noqa: BLE001 - final stream check is best-effort; never break the stream
        return


def _buffer_validate(text: str, sdk_method: str | None) -> tuple:
    """Validate fully-accumulated stream output (buffer mode). Returns (action, value): ('pass', None),
    ('mask', masked_text), ('block', decision) or ('softblock', (decision, message)). Fail-open -> ('pass', None)."""
    try:
        config = _gateway_config()
        if config is None or not text.strip():
            return ("pass", None)
        verdict = _validate(config, {"output": text})
        if verdict is None:
            return ("pass", None)
        if verdict.soft_block:
            decision = _decide_inline(verdict, sdk_method, _call_site_stack())
            _report(decision)
            return ("softblock", (decision, verdict.block_message or ""))
        if verdict.blocked:
            decision = _decide_inline(verdict, sdk_method, _call_site_stack())
            _report(decision)
            return ("block", decision)
        if config.route_mode and isinstance(verdict.sanitized, str) and verdict.sanitized != text:
            return ("mask", verdict.sanitized)
        return ("pass", None)
    except Exception:  # noqa: BLE001 - never break the stream
        return ("pass", None)


def _wrap_stream_sync(stream: Any, sdk_method: str | None = None) -> Any:
    """'final' (default): emit each chunk live, then validate the full output (block-only at the end). 'buffer':
    consume the whole stream, validate, and re-emit the sanitized text (enables OUTPUT MASKING for streaming, at
    the cost of real-time delivery) -> the policy's "buffered, full mask & block" mode."""
    if _stream_guard_mode() == "buffer":
        def _buffered() -> Any:
            chunks = list(stream)
            text = "".join(_extract_delta(c) for c in chunks)
            action, value = _buffer_validate(text, sdk_method)
            if action == "block":
                enforce(value)  # raises
            elif action == "softblock":
                decision, msg = value
                synth = _synthesize_block_response(msg, True, False, sdk_method)
                if synth is not None:
                    yield from synth
                    return
                enforce(decision)
            elif action == "mask":
                synth = _synthesize_block_response(value, True, False, sdk_method)
                if synth is not None:
                    yield from synth
                    return
            yield from chunks  # pass (or shape unknown): emit the original chunks
        return _buffered()

    def _gen() -> Any:
        acc: list[str] = []
        for chunk in stream:
            acc.append(_extract_delta(chunk))
            yield chunk
        text = "".join(acc)
        if text.strip():
            _final_stream_check(text, sdk_method)

    return _gen()


def _wrap_stream_async(stream: Any, sdk_method: str | None = None) -> Any:
    """Async counterpart of :func:`_wrap_stream_sync`."""
    if _stream_guard_mode() == "buffer":
        async def _buffered() -> Any:
            chunks = []
            async for chunk in stream:
                chunks.append(chunk)
            text = "".join(_extract_delta(c) for c in chunks)
            action, value = await asyncio.to_thread(_buffer_validate, text, sdk_method)
            if action == "block":
                enforce(value)  # raises
            elif action == "softblock":
                decision, msg = value
                synth = _synthesize_block_response(msg, True, True, sdk_method)
                if synth is not None:
                    async for ch in synth:
                        yield ch
                    return
                enforce(decision)
            elif action == "mask":
                synth = _synthesize_block_response(value, True, True, sdk_method)
                if synth is not None:
                    async for ch in synth:
                        yield ch
                    return
            for chunk in chunks:
                yield chunk
        return _buffered()

    async def _agen() -> Any:
        acc: list[str] = []
        async for chunk in stream:
            acc.append(_extract_delta(chunk))
            yield chunk
        text = "".join(acc)
        if text.strip():
            await asyncio.to_thread(_final_stream_check, text, sdk_method)

    return _agen()


def _synthesize_block_response(message: str, stream: bool, is_async: bool, sdk_method: str | None) -> Any:
    """Provider-shaped response carrying the block-as-message text, so the host gets a normal reply instead of the
    model's (the model is never called). Covers OpenAI- and Anthropic-shaped SDKs; OpenAI form is the default."""
    m = (sdk_method or "").lower()
    anthropic = "anthropic" in m
    openai_wire = any(p in m for p in ("openai", "groq", "mistral", "azure", "litellm", "huggingface"))
    langchain = ("langchain" in m) or ("basechatmodel" in m) or ("chat_models" in m)
    if langchain:
        # generate/agenerate return an LLMResult; reply with the block message as the model output (no stream:
        # langchain streaming uses stream/astream, not the hooked generate). Falls back to hard-block if unshapeable.
        if stream:
            return None
        try:
            from langchain_core.messages import AIMessage
            from langchain_core.outputs import ChatGeneration, LLMResult

            return LLMResult(generations=[[ChatGeneration(message=AIMessage(content=message))]])
        except Exception:  # noqa: BLE001 - langchain_core layout differs -> caller hard-blocks instead
            return None
    if not (anthropic or openai_wire):
        return None  # shape unknown for this SDK (bedrock/vertex/ollama/gemini/...) -> caller hard-blocks instead
    ns = types.SimpleNamespace
    if stream:
        if anthropic:
            chunks = [ns(type="content_block_delta", index=0, delta=ns(type="text_delta", text=message))]
        else:
            chunks = [ns(choices=[ns(index=0, delta=ns(role="assistant", content=message), finish_reason="content_filter")])]
        if is_async:
            async def _agen() -> Any:
                for chunk in chunks:
                    yield chunk
            return _agen()

        def _gen() -> Any:
            for chunk in chunks:
                yield chunk
        return _gen()
    if anthropic:
        return ns(id="msg_bh", type="message", role="assistant", model="bytehide-guard",
                  stop_reason="content_filter", content=[ns(type="text", text=message)])
    return ns(id="chatcmpl-bh", object="chat.completion", model="bytehide-guard",
              choices=[ns(index=0, message=ns(role="assistant", content=message), finish_reason="content_filter")])


def _make_inline_wrapper(body_builder: Any, is_async: bool) -> Any:
    if is_async:
        async def _async_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
            # Defer when a Chainlit (or Direct Line) border guard is already validating this turn: the chat
            # boundary covers the same input/output, so guarding the inner SDK call too would double-validate
            # (one trace as model 'chat' from the border, one as the real model here). One guard per turn.
            # Record the real model so the border's output trace can show it instead of "chat".
            if _HTTP_GUARD_SUPPRESSED.get():
                _capture_turn_model(body_builder, instance, args, kwargs)
                return await wrapped(*args, **kwargs)
            # The host frames must be read on the loop thread at entry (they are live on
            # the send() chain here), before validation is handed off to a worker thread.
            stack = _call_site_stack()
            sdk_method = _sdk_method(wrapped)
            # Run the blocking /validate off the event loop so the host's async call site is not stalled.
            pre = await asyncio.to_thread(
                _pre_validate, body_builder, instance, args, kwargs, sdk_method, stack
            )
            if pre.block_message is not None:  # block-as-message: reply with the message if we can shape it for this SDK
                synth = _synthesize_block_response(pre.block_message, bool(kwargs.get("stream")), True, sdk_method)
                if synth is not None:
                    return synth
            enforce(pre.decision)  # raises SecurityException on a (hard) block; no-op when None
            result = await wrapped(*args, **kwargs)
            if kwargs.get("stream"):
                return _wrap_stream_async(result, sdk_method) if _stream_guard_mode() != "off" else result
            if pre.validate_output:
                out_decision = await asyncio.to_thread(_validate_output_result, result, sdk_method, stack)
                enforce(out_decision)
            return result

        return _async_wrapper

    def _wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
        # Defer to an active Chainlit/Direct Line border guard (see the async branch): one validation per turn.
        if _HTTP_GUARD_SUPPRESSED.get():
            _capture_turn_model(body_builder, instance, args, kwargs)
            return wrapped(*args, **kwargs)
        sdk_method = _sdk_method(wrapped)
        pre = _pre_validate(body_builder, instance, args, kwargs, sdk_method)
        if pre.block_message is not None:  # block-as-message: reply with the message if we can shape it for this SDK
            synth = _synthesize_block_response(pre.block_message, bool(kwargs.get("stream")), False, sdk_method)
            if synth is not None:
                return synth
        enforce(pre.decision)  # raises SecurityException on a (hard) block; no-op when None
        result = wrapped(*args, **kwargs)
        if kwargs.get("stream"):
            return _wrap_stream_sync(result, sdk_method) if _stream_guard_mode() != "off" else result
        if pre.validate_output:
            out_decision = _validate_output_result(result, sdk_method)
            enforce(out_decision)
        return result

    return _wrapper


def _make_gateway_observer(is_async: bool) -> Any:
    if is_async:
        async def _async_wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
            # Captured at entry: when the awaited call raises, the wrapper has been resumed
            # from the loop and the host's awaiting frames are no longer on the C stack.
            stack = _call_site_stack()
            try:
                return await wrapped(*args, **kwargs)
            except BaseException as exc:
                _observe_gateway_block(exc, _sdk_method(wrapped), stack)
                raise

        return _async_wrapper

    def _wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
        try:
            return wrapped(*args, **kwargs)
        except BaseException as exc:
            _observe_gateway_block(exc, _sdk_method(wrapped))
            raise

    return _wrapper


def _wrap_class_method(cls: Any, method: str, wrapper: Any) -> None:
    """Idempotently wraps ``cls.method`` (a per-class sentinel guards against double-wrap across module paths)."""
    sentinel = f"_bh_ai_wrapped_{method}"
    if getattr(cls, sentinel, False):
        return
    try:
        wrapt.wrap_function_wrapper(cls, method, wrapper)
        setattr(cls, sentinel, True)
    except Exception:  # noqa: BLE001 - SDK variant without this method; skip it
        pass


# Each call target: (sdk module paths, class name, method, is_async, guard-body builder).
# Redirectable SDKs (OpenAI, Anthropic) follow the mode: gateway -> observe the redirected call; inline -> pre-validate.
_REDIRECTABLE_TARGETS: tuple[tuple[tuple[str, ...], str, str, bool, Any], ...] = (
    (_OPENAI_CALL_MODULES, "Completions", "create", False, _openai_chat_body),
    (_OPENAI_CALL_MODULES, "AsyncCompletions", "create", True, _openai_chat_body),
    (_OPENAI_RESPONSES_MODULES, "Responses", "create", False, _openai_responses_body),
    (_OPENAI_RESPONSES_MODULES, "AsyncResponses", "create", True, _openai_responses_body),
    (_ANTHROPIC_CALL_MODULES, "Messages", "create", False, _anthropic_msg_body),
    (_ANTHROPIC_CALL_MODULES, "AsyncMessages", "create", True, _anthropic_msg_body),
)
# Anthropic's ``messages.stream()`` helper builds its request via ``_post`` directly, bypassing the wrapped
# ``create`` (unlike OpenAI's ``.stream()``, which delegates to ``create`` and is covered transitively). It also
# returns a LAZY stream manager whose HTTP request only fires on context entry, so the gateway-mode observer -
# which wraps the call and inspects the raised exception - cannot see a block that surfaces later at
# ``__enter__``/``__aenter__``. These targets are therefore ALWAYS pre-validated inline, in BOTH modes, so a
# streamed prompt injection is both blocked and reported; in gateway mode the redirected stream still applies
# the full guard product at the gateway on top. Both methods are synchronous (they return a context manager,
# they are not coroutines), so both register with ``is_async=False``; the sync inline wrapper validates before
# the manager is built. The async helper is called synchronously on the loop thread, so the blocking validate
# briefly stalls the loop on stream entry - the same trade-off the other native inline targets accept.
_ANTHROPIC_STREAM_TARGETS: tuple[tuple[tuple[str, ...], str, str, bool, Any], ...] = (
    (_ANTHROPIC_CALL_MODULES, "Messages", "stream", False, _anthropic_msg_body),
    (_ANTHROPIC_CALL_MODULES, "AsyncMessages", "stream", False, _anthropic_msg_body),
)
# Native SDKs cannot be transparently rerouted, so they are ALWAYS pre-validated inline (in both modes).
# An empty class name targets a module-level function (LiteLLM's functional API).
_NATIVE_TARGETS: tuple[tuple[tuple[str, ...], str, str, bool, Any], ...] = (
    (_GROQ_CALL_MODULES, "Completions", "create", False, _openai_chat_body),
    (_GROQ_CALL_MODULES, "AsyncCompletions", "create", True, _openai_chat_body),
    (_MISTRAL_CALL_MODULES, "Chat", "complete", False, _openai_chat_body),
    (_MISTRAL_CALL_MODULES, "Chat", "complete_async", True, _openai_chat_body),
    (_GEMINI_LEGACY_MODULES, "GenerativeModel", "generate_content", False, _gemini_body),
    (_GEMINI_LEGACY_MODULES, "GenerativeModel", "generate_content_async", True, _gemini_body),
    (_GEMINI_UNIFIED_MODULES, "Models", "generate_content", False, _gemini_body),
    (_GEMINI_UNIFIED_MODULES, "AsyncModels", "generate_content", True, _gemini_body),
    (_LITELLM_MODULES, "", "completion", False, _positional_chat_body),
    (_LITELLM_MODULES, "", "acompletion", True, _positional_chat_body),
    (_OLLAMA_CALL_MODULES, "Client", "chat", False, _positional_chat_body),
    (_OLLAMA_CALL_MODULES, "Client", "generate", False, _ollama_generate_body),
    (_OLLAMA_CALL_MODULES, "AsyncClient", "chat", True, _positional_chat_body),
    (_OLLAMA_CALL_MODULES, "AsyncClient", "generate", True, _ollama_generate_body),
    (_VERTEX_CALL_MODULES, "GenerativeModel", "generate_content", False, _gemini_body),
    (_VERTEX_CALL_MODULES, "GenerativeModel", "generate_content_async", True, _gemini_body),
    # Cohere v2 (messages) and v1 (single message string); chat + chat_stream, sync + async.
    (_COHERE_V2_MODULES, "V2Client", "chat", False, _openai_chat_body),
    (_COHERE_V2_MODULES, "V2Client", "chat_stream", False, _openai_chat_body),
    (_COHERE_V2_MODULES, "AsyncV2Client", "chat", True, _openai_chat_body),
    (_COHERE_V2_MODULES, "AsyncV2Client", "chat_stream", True, _openai_chat_body),
    (_COHERE_V1_MODULES, "BaseCohere", "chat", False, _cohere_v1_body),
    (_COHERE_V1_MODULES, "BaseCohere", "chat_stream", False, _cohere_v1_body),
    (_COHERE_V1_MODULES, "AsyncBaseCohere", "chat", True, _cohere_v1_body),
    (_COHERE_V1_MODULES, "AsyncBaseCohere", "chat_stream", True, _cohere_v1_body),
    # Hugging Face InferenceClient.chat_completion (sync + async).
    (_HF_MODULES, "InferenceClient", "chat_completion", False, _hf_chat_body),
    (_HF_MODULES, "AsyncInferenceClient", "chat_completion", True, _hf_chat_body),
    # Azure AI Inference ChatCompletionsClient.complete (sync module + .aio async module).
    (_AZURE_SYNC_MODULES, "ChatCompletionsClient", "complete", False, _openai_chat_body),
    (_AZURE_ASYNC_MODULES, "ChatCompletionsClient", "complete", True, _openai_chat_body),
    # Replicate run()/async_run(): the module-level functions and the Client methods.
    (_REPLICATE_FUNC_MODULES, "", "run", False, _replicate_body),
    (_REPLICATE_FUNC_MODULES, "", "async_run", True, _replicate_body),
    (_REPLICATE_CLIENT_MODULES, "Client", "run", False, _replicate_body),
    (_REPLICATE_CLIENT_MODULES, "Client", "async_run", True, _replicate_body),
    # LangChain / LangGraph: one hook on BaseChatModel.generate/agenerate guards every chat model and the
    # create_agent path, whatever provider sits underneath. Always inline (the call cannot be redirected).
    (_LANGCHAIN_MODULES, "BaseChatModel", "generate", False, _langchain_body),
    (_LANGCHAIN_MODULES, "BaseChatModel", "agenerate", True, _langchain_body),
)

# Bedrock call methods guarded on each bedrock-runtime client (boto3 is sync; kwargs-only calling convention).
def _bedrock_agent_body(instance: Any, args: tuple, kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Guard body from a Bedrock Agent ``invoke_agent`` call (bedrock-agent-runtime): the user prompt is the
    ``inputText`` kwarg. The managed agent runs its own model/tools server-side, so only the perimeter prompt is
    validated here (block on a hit); the agent's streamed response is an EventStream the host consumes itself."""
    text = kwargs.get("inputText")
    if not isinstance(text, str) or not text:
        return None
    agent = kwargs.get("agentId")
    model = f"agent:{agent}" if isinstance(agent, str) and agent else "agent"
    return {"model": model, "messages": [{"role": "user", "content": text}]}


_BEDROCK_METHODS: tuple[tuple[str, Any], ...] = (
    ("converse", _bedrock_converse_body),
    ("converse_stream", _bedrock_converse_body),
    ("invoke_model", _bedrock_invoke_body),
    ("invoke_model_with_response_stream", _bedrock_invoke_body),
)

# Bedrock Agent (bedrock-agent-runtime): only invoke_agent carries a user prompt to guard.
_BEDROCK_AGENT_METHODS: tuple[tuple[str, Any], ...] = (
    ("invoke_agent", _bedrock_agent_body),
)


def _register_target(modules: tuple[str, ...], class_name: str, method: str, is_async: bool, body_builder: Any, inline: bool) -> None:
    """Registers post-import hooks that wrap ``class_name.method`` (or the module-level ``method`` when
    ``class_name`` is empty) on each candidate module (inline or observer)."""
    def _hook(module: Any) -> None:
        target = getattr(module, class_name, None) if class_name else module
        if target is None:
            return
        wrapper = _make_inline_wrapper(body_builder, is_async) if inline else _make_gateway_observer(is_async)
        _wrap_class_method(target, method, wrapper)

    for module_name in modules:
        wrapt.register_post_import_hook(_hook, module_name)


def _agent_event_iter(text: str) -> Any:
    """A Bedrock Agent completion stream that yields a single chunk carrying ``text`` (block-as-message / masked)."""
    def _gen() -> Any:
        yield {"chunk": {"bytes": (text or "").encode("utf-8")}}
    return _gen()


def _wrap_agent_completion(events: Any, sdk_method: str | None) -> Any:
    """Buffer a Bedrock Agent ``completion`` event-stream, validate the full reply in-process, and re-emit it
    masked/blocked (full mask & block, buffered). Pass-through re-emits the original events. Fail-open."""
    def _gen() -> Any:
        buffered = list(events)
        text = "".join(
            e["chunk"]["bytes"].decode("utf-8", "replace")
            for e in buffered
            if isinstance(e, dict) and isinstance(e.get("chunk"), dict) and e["chunk"].get("bytes")
        )
        action, value = _buffer_validate(text, sdk_method)
        if action == "block":
            enforce(value)  # raises
        elif action == "softblock":
            _, msg = value
            yield {"chunk": {"bytes": (msg or "").encode("utf-8")}}
            return
        elif action == "mask":
            yield {"chunk": {"bytes": value.encode("utf-8")}}
            return
        yield from buffered
    return _gen()


def _make_bedrock_agent_wrapper(body_builder: Any) -> Any:
    """Dedicated wrapper for ``invoke_agent``: guards the INPUT (block-as-message -> reply via the completion shape,
    or hard block; mask -> substitute inputText) AND the OUTPUT (wrap response["completion"] to mask/block). Fully
    plug-and-play, so a managed agent is guarded with no app code (input + output)."""
    sdk_method = "bedrock-agent-runtime.invoke_agent"

    def _wrapper(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
        pre = _pre_validate(body_builder, instance, args, kwargs, sdk_method)
        if pre.block_message is not None:  # block-as-message: reply with the message via the agent's completion shape
            return {"completion": _agent_event_iter(pre.block_message)}
        enforce(pre.decision)  # reject-mode (hard) block -> raises; no-op when clean
        result = wrapped(*args, **kwargs)
        if isinstance(result, dict) and "completion" in result and _stream_guard_mode() != "off":
            result["completion"] = _wrap_agent_completion(result["completion"], sdk_method)
        return result

    return _wrapper


def _wrap_bedrock_client(client: Any, methods: tuple[tuple[str, Any], ...], agent: bool = False) -> None:
    """Wraps the guarded call methods on one bedrock(-agent)-runtime client instance (always inline pre-validation).
    Agent clients use the dedicated invoke_agent wrapper (guards input AND the completion output)."""
    for method, body_builder in methods:
        if hasattr(client, method):
            wrapper = _make_bedrock_agent_wrapper(body_builder) if agent else _make_inline_wrapper(body_builder, is_async=False)
            _wrap_class_method(client, method, wrapper)


def _botocore_create_client(wrapped: Any, instance: Any, args: tuple, kwargs: dict[str, Any]) -> Any:
    """Post-processes botocore client creation, guarding bedrock-runtime and bedrock-agent-runtime clients."""
    client = wrapped(*args, **kwargs)
    try:
        service = kwargs.get("service_name") or (args[0] if args else None)
        if service == _BEDROCK_SERVICE:
            _wrap_bedrock_client(client, _BEDROCK_METHODS)
        elif service == _BEDROCK_AGENT_SERVICE:
            _wrap_bedrock_client(client, _BEDROCK_AGENT_METHODS, agent=True)
    except Exception:  # noqa: BLE001 - guarding is best-effort; never break client creation
        pass
    return client


def _register_bedrock() -> None:
    """Hooks botocore client creation so bedrock-runtime clients are guarded regardless of import order."""
    def _hook(module: Any) -> None:
        creator = getattr(module, "ClientCreator", None)
        if creator is not None:
            _wrap_class_method(creator, "create_client", _botocore_create_client)

    wrapt.register_post_import_hook(_hook, _BOTOCORE_CLIENT_MODULE)


def _register_targets(targets: tuple[tuple[tuple[str, ...], str, str, bool, Any], ...], inline: bool) -> None:
    for modules, class_name, method, is_async, body_builder in targets:
        _register_target(modules, class_name, method, is_async, body_builder, inline)


def install() -> None:
    """Arms the LlmPromptInjection guard (opt-in via BYTEHIDE_AI_GATEWAY_URL).

    The SDK interception hooks are ALWAYS registered: enforcement of the LlmPromptInjection
    rule lives per call (a disabled rule no-ops in ``_pre_validate``), so the rule can be
    toggled from the dashboard at any heartbeat without re-installing. The gateway's
    project config (``ai_enabled``/``mode``) governs only the OPTIONAL full AI-guard
    product: when it selects ``gateway`` mode, the redirectable SDKs are rerouted through
    the gateway (guard + PII redaction there) instead of inline pre-validation.
    """
    config = _gateway_config()
    if config is None:
        return
    enabled, mode = _resolve_activation(config)
    # Native SDKs (groq/mistral/gemini/vertex/litellm/ollama/bedrock) cannot be redirected, so they are always
    # guarded by inline pre-validation against /monitor/validate (the gateway's default injection policy).
    _register_targets(_NATIVE_TARGETS, inline=True)
    _register_bedrock()
    # The Anthropic streaming helper bypasses ``create`` and cannot be observed (see _ANTHROPIC_STREAM_TARGETS),
    # so it is pre-validated inline regardless of mode.
    _register_targets(_ANTHROPIC_STREAM_TARGETS, inline=True)
    if enabled and mode == MODE_GATEWAY:
        # The full AI-guard product: rewrite the OpenAI/Anthropic client base_url to the gateway (which guards
        # the proxied call itself) and observe gateway blocks to report. No inline pre-validation for these -
        # the gateway already guards them; double-validating would add a second round-trip per call.
        wrapt.register_post_import_hook(lambda module: _patch_clients(module, ("OpenAI", "AsyncOpenAI"), _openai_init), "openai")
        wrapt.register_post_import_hook(lambda module: _patch_clients(module, ("Anthropic", "AsyncAnthropic"), _anthropic_init), "anthropic")
        _register_targets(_REDIRECTABLE_TARGETS, inline=False)
        MonitorLogger.info(
            "I_AI_REDIRECT",
            "AI SDK gateway redirect armed (openai, anthropic) + native inline guard (groq, mistral, gemini, vertexai, litellm, ollama, bedrock, cohere, huggingface_hub, azure-ai-inference, replicate, langchain)",
        )
        return
    # Inline mode, or the gateway AI-guard product is off for the project: every SDK is intercepted and
    # pre-validated inline, governed per call by the LlmPromptInjection rule.
    _register_targets(_REDIRECTABLE_TARGETS, inline=True)
    MonitorLogger.info(
        "I_AI_INLINE",
        "AI SDK inline pre-validation armed (openai, anthropic, groq, mistral, gemini, vertexai, litellm, ollama, bedrock, cohere, huggingface_hub, azure-ai-inference, replicate, langchain)",
    )

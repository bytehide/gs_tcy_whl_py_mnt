"""Sink instrumentation helpers.

A sink wrapper extracts the dangerous value (SQL query, command, path, URL), hands
it to the matching collector, and - when the collector returns a block decision and
the engine is in block mode - raises :class:`SecurityException` to abort the operation
before it runs. In detect-only mode (no block) the operation proceeds.

All wrappers are best-effort and fail open: any error inside instrumentation is
swallowed so the host application is never broken by the monitor.
"""

from __future__ import annotations

import contextvars
from collections.abc import Callable

from bytehide_monitor.cloud.runtime import CloudRuntime, get_active
from bytehide_monitor.cloud.scanner.block_decision import BlockDecision
from bytehide_monitor.core import reentry_guard
from bytehide_monitor.core.protection.security_exception import SecurityException

# A sink raises SecurityException to abort the dangerous operation. Some applications wrap the call
# site in a broad ``except Exception`` (e.g. crAPI's apply_coupon catches the DB error and returns
# 500), swallowing the block so it never reaches the framework's SecurityException handler. To make
# the block unswallowable, the decision is ALSO recorded here in a per-request contextvar; the
# framework source honours it after the view returns - turning a swallowed block into the proper 403
# regardless of what the application did with the exception.
_PENDING_BLOCK: contextvars.ContextVar[BlockDecision | None] = contextvars.ContextVar(
    "bh_pending_block", default=None
)


def set_pending_block(decision: BlockDecision) -> None:
    _PENDING_BLOCK.set(decision)


def consume_pending_block() -> BlockDecision | None:
    """Return and clear any pending block decision recorded during this request."""
    decision = _PENDING_BLOCK.get()
    if decision is not None:
        _PENDING_BLOCK.set(None)
    return decision


def clear_pending_block() -> None:
    _PENDING_BLOCK.set(None)


def active_runtime() -> CloudRuntime | None:
    # Suppress instrumentation while the monitor performs its own internal I/O
    # (logging, reporting, threat-intel) to avoid recursion and self-inspection.
    if reentry_guard.is_active():
        return None
    runtime = get_active()
    if runtime is None or not runtime.enabled:
        return None
    return runtime


def enforce(decision: BlockDecision | None) -> None:
    """Act on a sink detection: abort when blocking, report-only when ``log``/``none``.

    ``scan_sink`` returns a decision for any detector match. A blocking decision raises
    :class:`SecurityException` to abort the operation (the caller reports the incident on
    the exception path). A non-blocking decision (action ``log``/``none``) reports the
    incident here and lets the operation proceed, matching the inbound request path.
    """
    if decision is None:
        return
    if decision.blocked:
        # Record the block so a framework source can still emit the 403 even if the application
        # swallows the exception, then raise to abort the dangerous operation.
        set_pending_block(decision)
        raise SecurityException(decision)
    runtime = active_runtime()
    if runtime is not None:
        runtime.report_sink_incident(decision)


def guarded(action: Callable[[], None]) -> None:
    """Run sink instrumentation, swallowing everything except SecurityException."""
    try:
        action()
    except SecurityException:
        raise
    except Exception:  # noqa: BLE001 - instrumentation must never break the host
        pass

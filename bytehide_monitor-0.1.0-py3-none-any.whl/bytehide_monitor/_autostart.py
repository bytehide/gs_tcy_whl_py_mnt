"""
Zero-code auto-activation hook (the closest Python has to a .NET module initializer).

A `bytehide_monitor_autostart.pth` shipped in site-packages makes the interpreter `import` this module at startup
(before any app code), so installing the package can arm protection without the app calling `protect()`.

Gating (so it never fires for the wrong process):
- `BYTEHIDE_DISABLE` truthy            -> never auto-arm.
- `BYTEHIDE_MONITOR_AUTO` set          -> explicit on/off wins (1/true/yes/on vs 0/false/no/off).
- otherwise                            -> auto-arm only when a project token is present AND the process is not a
                                          packaging/build tool (pip, build, wheel, …), so `pip install` etc. are
                                          never instrumented.

Always fail-open: any error here is swallowed so a bad auto-init can never break the interpreter.
"""

import os
import sys

_TRUTHY = {"1", "true", "yes", "on"}


def _truthy(value: object) -> bool:
    return str(value or "").strip().lower() in _TRUTHY


def _is_packaging_tool() -> bool:
    """Best-effort: skip auto-arm when the interpreter is running pip / build / packaging tooling."""
    argv0 = os.path.basename((sys.argv[0] if sys.argv else "") or "").lower()
    if argv0 in {"pip", "pip3", "easy_install", "wheel", "build", "twine", "virtualenv", "uv"}:
        return True
    return any(mod in sys.modules for mod in ("pip", "build"))


def _should_autostart() -> bool:
    if _truthy(os.environ.get("BYTEHIDE_DISABLE")):
        return False
    auto = os.environ.get("BYTEHIDE_MONITOR_AUTO")
    if auto is not None:
        return _truthy(auto)  # explicit opt-in/out always wins
    # Default: arm when a project token signals intent, but never during a packaging/build run.
    has_token = bool(os.environ.get("BYTEHIDE_MONITOR_TOKEN") or os.environ.get("BYTEHIDE_TOKEN"))
    return has_token and not _is_packaging_tool()


def _run() -> None:
    if not _should_autostart():
        return
    try:
        import bytehide_monitor

        bytehide_monitor.protect()
    except Exception:  # noqa: BLE001 - auto-init must never break the host interpreter
        pass


_run()
